const _md5 = require('md5');
const jwt = require('jsonwebtoken');
const config = require('../clavetoken');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
var CryptoJS = require("crypto-js");

module.exports = app => {


app.get('/login', async (req, res) => {

  

    res.render('./login/login.ejs');
    
});


app.post('/login', async (req, res) => {
    try{
        var usuario = req.body.usuario;
       
        var username = "";
        var clave =  req.body.contrasena;  //_md5(req.body.contrasena);
        var msg = 'El usuario o clave ingresados son incorrectos, intente nuevamente.';
        var dte = await pool.query(consultas.claves());
        var login = await pool.query(consultas.login(usuario,clave));
        console.log(login);
                if(login[0].length>0){
                    const token = jwt.sign({"usuario": usuario}, dte[0].token, {
                        expiresIn: 36000
                    });
                   // var loguear = await pool.query(consultas.loguear(login[0].idusuario));
                    req.session.usuario = usuario;
                    req.session.encriptado = { "clave": CryptoJS.AES.encrypt("seguridad_encriptada",  dte[0].clave).toString()};
                    req.session.user_data={token};
                    req.session.user_data.idusuario =login[0][0].idusuario;
                    req.session.user_data.username =login[0][0].nombre.toString().trim();
                    username=login[0][0].nombre.toString().trim();
                    req.session.camino =[]
                   // console.log("token generado "+req.session.user_data.token);
                    res.redirect('/');

                } else{
                
                    var mensaje = {"respuesta":"Usuario y/o contraseña incorrecta.",
                                   "continuar":"Volver a Iniciar Sesión",
                                   "ruta": "/-" }
                    res.render('./components/mensaje_error.ejs', {mensaje});
                    //res.json({"Error":"Fallo al  activar empresa."})
                }
       
    }
    catch(error){
        console.log(error);
    }
    });;



app.get('/logout', async (req, res) => {
    req.session.user_data=null;
    req.session.usuario=null;
    res.redirect('/login');
});

}