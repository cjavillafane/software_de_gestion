<?php
  /* $_SESSION['usuario']=2846; */

  session_start();
  if(isset($_SESSION['usuario'])){
    echo 'login';
    header( 'Location: ./pages/mapa/index.php');
    exit;    
  }else{
    echo 'no conectado';
    header( 'Location: ./pages/login/index.php');
  }
  if (isset($_POST['logout'])){
    session_destroy();
    $days = 30;
    setcookie ("rememberme","", time() - ($days * 24 * 60 * 60 * 1000));
  }
 
?>