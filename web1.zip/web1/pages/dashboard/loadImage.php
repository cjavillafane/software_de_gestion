<div class="uk-padding">
  <div class="uk-card uk-card-default uk-card-small uk-card-body">
    <h3 class="uk-card-title"><i class="fas fa-image"></i> Carga de Imagenes por cuenta</h3>

    <div class="uk-margin">
      <input id="inpDist" class="uk-input uk-form-width-medium uk-form-small" type="number" placeholder="Dist.">
      <input id="inpCta" class="uk-input uk-form-width-medium uk-form-small" type="number" placeholder="Cuenta">
      <input id="inpScta" class="uk-input uk-form-width-medium uk-form-small" type="number" placeholder="Scta.">
      <input id="inpFecha" class="uk-input uk-form-width-medium uk-form-small" type="number" placeholder="Fecha de Imagen">
    </div>
    <div class="uk-margin" uk-margin>
      <div uk-form-custom="target: true">
        <input type="file" id="inpFile">
        <input  class="uk-input uk-form-small" type="text" placeholder="Select file" disabled>
      </div>
  
      <button id="btnCargar" class="uk-button uk-button-secondary uk-button-small"> Cargar Imagen</button>
    </div>
  
  </div>
</div>
  
