

document.onreadystatechange = function () {
  if (document.readyState === "interactive") {

    document.querySelector("#btnCargar").addEventListener("click", () => {
     
      let dist=document.getElementById("inpDist").value;
      let cta=document.getElementById("inpCta").value;
      let scta=document.getElementById("inpScta").value;
      let fecha=document.getElementById("inpFecha").value;
      let tipo=1;
      const archivo=document.querySelector("#inpFile");
     /*  const inputFile = document.querySelector("#inputFile"); */
      subirImagen(dist,cta,scta,fecha,tipo,archivo)

    });
 /*    var formData = new FormData();
    var fileField = document.querySelector("input[type='file']");
 */



    function subirImagen(dist,cta,scta,fecha,tipo,archivo ){
      let formData = new FormData();
      formData.append('inm_dist', dist);
      formData.append('inm_cta', cta);
      formData.append('inm_scta', scta);
      formData.append('tipo', tipo);
      formData.append('fecha', fecha);
      formData.append('archivo', archivo.files[0]);
     /*  formData.append("archivo", inputFile.files[0]); */

      fetch ('../php/subirImagen.php',{
        method: 'POST',  
        body: formData,        
      })
      .then ( response => response.ok ? response.json() : Promise.reject(response))
      .then (json =>{
        console.log(json);
      })
      .catch((error) => console.log(error))
    };
  };
};