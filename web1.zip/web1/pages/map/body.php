
  <div style="width: 400px; height: 700px;">   
    <div class="uk-card  uk-card-secondary uk-card-body" >
    <div class="uk-tile uk-tile-primary uk-padding-remove">
      <div class="uk-text-center"> 
        <p class="uk-h4">Cargo Esp. por Infraestructura</p>
        <p class="uk-h4">123-789-0</p>
      </div>
    </div>
    <!--   <div class="uk-background-default uk-padding uk-panel uk-card-title">
        <p class="uk-h4">Cargo Especial por Infraestructura - 123-789-0</p>
      </div> -->
      <ul uk-accordion="multiple: true">
        <li>
            <a class="uk-accordion-title" href="#" ><i class="far fa-file-alt"></i> Liq. N° 456 -  10/01/2017</a>
            <div class="uk-accordion-content">
            <hr>
            <ul class="uk-list">
                <li><b>Cuenta liq.:</b> 123-456-0 (inm_cod_liq)</li>
                <li><b>Sup. Liq.:</b> 500 m2 (sup_cub)</li>
                <li><b>N° Recibo:</b> 457 (nro_recibo)</li>
                <li><b>Fecha Recibo:</b> 12/10/2021 (fecha_recibo)</li>
                <li><b>Propietario:</b> Juan Perez (propietario)</li>
                <li><b>Obsevacion:</b> algo adicional ........(observacion)</li>
            </ul>
            <hr>
            </div>
        </li>
        <li>
            <a class="uk-accordion-title " href="#"  ><i class="far fa-file-alt"></i> Liq. N° 596 -  1/07/2018</a>
            <div class="uk-accordion-content">
              <hr>
              <ul class="uk-list">
                <li>Cuenta liq.: 123-456-0 (inm_cod_liq)</li>
                <li>Sup. Liq.:  500 m2 (sup_cub)</li>
                <li>N° Recibo:  457 (nro_recibo)</li>
                <li>Fecha Recibo: 12/10/2021 (fecha_recibo)</li>
                <li>Propietario: Juan Perez (propietario)</li>
                <li>Obsevacion: algo adicional ........(observacion)</li>
              </ul>
              <hr>
            </div>
        </li>
        <li>
            <a class="uk-accordion-title" href="#" ><i class="far fa-file-alt"></i> Liq. N° 957 -  15/01/2021</a>
            <div class="uk-accordion-content">
              <hr>
              <ul class="uk-list">
                <li>Cuenta liq.: 123-456-0 (inm_cod_liq)</li>
                <li>Sup. Liq.:  500 m2 (sup_cub)</li>
                <li>N° Recibo:  457 (nro_recibo)</li>
                <li>Fecha Recibo: 12/10/2021 (fecha_recibo)</li>
                <li>Propietario: Juan Perez (propietario)</li>
                <li>Obsevacion: algo adicional ........(observacion)</li>
              </ul>
              <hr>
            </div>
        </li>
      </ul>
    </div>  
  </div>

