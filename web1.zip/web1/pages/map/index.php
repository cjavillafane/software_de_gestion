<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
  <meta name="description" content="descripcion">
  <meta name="keywords" content="lista de temas para el buscador">
  <meta name="author" content="Vargas Elias Gustavo">
  <title>pagina</title>
  <link rel="shortcut icon" href="../../images/images.jpg" type="image/jpg">
  <?php include '../links.php'; ?>
  <link rel="stylesheet" href="./css/style.css">
</head>
<body>
  <?php include 'body.php'; ?>
  <?php include '../scripts.php';?>
  <script src="./js/app.js"></script>
</body>
</html>