<?php 
  include "../../php/conexion.php";
  $conexion=conexionBD();

  session_start();
  if (isset($_COOKIE["usuario_ck"]) && isset($_COOKIE["marca_aleatoria_ck"])){
    $ssql = "SELECT idusuario,nombre,agencia,idrol FROM usuarios  WHERE idusuario=". $_COOKIE['usuario_ck'] ." AND cookie=". $_COOKIE['marca_aleatoria_ck'] ." AND cookie IS NOT NULL AND estado='A'";
    $rs=pg_query($conexion,$ssql);
    
    if (pg_num_rows($rs)==1){
      $row=pg_fetch_assoc($rs);      
      $_SESSION['usuario']=$row['idusuario'];
      $_SESSION['nombre']=$row['nombre'];
      $_SESSION['agencia']=$row['agencia'];
      $_SESSION['idrol']=$row['idrol'];
    }else{
      echo "falla logueo";
    }
  }else {
    echo "no existe cookie";
  }
  
  if ($_SESSION["usuario"]!=''){ 
    header( 'Location: ../../mapa/index.php');
    exit; 
  }else{
    header( 'Location: ../index.php');
    exit; 
  } 
?>