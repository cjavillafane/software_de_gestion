<div id="modRegister" uk-modal>
  <div class="uk-modal-dialog uk-modal-body">
    <button class="uk-modal-close-default" type="button" uk-close></button>
    <h2 class="uk-modal-title">Registrar</h2>
    <div class="uk-margin">
      <div class="uk-inline uk-width-1-1">
        <span class="uk-form-icon uk-form-icon-flip" uk-icon="icon: user">*</span>
        <input id="inpUsuarioR"class="uk-input uk-form-small" type="text" placeholder="Numero de Legajo" 
         uk-tooltip="title: Numero de Legajo, solo numeros enteros (0-9999); pos: bottom-left"> 
      </div>
      
    </div>
    <div class="uk-margin">
      <div class="uk-inline uk-width-1-1">
        <!--         <i class="uk-form-icon uk-form-icon-flip fas fa-user-tag"></i> -->
        <span class="uk-form-icon uk-form-icon-flip" uk-icon="icon:  bookmark">*</span>
        <input id="inpNombre"class="uk-input uk-form-small" type="text" placeholder="Nombre y Apellido"
        uk-tooltip="title: Ingresar Nombre y Apellido, solo letras ; pos: bottom-left"> 
      </div>
    </div>
    <div class="uk-margin">
      <div class="uk-inline uk-width-1-1">        
        <span class="uk-form-icon uk-form-icon-flip" uk-icon="icon:  mail"></span>
        <input id="inpMailInt"class="uk-input uk-form-small" type="text" placeholder="direccion@linuxc.ost Correo Interno"
        uk-tooltip="title: ingresar un email valido ej: direccion@linuxc.ost; pos: bottom-left"> 
      </div>
    </div>
    <div class="uk-margin">
      <div class="uk-inline uk-width-1-1">        
        <span class="uk-form-icon uk-form-icon-flip" uk-icon="icon:  mail">* </span>
        <input id="inpMail"class="uk-input uk-form-small" type="text" placeholder="direccion@dominio.com Correo Externo"
        uk-tooltip="title: ingresar un email valido ej: direccion@dominio.com; pos: bottom-left"> 
      </div>
    </div>
    <div class="uk-margin">
      <label for="inpAgencia" class="uk-form-label">* Agencia</label>
      <div class="uk-form-controls">
        <select id="inpAgencia" name="inpAgencia" class="uk-select uk-form-small"
        uk-tooltip="title: selleccionar la agencia correspondiente ; pos: bottom-left">
          <option value="0" select>Seleccionar una Agencia</option>        
        </select>  
      </div>
    </div>
    <!-- <div class="uk-margin">
      <label for="inpDistrito" class="uk-form-label">Distritos</label>
      <div class="uk-form-controls">
        <select id="inpDistrito" name="inpDistrito" class="uk-select uk-form-small" disabled
        uk-tooltip="title: Seleccionar un registro de la agencia correspondiente ; pos: bottom-left"></select>          
      </div>
    </div>  -->
    <div class="uk-margin">
      <div class="uk-inline uk-width-1-1">
        <a class="uk-form-icon uk-form-icon-flip" uk-icon="icon: lock" href="#" id="btnPasswordR">*</a>
        <input id="inpPasswordR"class="uk-input uk-form-small" type="password" placeholder="Password 8 a 16 (Letras y Numeros)"
        uk-tooltip="title: Password debe contener AL MENOS una mayuscula, un numero y una minuscula, como minimo 8 y maximo 16; pos: bottom-left">
      </div>  
    </div>   
    <p class="uk-text-right">
      <button class="uk-button uk-button-default uk-modal-close" type="button"
      uk-tooltip="title: Cancelar el Registro ; pos: bottom-left">Cancelar</button>
      <button class="uk-button uk-button-secondary" type="button" id="btnRegister"
      uk-tooltip="title: Enviar la informacion para el registro ; pos: bottom-left">Enviar</button>
    </p>
  </div>
</div>