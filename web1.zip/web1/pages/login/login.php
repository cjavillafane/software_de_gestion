<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){ 
    $usuario= $_POST["usuario"];  
    $password= $_POST["password"];
    $recuerdame=$_POST["recuerdame"];
    include "../php/conexion.php";
    $conexion=conexionBD();
    
    $sql="SELECT CASE WHEN EXISTS(SELECT 1 FROM usuarios WHERE idusuario=$usuario AND estado='A') THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END";
    $result=pg_query($conexion,$sql);
    if (!$result){
      die("Error, no se ejecutó la consulta 1.");
    }else{
      $res= pg_fetch_result($result,0);
      
      if ($res){
        $sqlv="SELECT idusuario,nombre,agencia,idrol FROM usuarios WHERE idusuario=$usuario AND password='$password'";
        $resultv=pg_query($conexion,$sqlv);
        
        if(!$resultv){        
          die("Error, no se ejecutó la consulta 2.");
        }else{
          $count=pg_num_rows($resultv);
          $row=pg_fetch_assoc($resultv);
          if ($count==1){
            session_name("U$usuario");
            session_start();
            $_SESSION['usuario']=$row['idusuario'];
            $_SESSION['nombre']=$row['nombre'];
            $_SESSION['agencia']=$row['agencia'];
            $_SESSION['idrol']=$row['idrol'];
            $_SESSION['ultimoAcceso']= date('Y-n-j H:i:s');
            echo '3';
            if($recuerdame){
              echo 'guarda cookie';
              mt_srand (time());
              $aleatorio=mt_rand(1000000,999999999);
              $ssql = "UPDATE usuarios SET cookie='$aleatorio' where idusuario=$usuario";
              $uptade=pg_query($conexion,$ssql);
              setcookie("usuario_ck", $usuario , time()+(60*60*24*365));
              setcookie("marca_aleatoria_ck", $aleatorio, time()+(60*60*24*365));
            }

          }else{
            echo '2';
          }

        }        
      }else{
        echo $res;
      }
    }
  
    desconectarBD($conexion);
  };  
?>