<?php 
include "../php/conexion.php";
$conexion=conexionBD();

session_start();
if (isset($_COOKIE["usuario_ck"]) && isset($_COOKIE["marca_aleatoria_ck"])){
  $ssql = "SELECT idusuario,nombre,agencia,idrol FROM usuarios  WHERE idusuario=". $_COOKIE['usuario_ck'] ." AND cookie=". $_COOKIE['marca_aleatoria_ck'] ." AND cookie IS NOT NULL AND estado='A'";
  $rs=pg_query($conexion,$ssql);
  
  if (pg_num_rows($rs)==1){
    $row=pg_fetch_assoc($rs);      
    $_SESSION['usuario']=$row['idusuario'];
    $_SESSION['nombre']=$row['nombre'];
    $_SESSION['agencia']=$row['agencia'];
    $_SESSION['idrol']=$row['idrol'];
  }else{
 /*    echo "falla logueo"; */
  }
}else {
  /* echo "no existe cookie"; */
}
desconectarBD($conexion);
if (isset($_SESSION["usuario"])){ 
  header( 'Location: ../mapa/index.php');
  exit; 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
  <meta name="description" content="descripcion">
  <meta name="keywords" content="login">
  <meta name="author" content="Vargas Elias Gustavo">
  <title>Inicio de Secion</title>
  <link rel="shortcut icon" href="../../images/images.jpg" type="image/jpg">
  <?php include '../links.php'; ?>
  <link rel="stylesheet" href="./css/style.css">
</head>
<body>
  <?php include 'body.php'; ?>
  <?php include '../scripts.php';?>
  <script src="./js/app.js"></script>
</body>
</html>