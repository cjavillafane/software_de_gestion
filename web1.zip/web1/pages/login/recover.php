<?php 
  $recover= $_GET["recover"]; 
  include "../php/conexion.php";
  $conexion=conexionBD();
  $sql="SELECT CASE WHEN EXISTS(SELECT 1 FROM usuarios WHERE recover=$recover AND estado='A') THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END";
  $result=pg_query($conexion,$sql);
  if (!$result){
    die("Error, no se ejecutó la consulta 1.");
    exit;
  }else{
    $res= pg_fetch_result($result,0);
    
    if ($res){
      /* echo "correcto"; */
    }else{
      header( 'Location: ./index.php');
    }
  };
  desconectarBD($conexion);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
  <meta name="description" content="descripcion">
  <meta name="keywords" content="login">
  <meta name="author" content="Vargas Elias Gustavo">
  <title>Cambio de clave</title>
  <link rel="shortcut icon" href="../../images/images.jpg" type="image/jpg">
  <?php include '../links.php'; ?>
  <link rel="stylesheet" href="./css/style.css">
</head>
<body>
  <div class="uk-container-large" >
    <div class="uk-flex uk-height-medium  uk-margin" style="padding: 5px;"> 
      <div class=" uk-position-center uk-margin-auto uk-margin-auto-vertical uk-card uk-card-default uk-card-body uk-width-1-1 uk-width-1-3@s uk-width-1-3@m uk-width-1-4@l uk-width-1-5@xl">
        <center>
       
          <h4>Cambiar Clave </h4>        
          <div class="uk-margin-auto">
            <div class="uk-inline uk-width-1-1">
<!--               <a class="uk-form-icon uk-form-icon-flip" uk-icon="icon: lock" href="#" id="btnPassword" tabindex="5"></a>
 -->              <input id="inpNewPassword"class="uk-input" type="password" placeholder="Nuevo Password" tabindex="2">
            </div> 
          
            <p></p>
            <div class="uk-inline uk-width-1-1">
<!--               <a class="uk-form-icon uk-form-icon-flip" uk-icon="icon: lock" href="#" id="btnPassword" tabindex="5"></a>
 -->              <input id="inpRepeatPassword"class="uk-input" type="password" placeholder="Repetir Password" tabindex="2">
            </div>  
            <p></p>    
          
          </div>
        
          <button id='btnChangePassword' class="uk-button uk-button-secondary uk-width-1-1 uk-margin-small-bottom"  tabindex="3">Cambiar</button>

        </center>
      </div>
    </div>
  </div>
  
  <?php include '../scripts.php';?>
  <!-- <script src="./js/app.js"></script> -->
  <script>
  (function( window, undefined ){ 
    document.getElementById("btnChangePassword").addEventListener("click",function(){
      let password=valPassword("inpNewPassword"),
      repeatPassword=valPassword("inpRepeatPassword");
      if (password.valor === repeatPassword.valor) {
        if (!password.error && !repeatPassword.error ){
  
        }else{
  
        }
      }else{
        addError("inpRepeatPassword");
      }
    });
    
    document.querySelector(".uk-input").addEventListener("change",function(event){
      alert("paso");
    clearError(event.target.id);
    });
  })( window );
    
  
  </script>
</body>
</html>