<div id="modPassword" uk-modal>
  <div class="uk-modal-dialog uk-modal-body">
    <button class="uk-modal-close-default" type="button" uk-close></button>
    <h2 class="uk-modal-title">Recuperar password</h2>
    <div class="uk-inline uk-width-1-1">
      <span class="uk-form-icon uk-form-icon-flip"><i class="far fa-envelope fa-lg"></i></span>      
      <input id="inpMailRecover"class="uk-input" type="text" placeholder="Ingrese email"> 
    </div>
    <p></p>
    <p class="uk-text-right">
      <button class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
      <button class="uk-button uk-button-secondary" type="button" id="btnRecuperar">Enviar</button>
    </p>
  </div>
</div>