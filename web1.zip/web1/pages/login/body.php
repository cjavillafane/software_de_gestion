<div class="uk-container-large" >
  <div class="uk-flex uk-height-medium  uk-margin" style="padding: 5px;"> 
    <div class=" uk-position-center uk-margin-auto uk-margin-auto-vertical uk-card uk-card-default uk-card-body uk-width-1-1 uk-width-1-3@s uk-width-1-3@m uk-width-1-4@l uk-width-1-5@xl">
      <center>
        <h4>Iniciar sesión</h4>        
        <div class="uk-margin-auto">
          <div class="uk-inline uk-width-1-1">
            <span class="uk-form-icon uk-form-icon-flip" uk-icon="icon: user"></span>
            <input id="inpUser"class="uk-input" type="text" placeholder="usuario" tabindex="1"> 
          </div>
          <p></p>
          <div class="uk-inline uk-width-1-1">
            <a class="uk-form-icon uk-form-icon-flip" uk-icon="icon: lock" href="#" id="btnPassword" tabindex="5"></a>
            <input id="inpPassword"class="uk-input" type="password" placeholder="Password 8 a 16 (Letras y Numeros)" tabindex="2">
          </div>  
          <p class="uk-text-center">
            <button class="uk-button uk-button-text uk-button-small" uk-toggle="target: #modPassword" tabindex="6">¿Olvidaste tu password?</button>
          </p>        
        
        </div>
        <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
          <label><input class="uk-checkbox" type="checkbox" tabindex="7" id="inpRecuerdame"> Recuerdame</label>         
        </div>
        <button class="uk-button uk-button-secondary uk-width-1-1 uk-margin-small-bottom" id='btnLog' tabindex="3">Ingresar</button>
        <button class="uk-button uk-button-default uk-width-1-1 uk-margin-small-bottom" id="btnReg" uk-toggle="target: #modRegister" tabindex="4">Registrarse</button>

      </center>
    </div>
  </div>
</div>

<?php include './modalRegister.php'; ?>
<?php include './modalPassword.php'; ?>