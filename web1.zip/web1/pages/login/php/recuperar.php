<?php 
  /* error_reporting(0); */
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;
  use PHPMailer\PHPMailer\Exception;
  if ($_SERVER["REQUEST_METHOD"] == "POST"){ 
    include '../../php/conexion.php';

    $conexion=conexionBD();
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents('php://input'), true);    
    $email =$data["email"];
    echo $email;
    $sql= "SELECT idusuario,nombre FROM usuarios WHERE emailext='$email' AND estado='A'";
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('0');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo '0';
      }else{                      
       /*  $array=array(); */
        while ($row = pg_fetch_array($result)) {
          $idusuario = $row["idusuario"]; 
          $nombre= $row["nombre"];           
        };
        mt_srand (time());
        $aleatorio=mt_rand(1000000,999999999);
        /* echo json_encode($array);
        echo $array['idusuario']; */
        $ssql = "UPDATE usuarios SET recover=$aleatorio WHERE  idusuario=$idusuario";
        $update=pg_query($conexion,$ssql);

       
        $url= "http:destino.php?idusuario=$idusuario&=$aleatorio";

        require_once('../../../library/PHPMailer-master/src/PHPMailer.php');
        require_once('../../../library/PHPMailer-master/src/SMTP.php');
        require_once('../../../library/PHPMailer-master/src/Exception.php');
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 465;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "ssl";
        $mail->Username = 'departamentodesarrollo.gis@gmail.com';
        $mail->Password = 'milk2k1Sat';
        $mail->SetFrom('departamentodesarrollo.gis@gmail.com', 'Gustavo Vargas');
        $mail->AddReplyTo("departamentodesarrollo.gis@gmail.com","Nombre completo");
        $mail->Subject = "Envío de email usando SMTP de Gmail";
        $mail->MsgHTML('
        <p style="text-align: right;"><br>
        <table contenteditable="true" style="width: 71.134%; height: 40px; margin-left: 14.0893%;" class="main-element">
        <tbody>
          <tr>
          <td style="text-align: left;">
          <strong>
          <span style="font-family: Tahoma, Geneva, sans-serif; font-size: 30px;">Hola '.$nombre.'</span>
          </strong><br>
          <p style="margin: 20px 0px; color: rgb(102, 102, 102); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Recibimos una solicitud de recuperación de contraseña</p>
          <p style="margin: 20px 0px; color: rgb(102, 102, 102); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Si usted no solicito esta modificación ignore por completo este mensaje.</p>
          <p style="margin: 20px 0px; color: rgb(102, 102, 102); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Para poder modificar su contraseña es necesario que haga clic en el botón</p>
          <p style="margin: 20px 0px; color: rgb(102, 102, 102); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;"><br></p>
          <p style="margin: 20px 0px; color: rgb(102, 102, 102); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; font-size: 16px;">
            <table contenteditable="true" style="width:100%;text-align:center;height:40px;" class="main-element">
            <tbody>
          <tr>
          <td>
          <span style="font-family: Helvetica, sans-serif;"><strong>
          <a contenteditable="true" style="padding: 5px 10px; border: 1px solid rgb(0, 0, 0); background-color: rgb(109, 158, 235); color: rgb(243, 243, 243);" class="main-element" href="http://'.'destino.php?idusuario=$idusuario&=$aleatorio'.'" target="_blank">Recuperar</a>
          </strong>
          </span>
          </td>
          </tr>
          </tbody>
          </table>
          </p>
          <p style="margin: 20px 0px; color: rgb(102, 102, 102); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;"><br></p></td></tr></tbody></table></p>
            <p><br></p>
        ');
        $mail->addAddress("$email","$nombre");
        if (!$mail->send()){
          echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
          echo 'Mensaje enviado a'.$mail ;
        };

      };
    };
    pg_free_result( $result );
    pg_close($conexion);
  };  


?>