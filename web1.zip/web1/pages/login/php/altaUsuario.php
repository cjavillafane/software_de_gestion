<?php
  //error_reporting(-1);
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    include '../../php/conexion.php';
    $conexion=conexionBD();
    header('Content-Type: application/json');
    $datos = json_decode(file_get_contents('php://input'), true);
    
    $usuario  =   $datos['usuario'];
    $agencia  =   $datos['agencia'];
    $emailInt =   $datos['emailInt'];
    $email    =   $datos['email'];
    $nombre   =   $datos['nombre'];
    $password =   $datos['password'];

    $sql="SELECT CAST (count(idusuario) AS BIT) FROM usuarios WHERE idusuario=$usuario";
    $result=pg_query($conexion,$sql);
    if (!$result){
      die("Error, no se ejecutó la consulta 1.");
    }else{
      $existe= pg_fetch_result($result,0);      
      if (!$existe){  
        $sqlInsert ="INSERT INTO usuarios (idusuario,nombre,password,emailint,emailext,fecha_alta,agencia)
        VALUES ($usuario,'$nombre','$password','$emailInt','$email',CURRENT_DATE,$agencia);";
        $resul=pg_query($conexion,$sqlInsert);
        echo 0;
        /* echo json_encode($resul); */
      }else{
        echo 1;
        /* echo json_encode('Existe'); */
      }

    }
    
    desconectarBD($conexion);
  };
?>