$(document).ready(function(){

  function stlSelect(color){
    return{
      fillOpacity: 0.2,
      fillColor:color,
      weight:4,
      color:color
    }
  };

  /*Crear representacion geoJson parcela*/
  /* function popupParcelas(feature,layer){
    layer.bindPopup(feature.properties.inm_cod);
  };
  var shpParcelas= L.geoJSON('',{
    style:stlSelect('#34D624'),
    onEachFeature:popupParcelas
  }).addTo(map); */

  /*Crea representacion de geojson Regiones*/
  /* function popupRegion(feature,layer){
    layer.bindTooltip(feature.properties.name);
  };
  var shpRegiones=L.geoJSON('',{
    style:stlSelect('#D35400'),
    onEachFeature: popupRegion
  }).addTo(map);
 */
  /**********************************  Control Input de Busqueda***************************************/
  let inpSearch=  document.getElementById('inpSearch');
  inpSearch.addEventListener('keypress',function(e){
    if (e.keyCode == 13) {      
      var data=ValSearchMap(document.getElementById('inpSearch').value);
      if(data.error){
        alertMessage(data.error,'error');
      }else{
        alertMessage('Analizando consulta.....','info');
        if (data.consulta.length >= 1){
          switch(data.metodo){
            case 'C':
              sqlCuentas(data);
            break;
            case 'P':
              geomJsonPadron(data.consulta); 
            break;
            case 'M':
              geomJsonMedidor(data.consulta);          
            break;
            case 'CC':
              geomJsonCodCli(data.consulta);              
            break;
            case 'B':
              geomJsonBarrio(data.consulta);
            break;
            case 'D':
              geoJsonDireccion(data.consulta);
            break;
            case 'DT':
              geomJsonDni(data.consulta,'T');
            break;
            case 'DU':
              geomJsonDni(data.consulta,'U');
            break;
  
          };
        }else{
          alertMessage('Consulta vacia','error');        
        };
      };
  }
    return false;
  });
  let sqlCuentas = (data) =>{
      let sql='';       
      data.consulta.forEach(e => {
        sql=sql+"( inm_dist="+e.dist+" AND cuentas.inm_cta="+e.cta+ " AND cuentas.inm_scta="+e.subcta+" ) OR ";
      });
      let hasta=sql.length-4
      sql=sql.slice(0,hasta);          
      geomJsonCuentas(sql);          
  };
  let geomJsonCuentas = (sql) =>{ 
    fetch ('./php/geomJsonCuentas.php', {
      method: 'POST',
      body:JSON.stringify(sql),
      headers: {'Content-Type': 'application/json'}      
    })
    .then((response) => response.json())
    .then( json => {
      if (json!==""){
        alertMessage('Localizando Cuentas','success');             
        dibujarJson(JSON.parse(json));     
      }else{
        alertMessage('Cuenta/s No Localizada/s','error');  
      } 
    })
    .catch((error) => {
      alertMessage('Error en la consulta de Cuenta : '+error,'error');
    })
  }
  let geomJsonPadron = (padrones) =>{  
    fetch ('./php/geoJsonPadron.php',{
      method:'POST',
      body:JSON.stringify(padrones),
      headers: {'Content-Type': 'application/json'}
    })
    .then((response) => response.json())
    .then( json => {   
      if (json!==""){
        alertMessage('Localizando Padron','success');             
        dibujarJson(JSON.parse(json));     
      }else{
        alertMessage('Padron No Localizada','error');  
      } 
    })
    .catch((error)=> {
      alertMessage('Error en la consulta de padrones : '+error,'error');
    }) 
  }
  let geomJsonMedidor = (medidores) => {   
    fetch ('./php/geoJsonMedidor.php',{
      method:'POST',
      body:JSON.stringify(medidores),
      headers:{'Content-Type': 'application/json'}
    })
    .then (response => response.json())
    .then ( json => {      
      if (json!==""){
        alertMessage('Localizando Medidor','success'); 
        console.log(json);
        debugger;              
        dibujarJson(JSON.parse(json));     
      }else{
        alertMessage('Medidor No Localizado','error');  
      } 
    })
    .catch( error => {
      alertMessage('Error en la consulta de medidores : '+error,'error');
    })
  };  
  
  let geomJsonCodCli =(clientes) => {
    fetch ('./php/geoJsonCliente.php',{
      method: 'POST',
      body: JSON.stringify(clientes),
      headers:{'Content-Type': 'application/json'}
    })
    .then (response => response.json())
    .then (json => {
      if (json!==""){
        alertMessage('Localizando Cliente','success');   
        dibujarJson(JSON.parse(json));     
      }else{
        alertMessage('Cliente No Localizado','error');  
      } 
    })
    .catch( error => {
      alertMessage('Error en la consulta de clientes : '+error,'error');
    })

  };
  let geomJsonBarrio = (barrios) => {
    fetch ('./php/geoJsonBarrio.php',{
      method: 'POST',
      body: JSON.stringify(barrios),
      headers:{'Content-Type': 'application/json'}
    })
    .then (response => response.json())
    .then (json => {     
      if (json!==""){
        alertMessage('Barrio/s Localizado/s ','success');      
        dibujarBarrios(JSON.parse(json));
      }else{
        alertMessage('Barrio/s No Localizado/s','error');  
      } 
    })
    .catch (error => {
      alertMessage('Error en la consulta de Barrios : '+error,'error');
    })

  }
  let geoJsonDireccion = (arrayDirecciones) =>{
    arrayDirecciones.forEach(direccion => {      
      let url="https://nominatim.openstreetmap.org/search.php?"+direccion
      fetch (url,{
        method:'GET'
      })
      .then (response => response.json())
      .then (json => {
        if(json.features.length){
          /*   json.features.forEach ((punto) => {
              console.log(punto)
            }) */
            console.log(json)
            dibujarDireccion(json);
        }else{
          console.log("no es posible encontrar la direccion")
        }
      })
      .catch (error => {
        console.log(error);
      })
    });
  }
  let geomJsonDni = (dni,tipo ) => {
    fetch ("./php/geoJsonDni.php",{
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',  // sent request
        'Accept':       'application/json'   // expected data sent back
      },
      body: JSON.stringify({dni:dni,tipo:tipo}),
    })
    .then (response => response.json())
    .then (json => {
      if (json!==""){
        alertMessage('Localizando Cliente','success');   
        dibujarJson(JSON.parse(json));     
      }else{
        alertMessage('Cliente No Localizado','error');  
      } 
    })
    .catch (error => {
      console.log('error en php');
    })


  }

  let dibujarJson = (json) => {
    shpTerreno.clearLayers();  
    shpTerreno.addData(json);         
    map.fitBounds(shpTerreno.getBounds());
  }

  
  let dibujarBarrios = (json) => {
    shpBarrio.clearLayers();  
    shpBarrio.addData(json);     
   console.log(json)
    map.fitBounds(shpBarrio.getBounds());
  }


  let dibujarDireccion = (json) => {
    shpDireccion.clearLayers();
    shpDireccion.addData(json);
    map.fitBounds(shpDireccion.getBounds());
  }


  




});