$(document).ready(function(){

 
  var selectAgencia=document.getElementById("selAgencia");
  selectAgencia.value=agencia;
  document.getElementById('spanAgencia').innerHTML=selectAgencia.textContent;

  var MonitoreoCuentas = (codUsuario,agencia) => {
    document.getElementById('userLabel').innerHTML=userName;
    if(codUsuario){
      if(rol==1){
        selectAgencia.disabled = false;
      } else {
        selectAgencia.disabled = true;
      }

      fetch ('./php/CantCuentas.php',{
        method: 'POST', 
        headers: {
          'Content-Type': 'application/json',  // sent request
          'Accept':       'application/json'   // expected data sent back
        },
        body:JSON.stringify({codUsuario:codUsuario,agencia:agencia})        
      })
      .then ( response => response.ok ? response.json() : Promise.reject(response))
      .then ( json => {
        if (json!=""){
          let data=json[0];
          document.getElementById("nroGis").innerHTML= data.cta_gis;
          document.getElementById("nroNoGis").innerHTML=data.cta_nogis;
         }
      })
      .catch ( error => console.log('Se produjo un error: '+error))
    }
  
   
  };
  MonitoreoCuentas(codUsuario,agencia);
 
  selectAgencia.addEventListener("change",(event)=>{
    MonitoreoCuentas(codUsuario,event.target.value)
  })

  var mapBase= satelital.addTo(map);
  cuentasWMS.addTo(map);
  callesWMS.addTo(map);
/*   Evento en el mapa */
  map.on('zoomstart zoom zoomend', function(ev){
    document.getElementById("txtZoom").innerHTML="Zoom: "+ map.getZoom();    
    
  })
  map.on( 'moveend', function(ev){
    let coordenadas= map.getCenter();
    document.getElementById("txtCoordenadas").innerHTML=" - Lat: "+coordenadas.lat.toFixed(5)+" Long: "+coordenadas.lng.toFixed(5)
  })
  document.getElementsByClassName( 'leaflet-control-attribution' )[0].style.display = 'none'; 

  /*Control de Mapa Base*/
  $('#frmMapBase input[type=radio][name="radMapaBase"]').change(function() {        
    map.removeLayer(mapBase);
    var op=$(this).val();
    if  (op=="0"){        
      mapBase = satelital.addTo(map);     
    }if (op=="1"){        
      mapBase = blancoNegro.addTo(map);     
    }if (op=="2"){        
      mapBase = negro.addTo(map);
    }if (op=="3"){        
      mapBase = openStreetMap.addTo(map);
    }if (op=="4"){        
      mapBase = lineas.addTo(map);
    }if (op=="5"){
      mapBase = google.addTo(map);
    }
  });
  /*Control Capas Sat-Sapem*/
  $('#frmShpSat input[type=checkbox]').change(function(){
    var capaName=$(this).attr('name');
    var estado=$(this).prop( "checked");   
    var variable=eval(capaName);
    if (estado){    
      variable.addTo(map);
    }else{
      map.removeLayer(variable);     
    }   
  });
  /*Control Capas Catastro*/
  $('#frmShpCat input[type=checkbox]').change(function(){
    var capaName=$(this).attr('name');    
    var estado=$(this).prop('checked');  
    var variable=eval(capaName);  
    if (estado){
      variable.addTo(map);
    }else{
      map.removeLayer(variable);
    }
  })

  // define los geoJSON en leaflet
  

  // une todos los elemento de la capa 
 

 
 /*  clusterEscPublic.addTo(map); */
/*  clusterEscPriv.addTo(map);
 */ /*  map.addLayer(markers); */
  // Actualizacion de contenido popup

  
  document.getElementById("btnDatos").addEventListener("click",function(){
    alert("datos");
  })
  

});
function dibujarLinea (e,arrLine){
  let location= e.latlng;  
  let arrlatlng=[location.lat,location.lng];
  arrLine.push(arrlatlng);
  console.log(arrLine);
  var polyline = L.polyline(arrLine, {color: 'red'}).addTo(map);
};
document.getElementById("linea").addEventListener("click",function(){
  UIkit.offcanvas("#mobile-navbar").hide();
 /* let arrLine=[];
  map.on('click',function (e){
    dibujarLinea (e,arrLine)
  });*/
});
/* se cargan las geometrias al Mapa */
let AreaDraw= L.geoJson('',{style:stlArea}).addTo(map);
let lineaDraw=L.geoJson('',{style:stlArea}).addTo(map);
//let arrArea=[];
let arrPuntos=[];
let arrLineas=[];
let arrPerimetro=0;
function dibujarArea(array){
  areaMensura.features[0].geometry.coordinates[0]=array.slice();
  AreaDraw.clearLayers();  
  AreaDraw.addData(areaMensura);
  console.log(areaMensura);
  //areaMen.addTo(map);
}
function dibujarLinea(array,tipo){
  let total= array.length;
  if (total >1){
    let linea=[];
    let lineaCierre=[];
    let templine,longCierre,longLinea;

    if (tipo='C'){
      if (total>3){

        map.removeLayer(arrLineas[total-1]);        
        console.log(arrLineas[total-1]);
     
        arrLineas.pop();
      }
      if (total>=3){
        lineaCierre=[array[0],array[total-1]];
        longCierre=distanciaGeometrica(array[0],array[total-1]);
      }
    }
    linea=[array[total-2],array[total-1]]; 
    longLinea=distanciaGeometrica(array[total-2],array[total-1]);
    templine=L.polyline(linea,{color:'white', weight: 10,  opacity: .7,}).addTo(map) ; 
    templine.setText(longLinea+' m',{center: true, offset:3,attributes:{style : "font-size:10px;"}});
    arrLineas.push(templine);
    if (lineaCierre !== []){
      templine= L.polyline(lineaCierre,{color:'white', weight: 10,  opacity: .7}).addTo(map);
      templine.setText(longCierre+' m',{center: true, offset:3,attributes:{style : "font-size:10px;"}});
      arrLineas.push(templine);
    }
  }
  
  
}
function dibujarPunto(point){
  let punto=L.circleMarker(point,{"radius": 5})
  arrPuntos.push(punto);    
  punto.addTo(map);
}
function calcularPerimetro(array){
  lineaMensura.features[0].geometry.coordinates[0]=array.slice();
  let perimetro=turf.length(lineaMensura)*1000
  return perimetro.toFixed(2);
}
document.getElementById("poligono").addEventListener("click",function(){ 
  //global mensura;
  const listMen= new ListNodes();


  let mensuraLngLat=[];
  let mensuraLatLng=[];
  arrLineas=[];
  arrPuntos=[];
  arrPerimetro=0;
  UIkit.offcanvas("#mobile-navbar").hide();


  arrPuntos.forEach(function (punto){
    punto.clearLayers(); 
  })
 // arrArea=[];


  map.on('click',function (e){


   // let arrLinea=[];


    let location= e.latlng;   
    listMen.push(location);
    console.log(listMen);
   /*  console.log(listMen.total()); */


    mensuraLngLat.push([location.lng,location.lat]); //gjson
    mensuraLatLng.push([location.lat,location.lng]); //layer
    //dibujarPunto(location);
    dibujarLinea(mensuraLatLng,'C');
    //Determinar tipo de mensura
    if (mensuraLngLat.length>=3){
      //Area
      let area=mensuraLngLat.slice();
      area.push(mensuraLngLat[0]);      
     
      //dibujarArea(area);
      //Perimetro
      console.log (calcularPerimetro(area));
    
     
    }else{      
    }



    //let arrCoordenadas=[location.lng,location.lat];
    // console.log(location);
    /* puntoMenura.addData(arrCoordenadas); */
    /*arrArea.push(arrCoordenadas); 
    arrPuntos.push(L.circleMarker(location,{"radius": 5}));    
    arrPuntos[arrPuntos.length-1].addTo(map);

   // console.log("arrPuntos:");
    //console.log(arrPuntos);
    arrLinea=arrArea.slice();
    
    if (arrLinea.length>2){    
      arrLinea.push(arrArea[0])
    };
    //console.log(arrLinea);
    //console.log(arrArea);

    /* areaMensura.features[0].geometry.coordinates[0]=arrArea.slice(); */

   /* lineaMensura.features[0].geometry.coordinates[0]=arrLinea.slice();*/
    //console.log(lineaMensura);

   /*  let area =turf.area(areaMensura);   */  
/*     let line = turf.lineString(arrLinea); */
 /* let perimetro = turf.length(lineaMensura); 
  console.log(perimetro*1000);*/
/*  console.log('Area:'+area+' Perimetro:'+perimetro); */


    /* let perimetro= turf.length(mensuraGeoJson,{units: 'miles'}); */
/*     console.log(area.toFixed(2)); */
   
/*     AreaDraw.clearLayers();  
    // AreaDraw.addData(areaMensura); */
    /*lineaDraw.clearLayers();  
    lineaDraw.addData(lineaMensura);*/
  });
  map.on('contextmenu',function(e){
    
     map.off('click');
   });

});
document.getElementById("irGoogle").addEventListener("click",function(){
  UIkit.offcanvas("#mobile-navbar").hide();
  map.on('click', function(e) {        
    var location= e.latlng;
    var coordenada = new L.LatLng(location.lat, location.lng);
    let googleMap="https://www.google.com.ar/maps/@"+location.lat+","+location.lng+","+100+"m/data=!3m1!1e3";
    let googleStreet="http://maps.google.com/maps?q=&layer=c&cbll="+location.lat+","+location.lng;
    let googleEarth="https://earth.google.com/web/@"+location.lat+","+location.lng+",0a,10000d";
    var body= 
    "<div class='uk-card uk-card-secondary uk-card-body '>"+
      "<h3 class='uk-card-title'>Ir a Mapas de Google</h3>"+
      "<p uk-margin>"+
        "<a class='uk-button uk-button-default uk-button-small' href='"+googleMap+"' target='_blank'><i class='fas fa-map-marked-alt'></i> Google Maps</a>"+
        "<a class='uk-button uk-button-default uk-button-small' href='"+googleStreet+"' target='_blank'><i class='fas fa-street-view'></i> Google Street</a>"+
        "<a class='uk-button uk-button-default uk-button-small' href='"+googleEarth+"' target='_blank'><i class='fas fa-globe-americas'></i> Google Earth</a>"+
      "</p>"+
    "</div>";
    iconMark.setLatLng(coordenada).bindPopup(body).addTo(map); 
    map.off('click');
  });
})

/*  */
