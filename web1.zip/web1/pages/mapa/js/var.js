// ACTIVAR CONTROLES DE MAPA
var opmap={
  zoomControl: false
};
//CREA EL MAPA, SETEA EL MAPA INICIALMENTE
var map=L.map('map', opmap).setView([-26.82, -65.22],9);


var urlWMS='http://186.122.179.6:8080/geoserver/sigSat/wms'; // WMS EN SERVIDOR PROPIO
var urlWMScat='http://www.catastrotucuman.gov.ar:8081/geoserver/dgc/wms'; // WMS EN CATASTRO
var espTrabajo='sigSat:'; // ESPACIO DE TRABAJO

//--------------------DEFINICION DE MAPAS BASE-------------------------/
var lineas = L.tileLayer('https://stamen-tiles-{s}.a.ssl.fastly.net/toner-lines/{z}/{x}/{y}{r}.{ext}', {
	attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
	subdomains: 'abcd',
	minZoom: 0,
  maxZoom:22,
	ext: 'png'
});
var negro = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png', {
	attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
	subdomains: 'abcd',
	maxZoom:22,
});
var blancoNegro = L.tileLayer('https://stamen-tiles-{s}.a.ssl.fastly.net/toner-background/{z}/{x}/{y}{r}.{ext}', {
	attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
	subdomains: 'abcd',
	minZoom: 0,
  maxZoom:22,
	ext: 'png'
});
var satelital = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
  attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
  maxZoom:22,
});

var openStreetMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  maxZoom:22,
});

var google= L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
  maxZoom: 22,
  subdomains: ['mt0', 'mt1', 'mt2', 'mt3']
});

//----------------------- DEFINO LOS WMS EN SERVIDOR PROPIO-----------------/
var manzanasWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 1,
  minZoom:14,
  maxZoom:24,    
  identify:false,    
}).getLayer(espTrabajo+"shp_manzanas");

var cuentasWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 1,
  maxZoom:24,
  minZoom:15,
  identify:false,
}).getLayer(espTrabajo+"cuentas_geom");
var callesWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:16,
  identify:false,
}).getLayer(espTrabajo+"calles_geom");
var IndefinidasWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shp_missing");
var departamentosWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 1,
  maxZoom:24,    
  identify:false,    
}).getLayer(espTrabajo+"shp_departamentos");

var distritosWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 1,
  maxZoom:24,    
  identify:false,    
}).getLayer(espTrabajo+"shp_DistAge");

var barriosWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 1,
  maxZoom:24,
  minZoom:12,
  identify:false,
  zIndex:99999999,
}).getLayer(espTrabajo+"shp_barrios");




/* DINAMICAS */
var clientesNRWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shpnr");

var baldiosWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shp_baldios");

var obrasWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shp_obras");

var medidoresWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shp_medidores");

var serviciosWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shp_servicios");  

var phWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shp_ph");

var demolicionWMS = L.WMS.source(urlWMS, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.7,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer(espTrabajo+"shp_demolicion");

//-------------DEFINIMOS CAPAS WMS DE CATASTRO ------------------------/
var padronWMS = L.WMS.source(urlWMScat, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.8,
  maxZoom:24,
  identify:false,
}).getLayer("dgc:PARCELAS");
var edificaWMS = L.WMS.source(urlWMScat, {          
  format: 'image/png',
  transparent: true,
  opacity: 0.8,
  maxZoom:24,
  identify:false,
}).getLayer("dgc:EDIFICIOS");
var piletasWMS = L.WMS.source(urlWMScat, {
  format: 'image/png',
  transparent: true,
  opacity: 0.9,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer("dgc:PISCINAS");
var cotasWMS = L.WMS.source(urlWMScat, {
  format: 'image/png',
  transparent: true,
  opacity: 0.9,
  maxZoom:24,
  minZoom:14,
  identify:false,
}).getLayer("dgc:COTAS");

















const popupDireccion= (feature,layer)=>{
  layer.bindPopup(feature.properties.display_name);
}




//============================= CAPAS GEOJSON  =========================================

//===============RESPUESTA DE LA BUSQEU POR BARRIOS
function stlBarrios(feacture){ 
  return{
    fillOpacity: 0.2,
    fillColor:'#CE7C3C',
    weight:4,
    color:'#CE7C3C'
  }
};

const popupBarrio= (feature,layer) =>{ 

  let datos={inm_bar:feature.properties.inm_bar ,inm_dist:feature.properties.inm_dist};
  if (datos.inm_bar){
    console.log(datos);
    fetch ('./php/datosBarrio.php',{
      method: 'POST',
      body:JSON.stringify(datos),
      headers:{'Content-Type': 'application/json'} 
    })
    .then ( response => response.ok ? response.json() : Promise.reject(response))
    .then ( json => {      
      let headhtml=
        '<div class="uk-tile uk-tile-muted uk-padding-remove uk-text-center">'+
          '<p class="uk-h4" style="color:#2279E1; font-weight: bold;">Barri '+feature.properties.name+'</p>'+
        '</div><br>'+
        '<div class="uk-child-width-expand@s" uk-grid>'+  
          '<ul class="uk-list uk-list-collapse uk-list-divider ">'+          
            '<li class="uk-margin-remove uk-text-small">Total de Cuentas: '+json[0].total_cuentas+'</li>'+
            '<li class="uk-margin-remove uk-text-small">Cta Consumo Asignado: '+json[0].cuentas_asignado+'</li>'+
            '<li class="uk-margin-remove uk-text-small">Total : '+json[0].consumo_asignado+'</li>'+
            '<li class="uk-margin-remove uk-text-small">Cta Medidor: '+json[0].cuentas_medidores+'</li>'+          
            '<li class="uk-margin-remove uk-text-small">Total: '+json[0].consumo_medidores+'</li>'+
            '<li class="uk-margin-remove uk-text-small">Consumo Total: '+(parseInt(json[0].consumo_medidores)+parseInt(json[0].consumo_asignado))+'</li>'+
            /* '<li class="uk-margin-remove uk-text-small">CUIT/CUIL: '+json[0].usuario_cuil+'</li>'+
            '<li class="uk-margin-remove uk-text-small">Sup.Cub.: '+json[0].inm_supcub+'m -- Sup.Ter.: '+json[0].inm_supter+'m</li>'+            
            '<li class="uk-margin-remove uk-text-small">Consumo Asignado: <h6 style="color:#23EFF5; display:inline; font-weight: bold;">'+json[0].iad_bc+'</h6></li>'+
            '<li class="uk-margin-remove uk-text-small">Medidor/es: <h6 style="color:#23EFF5; display:inline; font-weight: bold;">'+json[0].medidores+'</h6></li>'+             */
          '</ul>'+       
        '</div>';       
        layer.bindPopup(headhtml);  
    })
    .catch ( error => {
      console.log(error);
    })
  } 
  layer.bindTooltip(feature.properties.name.toString(), { permanent: true,className: 'classEtiquetaJson', direction: 'center' });
}

let shpBarrio= L.geoJSON('',{
  style:stlBarrios,
  onEachFeature:popupBarrio,  
}).addTo(map);

//===============RESPUESTA DE BUSQUEDA DE CUENTAS
function stlParcelas(feacture){
  return{
    fillOpacity: 0.2,
    fillColor:'#34D624',
    weight:4,
    color:'#34D624'
  }
}

const popupTerreno= (feature,layer) =>{   //CREA EL POPUP 
  let inm_cod= feature.properties.inm_cod;
  console.log(inm_cod);
  let headhtml=
  '<div class="uk-tile uk-tile-muted uk-padding-remove uk-text-center">'+
    '<p class="uk-h4" style="color:#2279E1; font-weight: bold;">Datos de la parcela</p>'+
  '</div><br>';
  
  layer.bindPopup(headhtml+' <br>'+feature.properties.key);
  if (inm_cod!='null'){
      fetch ('./php/datosCuenta.php',{
        method:'post',
        body:inm_cod      
      })
      .then ( response => response.ok ? response.json() : Promise.reject(response))
      .then ( json => {
        if (json!==''){
          let bodyhtml=
          '<div class="uk-child-width-expand@s" uk-grid>'+  
            '<ul class="uk-list uk-list-collapse uk-list-divider ">'+          
              '<li class="uk-margin-remove uk-text-small">Cuenta: '+json[0].cuenta+'</li>'+
              '<li class="uk-margin-remove uk-text-small">Domicilio: '+json[0].inm_dom+'</li>'+
              '<li class="uk-margin-remove uk-text-small">Postal: '+json[0].inm_post+'</li>'+
              '<li class="uk-margin-remove uk-text-small">Titular: '+json[0].titular_nom+'</li>'+          
              '<li class="uk-margin-remove uk-text-small">CUIT/CUIL: '+json[0].titular_cuil+'</li>'+
              '<li class="uk-margin-remove uk-text-small">Usuario: '+json[0].usuario_nom+'</li>'+
              '<li class="uk-margin-remove uk-text-small">CUIT/CUIL: '+json[0].usuario_cuil+'</li>'+
              '<li class="uk-margin-remove uk-text-small">Sup.Cub.: '+json[0].inm_supcub+'m -- Sup.Ter.: '+json[0].inm_supter+'m</li>'+            
              '<li class="uk-margin-remove uk-text-small">Consumo Asignado: <h6 style="color:#23EFF5; display:inline; font-weight: bold;">'+json[0].iad_bc+'</h6></li>'+
              '<li class="uk-margin-remove uk-text-small">Medidor/es: <h6 style="color:#23EFF5; display:inline; font-weight: bold;">'+json[0].medidores+'</h6></li>'+            
            '</ul>'+       
          '</div>';     
          layer.bindPopup(headhtml+bodyhtml);  
        }
      })  
      .catch ((error)=> {
        console.log(error);
      })
    }   
}

let shpTerreno= L.geoJSON('',{
  style:stlParcelas,
  onEachFeature:popupTerreno
}).addTo(map);

//=============== PUNTO DE GEOCODING
var iconDireccion = L.ExtraMarkers.icon({
  icon:'fa-road',
  markerColor: 'orange-dark',
  shape: 'square',
  prefix: 'fa',
});
let shpDireccion=L.geoJSON('',{
  pointToLayer: function (feature, latlng) {
    return L.marker(latlng, {icon: iconDireccion});
  },
  onEachFeature:popupDireccion,
}).addTo(map);

// ==============CANON
let iconCanon = L.ExtraMarkers.icon({
  icon: 'fa-building',
  markerColor: 'yellow',
  shape: 'square',
  prefix: 'fa',
});
var canonShape= L.geoJSON(geoJsonCanon,{
  pointToLayer: function (geoJsonPoint, latlng) { 
    return L.marker(latlng, {icon: iconCanon});
  },
  onEachFeature:function(feature,layer){
    layer.bindPopup('',{maxWidth:300,minWidth:300,maxHeight:450})
  }
})
canonShape.eachLayer(function(layer){
  var inm_cod=layer.feature.properties.inm_cod;
  layer._popup.setContent('<iframe id="iframe" style="border:none; width:300px; height:450px" src="./canonConsulta.php?inm_cod='+inm_cod+'"></iframe>')
});
var shpCanon = L.markerClusterGroup({
  iconCreateFunction: function (cluster){
    var childCount = cluster.getChildCount();
    return new L.DivIcon({ 
      html: '<div><span>' + childCount + '</span></div>', 
      className: 'marker-cluster marker-cluster-yellow' , 
      iconSize: new L.Point(40, 40) 
    });
  }  
});
shpCanon.addLayer(canonShape);
// ==============ESTABLECIMIENTOS PUBLICOS
function poupEscPublic (feature, layer) {
  let popupContent = 
    "<div class='titulosPopup'>Escuela del Sector Publico<br></div>"+ 
    "<hr  class='hrx' style='color: #ef7d26;' align='left' noshade='noshade' size='2' width='100%' />"+
    "<div id='textBodyPopup'>"+
      "Establecimiento: " +  feature.properties.nombre + "<br>"+
      "Dirección: " + feature.properties.direccion + "<br>"+
      "Localidad: " +  feature.properties.localidad + "<br>"+
      "Departamento: " + feature.properties.departamen +"<br>"+
      "CUE: " + feature.properties.cue +
    "</div>";
			
	layer.bindPopup(popupContent);
}
let iconEscPublic=L.ExtraMarkers.icon({
  icon:'fa-school',
  markerColor:'cyan',
  shape: 'square',
  prefix: 'fa',
});
let shpEscPublic=L.geoJSON(geoJsonEscPublic,{
  onEachFeature:poupEscPublic,
  pointToLayer:function (feacture,latlng){
    return L.marker(latlng, {icon: iconEscPublic});
  }
});
let clusterEscPublic = L.markerClusterGroup({
  iconCreateFunction: function (cluster){
    var childCount = cluster.getChildCount();
    return new L.DivIcon({ 
      html: '<div><span>' + childCount + '</span></div>', 
      className: 'marker-cluster marker-cluster-cyan' , 
      iconSize: new L.Point(40, 40) 
    });
  }  
});
clusterEscPublic.addLayer(shpEscPublic);
// ==============ESTABLECIMIENTOS PRIVADOS
function poupEscPriv (feature, layer) {
  let popupContent = 
  "<div class='titulosPopup'>Escuela del Sector Privado<br></div>"+ 
  "<hr  style='color: #ef7d26;' align='left' noshade='noshade' size='2' width='100%' />"+
  "<div id='textBodyPopup'>"+
    "Establecimiento: " +  feature.properties.NOMBRE + "<br>"+
    "Dirección: " + feature.properties.DIRECCION + "<br>"+
    "Localidad: " +  feature.properties.LOCALIDAD + "<br>"+
    "Departamento: " + feature.properties.DEPARTAMEN +"<br>"+
    "CUE: " + feature.properties.CUE +
  "</div>";    
  layer.bindPopup(popupContent);
}
let iconEscPriv=L.ExtraMarkers.icon({
  icon:'fa-school',
  markerColor:'violet',
  shape: 'square',
  prefix: 'fa',
});
 let shpEscPriv=L.geoJSON(geoJsonEscPriv,{
  onEachFeature:poupEscPriv,
  pointToLayer:function (feacture,latlng){
    return L.marker(latlng, {icon: iconEscPriv});
  }
});
let clusterEscPriv = L.markerClusterGroup({
  iconCreateFunction: function (cluster){
    var childCount = cluster.getChildCount();
    return new L.DivIcon({ 
      html: '<div><span>' + childCount + '</span></div>', 
      className: 'marker-cluster marker-cluster-violet' , 
      iconSize: new L.Point(40, 40) 
    });

  }
  
});
clusterEscPriv.addLayer(shpEscPriv);
// ==============ORGANISMOS PUBLICOS
function poupOrganismos (feature, layer) {
  let popupContent = 
    "<div class='titulosPopup'>Organismos Publico<br></div>"+ 
    "<hr  class='hrx' style='color: #ef7d26;' align='left' noshade='noshade' size='2' width='100%' />"+
    "<div id='textBodyPopup'>"+
      "Nombre: " +  feature.properties.Nombre + "<br>"+
      "Dirección: " + feature.properties.Direccion + "<br>"+
      "Localidad: " + feature.properties.Localidad + "<br>"+
    "</div>";
			
	layer.bindPopup(popupContent);
}
let iconOrganismos=L.ExtraMarkers.icon({
  icon:'fa-building',
  markerColor:'blue',
  shape: 'square',
  prefix: 'fa',
});
let shpOrganismos=L.geoJSON(geoJsonOrganismos,{
  onEachFeature:poupOrganismos,
  pointToLayer:function (feacture,latlng){
    return L.marker(latlng, {icon:iconOrganismos});
  }
});
let clusterOrganismos = L.markerClusterGroup({
  iconCreateFunction: function (cluster){
    var childCount = cluster.getChildCount();
    return new L.DivIcon({ 
      html: '<div><span>' + childCount + '</span></div>', 
      className: 'marker-cluster marker-cluster-blue' , 
      iconSize: new L.Point(40, 40) 
    });

  }
  
});
clusterOrganismos.addLayer(shpOrganismos);
// ==============HOSPITALES
function poupHospitales (feature, layer) {
  let popupContent = 
    "<div class='titulosPopup'>Hospitales<br></div>"+ 
    "<hr  class='hrx' style='color: #ef7d26;' align='left' noshade='noshade' size='2' width='100%' />"+
    "<div id='textBodyPopup'>"+
      "Nombre: " +  feature.properties.nombre + "<br>"+
      "Dirección: " + feature.properties.direccion +    
    "</div>";			
	layer.bindPopup(popupContent);
}
let iconHospitales=L.ExtraMarkers.icon({
  icon:'fa-hospital',
  markerColor:'red',
  shape: 'penta',
  prefix: 'fa',
});
let shpHospitales=L.geoJSON(geoJsonHospitales,{
  onEachFeature:poupHospitales,
  pointToLayer:function (feacture,latlng){
    return L.marker(latlng, {icon:iconHospitales});
  }
});
// ==============ESTABLECIMIENTOS DE SALUD
function poupSalud (feature, layer) {
  let popupContent = 
    "<div class='titulosPopup'>Establecimientos de Salud<br></div>"+ 
    "<hr  class='hrx' style='color: #ef7d26;' align='left' noshade='noshade' size='2' width='100%' />"+
    "<div id='textBodyPopup'>"+
      "Nombre: " +  feature.properties.nombre + "<br>"+
      "Dirección: " + feature.properties.direccion +    
    "</div>";			
	layer.bindPopup(popupContent);
}
let iconSalud=L.ExtraMarkers.icon({
  icon:'fa-clinic-medical',
  markerColor:'orange-dark',
  shape: 'penta',
  prefix: 'fa',
});
let shpSalud=L.geoJSON(geoJsonSalud,{
  onEachFeature:poupSalud,
  pointToLayer:function (feacture,latlng){
    return L.marker(latlng, {icon:iconSalud});
  }
});
let clusterSalud = L.markerClusterGroup({
  iconCreateFunction: function (cluster){
    var childCount = cluster.getChildCount();
    return new L.DivIcon({ 
      html: '<div><span>' + childCount + '</span></div>', 
      className: 'marker-cluster marker-cluster-orange-dark' , 
      iconSize: new L.Point(40, 40) 
    });

  }
  
});

/* var markers = L.markerClusterGroup({
  maxClusterRadius: 120,
  iconCreateFunction: function (cluster) {
      var childCount = cluster.getChildCount();

    var c = ' marker-cluster-';
    if (childCount < 10) {
      c += 'small';
    } else if (childCount < 100) {
      c += 'medium';
    } else {
      c += 'large';
    }

    return new L.DivIcon({ html: '<div><span>' + childCount + '</span></div>', className: 'marker-cluster' + c, iconSize: new L.Point(40, 40) });
  },

  spiderfyOnMaxZoom: false, showCoverageOnHover: false, zoomToBoundsOnClick: false
}); */



clusterSalud.addLayer(shpSalud);

// ==============CIC
function poupCic (feature, layer) {
  let popupContent = 
    "<div class='titulosPopup'>Centro Integrador Comunitario<br></div>"+ 
    "<hr  class='hrx' style='color: #ef7d26;' align='left' noshade='noshade' size='2' width='100%' />"+
    "<div id='textBodyPopup'>"+
      "Nombre: " +  feature.properties.nombre + "<br>"+
      "Dirección: " + feature.properties.direccion +    
    "</div>";			
	layer.bindPopup(popupContent);
}
let iconCic=L.ExtraMarkers.icon({
  icon:'fa-briefcase-medical',
  markerColor:'cyan',
  shape: 'penta',
  prefix: 'fa',
});
let shpCic=L.geoJSON(geojsonCic,{
  onEachFeature:poupCic,
  pointToLayer:function (feacture,latlng){
    return L.marker(latlng, {icon:iconCic});
  }
});
//*****************************************//
/* let shpCanons=L.geoJSON('',{
  pointToLayer: function (feature, latlng) {
    return L.marker(latlng, {icon: iconDireccion});
  },
}).addTo(map); */






/* Creacion de ICONOS*/
var iconLocation = L.icon({
  iconUrl: '../../images/mark.png',
  iconSize:     [38, 52],
  iconAnchor:   [22, 52],
});
var iconMark=L.marker([0,0],{icon: iconLocation});
var puntoMensura=L.marker([0,0]);

var areaMensura={
  type:"FeatureCollection",
  name:"mensura",
  crs:{
    type:"name",
    properties:{
      name:"urn:ogc:def:crs:OGC:1.3:CRS84"
    }
  },
  features:[
    {
      geometry:{        
        type:"Polygon",
        coordinates:[]      
      },
      type:"Feature",
      properties: {
        area: 0, 
        perimetro:0         
      }
    }
  ]
};
let lineaMensura={
  type:"FeatureCollection",
  name:"mensura_lineal",
  crs:{
    type:"name",
    properties:{
      name:"urn:ogc:def:crs:OGC:1.3:CRS84"
    }
  },
  features:[
    {
      geometry:{        
        type: "MultiLineString",
        coordinates:[]      
      },
      type:"Feature",
      properties: {}
    }
  ]
};

/* mensuraGeoJson.features[0].geometry.coordinates.push(pol); */
function stlArea(feacture){
  return{
    fillOpacity: 0.2,
    fillColor:'#04BDDE',
    weight:4,
    color:'#04BDDE'
  }
}
function stlLinea(feacture){
  return{
    fillOpacity: 0.2,
    fillColor:'#F0FF01',
    weight:10,
    color:'#F0FF01'
  }
}
const popupLineas = (feacture,layer) => {
  //console.log(layer);
  layer.bindPopup("hola mundo"); 
}

class ListNodes {
  constructor (){
    this.head=null;//cabecera
    this.tail=null;//cola
    this.length=0;
  }
  lineDraw = ()=>{
    let elemt= this.head;
    while (elemt != null){
      console.log(elemt.coordenadas);
      if(elemt== this.head){
       alert("primero");
      }else{
        alert("restos");
      }
      elemt=elemt.next;
    }
    
  }
  push = (coordenadas)=>{
    const newNode= new Nodo(coordenadas);
    newNode.draw();
    if (this.length===0){
      this.head=newNode;
      this.tail=newNode;
    }else{
      this.tail.next =newNode;
      newNode.prev=this.tail;
      this.tail= newNode;
    }
    this.length++;
    newNode.name(this.length);//etiqueta los nodos
    this.lineDraw();
    return this;
  };
  
 
}
class Nodo{ 
  constructor(coordenadas){    
    this.label=0;
    this.coordenadas=coordenadas;
    this.next=null;
    this.prev=null;
    this.shpNodo=null;
  };
  name=(name)=>{
    this.label=name;
  }
  draw=()=>{
    this.shpNodo=L.circleMarker(this.coordenadas,{"radius": 20})     
    this.shpNodo.addTo(map);

  };
  erase=()=>{

  }
}
let locationCanon = () =>{   
  fetch ("php/geoJsonCanon.php",{  })
  .then (response => response.json())
  .then (json => {
    let can=JSON.parse(json);
 /*   shpCanons.clearLayers();
    shpCanons.addData(can);
    map.fitBounds(shpCanons.getBounds());  */
    console.log(json);
  })
  .catch (error => {
    console.log(error);
  });
  
}

locationCanon();



