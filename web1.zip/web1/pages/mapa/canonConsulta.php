<?php
	if (isset($_GET)){

	}else{
    exit; 
  }
	?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
  <meta name="description" content="descripcion">
  <meta name="keywords" content="lista de temas para el buscador">
  <meta name="author" content="Vargas Elias Gustavo">
  <title>pagina</title>

  <?php include '../links.php'; ?>
  <!-- <link rel="stylesheet" href="./css/style.css"> -->
  <style>
    * {
        margin: 0;
        padding: 0;
        border: 0;
        outline: 0;
        font-size: 100%;
        vertical-align: baseline;
        background: transparent;
    }
    body{
      background-color: #222;
      margin: 0;
      padding: 0;
      height: 100%;
     
    }
    .titulo{
     
      text-align:center;
      background-color: #5495CF;
      padding: 2px;
      color:black !important;
   
    }
    #btnGaleria{
      display:none;
    }
  </style>
</head>
<body  >
  <div class="uk-background-secondary uk-light uk-padding-small">
    <div class="titulo">
      <h5 style="margin:3px;color:#222;">Cargo Esp. por Infraestructura</h5>
      <h6 style="margin:3px;" id="ctaActual"></h6>
    </div>
    <hr>      
    <div id="listLiq" ></div>  
  </div>
  <center>
    <a  id="btnGaleria" class="uk-button uk-button-primary uk-button-small " href="#modalGalCanon" uk-toggle>Galeria</a>
  </center>
  <!-- Modal Galeria canon -->
  <div id="modalGalCanon" class="uk-modal-full" uk-modal>
    <div class="uk-modal-dialog">
      <button class="uk-modal-close-full uk-close-large" type="button" uk-close></button>
      <br>
      <br>
      <br>
      <div class="uk-grid-collapse uk-child-width-1-1@s uk-flex-middle" uk-grid>
<!--       <div uk-slideshow="animation: push">-->  
       <!-- <div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1"> -->
          <!-- <ul class="uk-slideshow-items"> -->
            <div id="galeriaCanon"></div>
          <!--   <li>
              <img src="images/photo.jpg" alt="" uk-cover>
            </li>
            <li>
              <img src="images/dark.jpg" alt="" uk-cover>
            </li>
            <li>
              <img src="images/light.jpg" alt="" uk-cover>
            </li> -->
         <!--  </ul> -->
<!--           <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>
          <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>
 -->        <!-- </div> -->
        <!-- <ul class="uk-slideshow-nav uk-dotnav uk-flex-center uk-margin"></ul> -->
     <!--  </div> -->
      </div>
      <br>
    </div>
  </div>
  
  <?php include '../scripts.php';?>
  <script>
    let inm_cod ='<?php echo $_GET["inm_cod"]; ?>';
    loadCanon(inm_cod);
    function loadImagenes(inm_cod){
      fetch('./php/searchFotos.php',{
        method:'POST',
        body:inm_cod
      })
      .then( response => response.ok ? response.json() : Promise.reject(response))
      .then(json =>{
        if(json!=="" && json.length>0){
         
          document.getElementById('btnGaleria').style.display='inline';
/*           console.log(document.getElementById('btnGaleria').classList.contains('uk-hidden'));
           document.getElementById('btnGaleria').classList.add ('uk-visible@s') ; */
           let galeria=
          '<div uk-slideshow="animation: push">'+
            '<div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1">'+
              '<ul class="uk-slideshow-items">'
          ;
          json.forEach ( foto=>{
          
            galeria+=
            '<li>'+
          /* `<img src="../../fotos/${foto.url}" alt="" uk-cover>`+ */
              `<img src="http://186.122.179.6/new/fotos/${foto.nom_archivo}" alt="" uk-cover>`+
              '<div class="uk-position-bottom uk-text-center">'+
                `<h5 uk-slider-parallax="x: 100,-100" class="uk-text-warning">${foto.fecha_foto}</h5>`+                    
              '</div>'+
            '</li>';
          });
          galeria+=
          '</ul>'+
          '<a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>'+
          '<a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>'+
          '</div>'+
          '<ul class="uk-slideshow-nav uk-dotnav uk-flex-center uk-margin"></ul>'+
          '</div>';
          document.getElementById("galeriaCanon").innerHTML=galeria
        }else{
          console.log('no posee imagenes')
        }
      })
      .catch()
    };
    function loadCanon(inm_cod){
     
      document.getElementById('btnGaleria').style.display="none";
/*          document.getElementById('btnGaleria').classList.remove ('uk-visible');*/
     
      fetch ('./php/searchCanon.php',{
          method: 'POST',      
          body:inm_cod       
        })
        .then ( response => response.ok ? response.json() : Promise.reject(response))
        .then ( json => {
           /* console.log(json); */
          if (json!==""){
            loadImagenes(inm_cod);
            
            document.getElementById("ctaActual").innerHTML= json[0].cuenta;
            let list='<ul uk-accordion="multiple: true">';
            json.forEach (liq => {
            /*   console.log(liq); */
              list +=
              '<li>'+
              `<a class="uk-accordion-title uk-text-small" href="#" ><i class="far fa-file-alt"></i> Liq. N° ${liq.num_liq} -  ${liq.fecha_liq}</a>`+
              '<div class="uk-accordion-content">'+
              '<hr>'+
              '<ul class="uk-list">'+
                  `<li><b>Cuenta liq.:</b> ${liq.cuenta_liq}</li>`+
                  `<li><b>Sup. Liq.:</b> ${liq.sup_liq} m2</li>`+
                  `<li><b>N° Recibo:</b> N° ${liq.nro_recibo}</li>`+
                  `<li><b>Fecha Recibo:</b> ${liq.fecha_recibo}</li>`+
                  `<li><b>Propietario:</b> ${liq.propietario}</li>`+
                  `<li><b>Obsevacion:</b> ${liq.observacion}</li>`+
              '</ul>'+
              '<hr>'+
              '</div>'+
              '</li>';         
            });
            document.getElementById("listLiq").innerHTML=list+'</ul>';
          } 
        })
        .catch ( error => console.log('Se produjo un error: '+error))
    }
  </script>
</body>
</html>