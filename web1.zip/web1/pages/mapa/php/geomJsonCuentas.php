<?php
  /* error_reporting(0); */
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    include '../../php/conexion.php';
    $conexion=conexionBD();
   /*  $sqlwhere=$_POST["sql"]; */
    header('Content-Type: application/json');
    $sqlwhere= json_decode(file_get_contents('php://input'), true);
    $sql="SELECT cuentas.inm_cod, cuentas_geom.key ,ST_AsGeoJSON(ST_Transform(cuentas_geom.geom,4326)) AS geom
      FROM cuentas
      JOIN cuentas_geom ON cuentas.idcuentas_geom=cuentas_geom.idcuentas_geom
      WHERE $sqlwhere";

  
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo json_encode('');
      }else{
        $str = '';
        $srt2= '';
        $str .= '{
        "type": "FeatureCollection",
        "name": "Busqueda",
        "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
        "features": [ ';
        while ($res = pg_fetch_array($result)) {
          $str .= '{
            "type": "Feature",
            "properties": {
              "inm_cod": "'.$res['inm_cod'].'", 
              "key": "'.$res['key'].'"   
            },
            "geometry":'.$res['geom'].'
          },';
        }   
        $str2 = substr($str,0,strlen($str)-1);     
        $str2 .= ']}';
        echo json_encode($str2);
      }      
    }
    pg_free_result( $result );
    pg_close($conexion);
  }; 
?>