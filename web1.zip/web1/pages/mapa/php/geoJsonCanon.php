<?php
    include '../../php/conexion.php';
    $conexion=conexionBD();    
    $str = '';
    $srt2= '';
    $band=false;
    $str .= '{
      "type": "FeatureCollection",
      "name": "Busqueda",
      "crs": { 
        "type": "name", 
        "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } 
      },
      "features": [ ';

      $sql="SELECT inm_cod,lat,lng,geom FROM shp_canon WHERE lat IS NOT NULL";
      $result=pg_query($conexion,$sql); 
      if (!$result){
        echo ('');                
      }else{
        if (pg_num_rows($result) != 0) {          
          while ($res = pg_fetch_assoc($result)) {
            $str .= '{
              "type": "Feature",
              "properties": {
                "inm_cod": "'.$res["inm_cod"].'"
              },
              "geometry":{
                "type":"Point",
                "coordinates": ['.$res["lat"].','.$res["lng"].']
                }
            },';
            $band=true;
          }          
        }
      } 
    header ('Content-type: application/txt');
    header ('Content-Disposition: attachment; filename="canonee.geojson"');

    if ($band){
      $str2 = substr($str,0,strlen($str)-1);     
      $str2 .= ']}';
      echo  json_encode($str2);  
    }else{
      echo json_encode('');
    }
    pg_free_result( $result ); 
    pg_close($conexion);
   
?>