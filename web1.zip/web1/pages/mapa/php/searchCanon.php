<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST"){
    header('Content-Type: application/json');
		$inm_cod=json_decode(file_get_contents('php://input'), true); 
 
    include '../../php/conexion.php';
    $conexion=conexionBD();
    $sql="SELECT (cuentas.inm_dist || '-' ||cuentas.inm_cta || '-' || cuentas.inm_scta) AS cuenta,(calles.calinm_nom||' N° '||domicilios.inm_nro)AS direccion,
    (SELECT distinct(cuentas.inm_dist || '-' ||cuentas.inm_cta || '-' || cuentas.inm_scta) AS cuenta_liq FROM bd_canon JOIN cuentas ON cuentas.inm_cod=bd_canon.inm_cod_liq WHERE bd_canon.inm_cod=$inm_cod)
    cuenta_liq,sup_liq,nro_recibo,to_char(fecha_recibo, 'dd/mm/yyyy')AS fecha_recibo,propietario,observacion,num_liq,to_char(fecha_liq, 'dd/mm/yyyy')AS fecha_liq FROM bd_canon 
    JOIN cuentas ON cuentas.inm_cod=bd_canon.inm_cod
    JOIN domicilios ON domicilios.inm_cod=cuentas.inm_cod
    JOIN calles ON calles.inm_cal=domicilios.inm_cal  
    WHERE bd_canon.inm_cod=$inm_cod AND domicilios.idestados='INMUEBLES'  ORDER BY fecha_liq,num_liq";
    $result=pg_query($conexion,$sql);    
		$list='';
    if( !$result )
    die("Error, no se ejecutó la consulta.");
	  else{ 
      $array=array();
		  while ( $data = pg_fetch_assoc($result)){
        $array[] = $data;   
	    }
      echo json_encode($array);
	  }	
    pg_free_result( $result );
		pg_close($conexion);	
	}else{
    exit; 
  }
	?>