<?php
  session_start();
  $_SESSION = array();
  if (ini_get("session.use_cookies")) {
      $params = session_get_cookie_params();
      setcookie(session_name(), '', time() - 42000,
          $params["path"], $params["domain"],
          $params["secure"], $params["httponly"]
      );
      echo 'paso por aqui';
  }
                                                  
  setcookie("usuario_ck",'',1);
  setcookie("usuario_ck",'',1,'/web1/pages/login');
  setcookie("marca_aleatoria_ck",'',1); 
  setcookie("marca_aleatoria_ck",'',1,'/web1/pages/login');
  session_destroy();
?>  