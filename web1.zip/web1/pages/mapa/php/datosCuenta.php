<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
/*     $inm_cod=$_POST["inm_cod"];  */
    include '../../php/conexion.php';
    $conexion=conexionBD();
    header('Content-Type: application/json');
    $inm_cod = intval(json_decode(file_get_contents('php://input'), true));  
    $sql="SELECT * FROM sat_buscar_datos($inm_cod)";
 /*    $sql="SELECT  concat(cuentas.inm_dist,'-',cuentas.inm_cta,'-',cuentas.inm_scta)AS cuenta,
    concat(calles.calinm_nom,' N° ',domicilios.inm_nro)AS inm_dom,
    (select concat(calles.calinm_nom,' N° ',inm_nro) from calles join domicilios on calles.inm_cal=domicilios.inm_cal where idestados='POSTALES' and inm_cod=$inm_cod) as inm_post,
    clientes.inm_nomcli AS titular_nom,concat(clientes.inm_digide,'-',clientes.inm_doc,'-',clientes.inm_digver) AS titular_cuil ,
    adicional.iad_nomusu AS usuario_nom,concat(adicional.iad_digide,'-',adicional.iad_doc_us,'-',adicional.iad_digver) AS usuario_cuil,
    adicional.iad_lote AS lote_fact,
    inmuebles.inm_supter,inmuebles.inm_supcub,
    adicional.iad_bc, array_agg(numero_medidor)as medidores 
  FROM cuentas
  JOIN domicilios ON domicilios.inm_cod=cuentas.inm_cod
  JOIN inmuebles ON inmuebles.inm_cod=cuentas.inm_cod
  JOIN calles ON calles.inm_cal=domicilios.inm_cal
  JOIN adicional ON adicional.inm_cod=cuentas.inm_cod
  JOIN clientes ON clientes.idclientes=cuentas.inm_cod
  LEFT JOIN medidores ON medidores.inm_cod=cuentas.inm_cod
  WHERE cuentas.inm_cod=$inm_cod AND domicilios.idestados='INMUEBLES'
  GROUP BY cuentas.inm_dist,cuentas.inm_cta,cuentas.inm_scta,clientes.inm_nomcli,clientes.inm_doc,adicional.iad_nomusu,adicional.iad_doc_us,adicional.iad_lote
    ,inmuebles.inm_supter,inmuebles.inm_supcub,calles.calinm_nom, domicilios.inm_nro,adicional.iad_bc,clientes.inm_digide,clientes.inm_digver,adicional.iad_digide,adicional.iad_digver
   "; */
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "";
      }else{                      
        $array=array();
        while ($row = pg_fetch_array($result)) {
          $array[] = $row;     
        }
        echo json_encode($array);
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  };
?>