<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    include '../../php/conexion.php';
    $conexion=conexionBD();
    
    /* $inm_dist=$_POST["inm_dist"]; 
    $inm_cta=$_POST["inm_cta"]; 
    $inm_scta=$_POST["inm_scta"];  */
    /* $sql="SELECT cuentas.inm_cod,ST_AsGeoJSON(ST_Transform(cuentas_geom.geom,4326)) AS geom
      FROM cuentas
      JOIN cuentas_geom ON cuentas.idcuentas_geom=cuentas_geom.idcuentas_geom
      WHERE (cuentas.inm_dist=123 AND cuentas.inm_cta=1234 AND cuentas.inm_scta=0) OR (cuentas.inm_dist=123 AND cuentas.inm_cta=789 AND cuentas.inm_scta=0)
    ";
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "";
      }else{
        $str = '';
        $srt2= '';
        $str .= '{
        "type": "FeatureCollection",
        "name": "Busqueda",
        "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
        "features": [ ';
        while ($res = pg_fetch_array($result)) {
          $str .= '{
            "type": "Feature",
            "properties": {
              "inm_cod": "'.$res['inm_cod'].'"    
            },
            "geometry":'.$res['geom'].'
          },';
        }   
        $str2 = substr($str,0,strlen($str)-1);     
        $str2 .= ']}';
        echo $str2; 
      }      
    } */
    pg_free_result( $result );
    pg_close($conexion);
  }; 
?>