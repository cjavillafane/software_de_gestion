<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
/*     $inm_cod=$_POST["inm_cod"];  */
    include '../../php/conexion.php';
    $conexion=conexionBD();
    header('Content-Type: application/json');
  /*   $inm_bar = json_decode($_POST['inm_bar'], true);
    $inm_dist = json_decode($_POST['inm_dist'], true);
    echo $inm_bar;
    echo $_POST['inm_dist']; */

     $datos = json_decode(file_get_contents('php://input'), true);
    
    $inm_bar=$datos['inm_bar'];
    $inm_dist=$datos['inm_dist'];
    $sql= "SELECT * FROM sat_consumos_barrio($inm_bar,$inm_dist)";

    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "";
      }else{                      
        $array=array();
        while ($row = pg_fetch_array($result)) {
          $array[] = $row;     
        }
        echo json_encode($array);
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  };
?>