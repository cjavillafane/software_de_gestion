<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
/*     $inm_cod=$_POST["inm_cod"];  */
    include '../../php/conexion.php';
    $conexion=conexionBD();
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents('php://input'), true);  
    $usuario=intval($data["codUsuario"]);
    $agencia=intval($data["agencia"]);
    $sql="SELECT * FROM sat_numero_agencia($agencia) ";
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "";
      }else{                      
        $array=array();
        while ($row = pg_fetch_array($result)) {
          $array[] = $row;     
        }
        echo json_encode($array);
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  };
?>