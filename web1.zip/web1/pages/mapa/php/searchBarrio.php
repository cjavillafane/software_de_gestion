<?php
  /* error_reporting(0); */
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $name=$_POST["name"]; 
    include '../../php/conexion.php';
    $conexion=conexionBD();
    $sql="SELECT name,ST_AsGeoJSON(geom) AS geom 
    FROM shp_barrios
    WHERE name ILIKE '%$name%' ";
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "";
      }else{
        $str = '';
        $str .= '{
        "type": "FeatureCollection",
        "name": "Busqueda",
        "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
        "features": [';
        while ($res = pg_fetch_array($result)) {
          $str .= '{
            "type": "Feature",
            "properties": {
              "name": "'.$res['name'].'"    
            },
            "geometry":'.$res['geom'].'
          },';
        }
        // Ahi quito la ultima coma que esta sobrando.
        $str2 = substr($str,0,strlen($str)-1);     
        //Cerrando el GeoJson
        $str2 .= ']}';
        echo $str2;
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  };
?>