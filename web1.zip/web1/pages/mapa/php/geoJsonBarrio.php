<?php
  /* error_reporting(0); */
  if ($_SERVER["REQUEST_METHOD"] == "POST"){ 
    include '../../php/conexion.php';
    $conexion=conexionBD();
  /*   $recibe=$_POST["padrones"]; */
    header('Content-Type: application/json');
    $barrios = json_decode(file_get_contents('php://input'), true);    
    $str = '';
    $srt2= '';
    $band=false;
    $str .= '{
      "type": "FeatureCollection",
      "name": "Busqueda",
      "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
      "features": [ ';
    foreach($barrios as &$barrio){
     // $sql="SELECT * FROM sat_search_barrio('$barrio')";  
       $sql="SELECT inm_bar,name,ST_AsGeoJSON(geom) AS geom, inm_dist 
      FROM shp_barrios
      WHERE name ILIKE '%$barrio%' ";    
      $result=pg_query($conexion,$sql); 
      if (!$result){
        echo ('');                
      }else{
        if (pg_num_rows($result) != 0) {          
          while ($res = pg_fetch_assoc($result)) {
            $str .= '{
              "type": "Feature",
              "properties": {
                "inm_bar": "'.$res["inm_bar"].'",
                "name":"'.$res["name"].'",
                "inm_dist" :"'.$res["inm_dist"].'"   
              },
              "geometry":'.$res["geom"].'
            },';
            $band=true;
          }          
        }
      } 
    }    
    if ($band){
      $str2 = substr($str,0,strlen($str)-1);     
      $str2 .= ']}';
      echo  json_encode($str2);  
    }else{
      echo json_encode('');
    }
    pg_free_result( $result ); 
    pg_close($conexion);
  };  
?>