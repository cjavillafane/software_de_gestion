<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST"){
    header('Content-Type: application/json');
		$inm_cod=json_decode(file_get_contents('php://input'), true); 
 
    include '../../php/conexion.php';
    $conexion=conexionBD();
    $sql="SELECT inm_cod,nom_archivo,to_char(fecha, 'dd/mm/yyyy')AS fecha_foto FROM banco_imagenes WHERE inm_cod=$inm_cod AND tipo=1 ORDER BY fecha DESC" ;
    $result=pg_query($conexion,$sql);    
		$list='';
    if( !$result )
    die("Error, no se ejecutó la consulta.");
	  else{ 
      $array=array();
		  while ( $data = pg_fetch_assoc($result)){
        $array[] = $data;   
	    }
      echo json_encode($array);
	  }	
    pg_free_result( $result );
		pg_close($conexion);	
	}else{
    exit; 
  }
	?>