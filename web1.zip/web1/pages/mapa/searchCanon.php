<?php
	if (isset($_GET)){
		$inm_cod=$_GET["inm_cod"];
		$conexion=pg_connect("host=localhost port=5432 dbname=sat user=postgres password=milk2k1")or die("NO se pudo conectar la base de datos".pg_last_error());
    $sql="SELECT liq_canon.*, 
		ROUND((liq_canon.sup_cub*liq_canon.import_unit):: numeric,2)AS import_liq,
		(cuentas.inm_dist || '-' ||cuentas.inm_cta || '-' || cuentas.inm_scta) AS cuenta,
		(calles.calinm_nom||' N° '||domicilios.inm_nro)AS direccion
		FROM liq_canon 
		JOIN cuentas ON cuentas.inm_cod=liq_canon.inm_cod_liq
		JOIN domicilios ON domicilios.inm_cod=cuentas.inm_cod
		JOIN calles ON calles.inm_cal=domicilios.inm_cal
		WHERE liq_canon.inm_cod=$inm_cod AND domicilios.idestados='INMUEBLES'";
    $result=pg_query($conexion,$sql);    
		$list='';
    if( !$result )
		  die("Error, no se ejecutó la consulta.");
	  else{ 
		  $array["data"] = [];//devuelve un arreglo vacio por si no hay registros en la base de datos
		  while ( $data = pg_fetch_assoc($result)){
			  $array["data"][] = $data;//array_map("utf8_encode", $data);
		  }
			$list= json_encode( $array );
	  }	
    pg_free_result( $result );
		pg_close($conexion);	
	};
	?>
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Document</title>
			<?php include $_SERVER['DOCUMENT_ROOT'].'/web/pages/links.php'; ?>
<!-- 		<link rel="stylesheet" href="../library/bootstrap/bootstrap.min.css">
		<link rel="stylesheet" href="../library/dataTable/datatables.min.css">
		<script src="../library/jquery/jquery-3.4.1.min.js"></script>
		<script src="../library/popper/popper.min.js"></script>
		<script src="../library/bootstrap/bootstrap.min.js"></script>
		<script src="../library/fontawesome/js/all.min.js"></script>
		<script src="../library/dataTable/datatables.min.js"></script> 
		<script src="../src/var.js"></script>  -->
		<style>
      .custom {
					font-size: 10px;
					font-family: Arial;
			}
			.bottomcustom, .topcustom {
					font-size: 10px;
					font-family: Arial;
		
				/* 	width: 540px; */
			}
    </style>
	</head>
	<body>
	<table id="tableCanon"  
		cellspacing="0"
		class="table table-sm table-striped table-bordered custom" 
		style="width:100%">
		<thead class=" table-dark">
			<tr>
				<th>Liq N°</th>
				<th>Cuenta</th>
				<th>Domicilio</th>		
				<th>Fecha Liq.</th>
				<th>Sup.Cub.</th>
				<th>Imp. Unit.</th>
				<th>Imp. Liq.</th>
				<th>Fecha Pago</th>
				<th>Representante</th>
				<th>cuit/cuil</th>	
				<th>Domicilio Rep.</th>
				<th>Telefono</th>
				<th>Observaciones</th>
			</tr>
		</thead>
	</table>
	<?php include $_SERVER['DOCUMENT_ROOT'].'/web/pages/scripts.php';?>
	<script type="text/javascript">
		$(document).ready(function() {					
			var obj=JSON.parse('<?php echo $list;?>');
			var value=obj.data;
    	$('#tableCanon').DataTable( {
				"data":value,
				"columns":[
					{"data":"num_liq","width": "400px"},
	 				{"data":"cuenta"},
					{"data":"direccion"},
					{"data":"fecha_liq"},
					{"data":"sup_cub"},
					{"data":"import_unit"},
					{"data":"import_liq"},
					{"data":"fecha_pago"},
					{"data":"representante"},
					{"data":"cuit_cuil"},
					{"data":"dom_rep"},
					{"data":"tel_rep"},
					{"data":"observaciones"},
				],
				"dom": "<'row topcustom'<'col-sm-6'B><'col-sm-6'f>>t"+
				"<'row bottomcustom'<'col-sm-4'l><'col-sm-4'i><'col-sm-4'p>>",
			/* 	"<'topcustom'lfrB>t<'bottomcustom'ip>", */
		
				"language": idioma_espanol,
				"buttons":[ 
					{
						extend:    'excelHtml5',
						text:      '<i class="fa fa-file-excel"></i>',
						className: "btn btn-success",
						titleAttr: 'Excel'
					},
					{
						extend: 'csvHtml5',
						text: '<i class="fa fa-th"></i>',
						className:"btn btn-info",
						titleAttr: 'CSV'
					},
					{
						extend:    'pdfHtml5',
						text:      '<i class="fa fa-file-pdf"></i>',
						className : "btn btn-danger",
						titleAttr: 'PDF'
						}
        ],
    	} ); 
		} );
	</script>
	</body>
	</html>