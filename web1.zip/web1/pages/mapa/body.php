<!-- <div class="uk-position-relative menu">  
  <div class="uk-position-top">
    <nav class="uk-navbar-container uk-navbar-transparent" uk-navbar>
      <div class="uk-navbar-left">
        <ul class="uk-navbar-nav">
          <li class="uk-active"><a href="#">Active</a></li>
          <li>
            <a href="#">
              <i class="fas fa-edit"></i>
            </a>
          </li>
          <li>
            <a href="#">Parent</a>
            <div class="uk-navbar-dropdown">
              <ul class="uk-nav uk-navbar-dropdown-nav">
                <li class="uk-active"><a href="#">Active</a></li>
                <li><a href="#">Item</a></li>
                <li class="uk-nav-header">Header</li>
                <li><a href="#">Item</a></li>
                <li><a href="#">Item</a></li>
                <li class="uk-nav-divider"></li>
                <li><a href="#">Item</a></li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</div>
<div id="map"></div>    
 -->
 <div id="map">

  
 </div>
 <div class="uk-offcanvas-content menu ">
  <!-- menu position. delete .uk-light to change black navbar to white (also you should change logo to dark one)-->
  <nav class="uk-navbar-container uk-light" style="z-index: 999999; height: 70px;  padding-top: 0px;" uk-navbar uk-sticky="animation: uk-animation-slide-top; show-on-up: true">
    <!-- logo or title-->
    <div class="uk-navbar-left nav-overlay">
      <div class="uk-navbar-item">
        <div uk-form-custom="target: true" style="font-weight: bold; font-size: 15px;">
          <select id="selAgencia">
            <option value="0">Tucuman</option>
            <option value="1">Aguilares</option>
            <option value="2">Alberdi</option>
            <option value="3">Banda del Rio Sali</option>
            <option value="4">Bella Vista</option>
            <option value="5">Concepcion</option>
            <option value="6">Lules</option>
            <option value="7">Monteros</option>
            <option value="8">Moreno</option>
            <option value="9">Simoca</option>
            <option value="10">Tafi Viejo</option>
            <option value="11">Yerba Buena</option>
            <option value="12">San Miguel</option>
            <option value="13">Tafi del Valle</option>
          </select>
          <span id="spanAgencia"></span>
        </div>
      </div>
    </div>
   

    <div class="uk-navbar-right nav-overlay">
      <div class="uk-navbar-flip">
        <ul class="uk-navbar-nav uk-visible@s">           
        <div class="uk-navbar-item">
          <div>Cta.Loc. <div class="uk-navbar-subtitle"><span class="uk-badge" id="nroGis" style="background-color:#2279E1; color:white">0</span> </div></div>            
          </div>     
          <div class="uk-navbar-item">
            <div>Faltan <div class="uk-navbar-subtitle"><span class="uk-badge" id="nroNoGis" style="background-color:red; color:white">0</span></div></div>
          </div>    
          <li>
            <a href="#" ><i class="far fa-user"></i></a>
            <div class="uk-navbar-dropdown">
              <ul class="uk-nav uk-navbar-dropdown-nav">
                <li class="uk-active"><a href="#" id="userLabel">Nombre de Usuario</a></li>  
                <li class="uk-nav-divider"></li>     
                <li><a href="#" id="btnDatos"><i class="fas fa-user-edit"></i>&nbsp;Mis Datos</a></li>
                <li><a href="#" name="btnSalirUser"><i class="fas fa-sign-out-alt"></i>&nbsp;Salir</a></li>                         
              </ul>
            </div>
          </li>        
          <li><a class="uk-navbar-toggle" uk-search-icon uk-toggle="target: .nav-overlay; animation: uk-animation-fade" href="#"></a></li>
        </ul>

        <ul class="uk-navbar-nav uk-hidden@s">
          <li><a class="uk-navbar-toggle" uk-search-icon uk-toggle="target: .nav-overlay; animation: uk-animation-fade" href="#"></a></li>
          <li><a class="uk-navbar-toggle" uk-navbar-toggle-icon uk-toggle="target: #mobile-navbar"></a></li>
        </ul>
      </div>
    </div>
    <!-- endmenu-->
    <!-- Overlay Search-->
    <div class="nav-overlay uk-navbar-left uk-flex-1" hidden>
      <div class="uk-navbar-item uk-width-expand">
        <div class="uk-search uk-search-navbar uk-width-1-1">
          <input class="uk-search-input" type="search" placeholder="Buscar..." autofocus id="inpSearch">
        </div>
      </div><a class="uk-navbar-toggle" uk-close uk-toggle="target: .nav-overlay; animation: uk-animation-fade" href="#"></a>
    </div>
    <!-- end overlay search-->
  </nav>
  <!-- end menu position-->
  <!-- off-canvas menu-->
  <div id="mobile-navbar" uk-offcanvas="mode: slide; flip: false"  style="z-index: 999999999;">
    <div class="uk-offcanvas-bar" >
      <!-- off-canvas close button-->
      <button class="uk-offcanvas-close" type="button" uk-close></button>
      <!-- off-canvas close button-->
      <ul class="uk-nav-default uk-nav-parent-icon" uk-nav>
        <!-- logo or title-->
        <li class="uk-text-center" style="padding: 0 0 25px 0;"><a href="#">
          <img src="../../images/logotuc.png" alt="logo" width="64"></a></li>
        
        <li>
          <hr>
        </li>
        <li class="uk-text-center" id="userLabel">Menu</li>
        <li class="uk-active"><a href="#">Item 1</a></li>
        <li class="uk-parent">
          <a href="#"><i class="fas fa-edit"></i> Editar</a>
          <ul class="uk-nav-sub">
            
          </ul>
        </li>
               
 
        <li><a href="#" id="irGoogle"><i class="fab fa-google"></i>&nbsp;Redireccionar Mapas Google</a></li>
       
        <li class="uk-parent">
          <a href="#"><i class="fas fa-ruler"></i>&nbsp;Mensura</a>
          <ul class="uk-nav-sub">         
            <li><a href="#" id="linea"><i class="fas fa-ruler-vertical"></i>&nbsp;Lineal</a></li>
            <li><a href="#" id="poligono"><i class="fas fa-ruler-combined"></i>&nbsp;Area</a></li> 
            <li><a href="#"><i class="fas fa-edit"></i>&nbsp;Editar</a>
              <ul>                  
                <li><a href="#">Editar Mensura</a></li>
                <li><a href="#">Guardar Modificación</a></li> 
                <li><a href="#">Cancelar Edición</a></li>  
                <li><a href="#">Borrar Todo</a></li>  
              </ul>             
            </li>
          </ul>         
         </li>
         <li><a href="#" name="btnSalirUser"><i class="fas fa-sign-out-alt"></i>&nbsp;Salir</a></li> 
      </ul>
    </div>
  </div>
  <!-- end off-canvas menu-->
</div>
<div class="contButton">
  <button class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored mdl-shadow--2dp" uk-toggle="target: #controlShape">
    <i class="fas fa-map-marked-alt"></i>
  </button>
</div>

<?php include 'controlShape.php';?>

<!-- <div class="controlInf">
  
  <p id="txtZoom"></p>
  <p id="txtCoordenadas"></p>
  
</div> -->
<div class="uk-flex uk-flex-center uk-hidden" >
    <div class="uk-button-group" >
        <button class="uk-button uk-button-secondary" uk-tooltip="title: Iniciar mensura; pos: bottom"><i class="fas fa-pen"></i></button>
        <button class="uk-button uk-button-secondary" uk-tooltip="title: Terminar mensura; pos: bottom"><i class="far fa-hand-paper"></i></button>
        <button class="uk-button uk-button-secondary" uk-tooltip="title: Editar mensura; pos: bottom"><i class="fas fa-edit"></i></button>
        <button class="uk-button uk-button-secondary" uk-tooltip="title: Eliminar mensura; pos: bottom"><i class="fas fa-trash-alt"></i></button>
        <button class="uk-button uk-button-secondary" uk-tooltip="title: Salir de la mensura; pos: bottom"><i class="fas fa-times-circle"></i></button>
    </div>
</div>

<div class="uk-overlay uk-overlay-primary uk-position-bottom" style=" height:28px; padding: 0px; ">
<table>
  <tr>
    <th>
    <div id="txtZoom"></div>
    </th>
    <th>

      <div id="txtCoordenadas"></div>
    </th>
  </tr>
  
</table>               
</div>
