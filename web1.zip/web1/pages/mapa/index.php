<!DOCTYPE html>
  <?php 
    session_start(); 
    if(isset($_SESSION['usuario'])){       
    }else{
      header( 'Location: ../login/index.php');
      exit; 
    }
  /* $_SESSION["usuario"]["nombre"]='Gustavo Vargas'; 
  $_SESSION["usuario"]["idsector"]=3; */
  ?>
<html lang="es">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
  <meta name="description" content="descripcion">
  <meta name="keywords" content="lista de temas para el buscador">
  <meta name="author" content="Vargas Elias Gustavo">
  <title>mapa GIS</title>
  <link rel="shortcut icon" href="../../images/images.jpg" type="image/jpg">
  <?php include '../links.php'; ?>
  <link rel="stylesheet" href="./css/style.css">
</head>
<body>
  <?php include 'body.php'; ?>
  <?php include '../scripts.php';?>
  <?php include '../php/modalSino.php';?>
 
  
  <script src="./php/LiqCanon.geojson"></script>
  <script src="./php/escPublicas.geojson"></script>
  <script src="./php/escPrivadas.geojson"></script>
  <script src="./php/organismos.geojson"></script>
  <script src="./php/hospitales.geojson"></script>
  <script src="./php/salud.geojson"></script>
  <script src="./php/cic.geojson"></script>
  <script src="../../library/turf/turf.min.js"></script>
  <script src="./js/var.js"></script>
  <script src="./js/app.js"></script>
  <script src="./js/searchMap.js"></script>
  <script>  
 
    var codUsuario ='<?php echo $_SESSION["usuario"]; ?>';
    var userName   = "<?php echo $_SESSION['nombre']; ?>";
    var agencia    = "<?php echo $_SESSION['agencia']; ?>";
    var rol        = "<?php echo $_SESSION['idrol']; ?>";  
   /* document.getElementsByName("btnSalirUser").addEventListener("click",function(event){
      UIkit.modal("#modSino").show();
    }); */

   
    document.getElementById("btnSalida").addEventListener("click",function(eventt){   
     
      fetch ('php/cerrarSecion.php',{
        
      })
      .then ( response => {
 
        window.location.href="../login/index.php"; 
      })
/*       .then ( json => {
       console.log(json);
       
      }) */
      .catch ( error => console.log('Se produjo un error: '+error))

    });
    
    
 

  </script>

</body>
</html>