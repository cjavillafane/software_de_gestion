<div id="controlShape" uk-offcanvas="flip: true; overlay: true" style="z-index: 999999999;">
  <div class="uk-offcanvas-bar" >
    <button class="uk-offcanvas-close" type="button" uk-close></button>
    <ul class="uk-nav-default uk-nav-parent-icon" uk-nav>
      <li class="uk-text-center">
        <h4>Control de Capas</h4>
      </li>
      <li>
        <hr>
      </li>
      <li class="uk-parent">
        <a href="#">Mapa Base</a>
        <ul class="uk-nav-sub">
          <form action="" id="frmMapBase">
            <div class="uk-form-controls uk-form-controls-text">
              <label><input class="uk-radio" type="radio" name="radMapaBase" value="0" checked> Satelital</label><br>
              <label><input class="uk-radio" type="radio" name="radMapaBase" value="1"> Claro</label><br>
              <label><input class="uk-radio" type="radio" name="radMapaBase" value="2"> Oscuro</label><br>
              <label><input class="uk-radio" type="radio" name="radMapaBase" value="3"> OpenSteetMap</label><br>
              <label><input class="uk-radio" type="radio" name="radMapaBase" value="4"> Claro 2</label><br>
              <label><input class="uk-radio" type="radio" name="radMapaBase" value="5"> Google Maps</label>
            </div>
          </form>
        </ul>
      </li>
      <li class="uk-parent uk-open" >
        <a href="#">Sat-Sapem</a>
        <ul class="uk-nav-sub" >
          <form action="" id="frmShpSat">
            <div class="uk-form-controls uk-form-controls-text" collapsible="false">
              <label><input class="uk-checkbox" type="checkbox" name="cuentasWMS" checked>&nbsp;<i class="fas fa-tint" style="color:#21D2FE;"></i> Cuentas Sat</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="callesWMS" checked>&nbsp;<i class="fas fa-road"></i> Calles</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="IndefinidasWMS">&nbsp;<i class="fas fa-square" style="color:#4BFF37;"></i> Indefinidas</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="departamentosWMS" >&nbsp;<i class="fas fa-square" style="color:#EBEDEC;"></i> Departamentos</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="barriosWMS" >&nbsp;<i class="fas fa-square" style="color:#FF5C15;"></i> Barrios</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="manzanasWMS" >&nbsp;<i class="fas fa-border-all" style="color:#EBEDEC;"></i> Manzanas</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="clientesNRWMS" >&nbsp;<i class="fas fa-store" style="color:#9224C5;"></i> Clientes NR</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="baldiosWMS" >&nbsp;<i class="fas fa-leaf" style="color:#3E8C2C;"></i> Baldios</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="obrasWMS" >&nbsp;<i class="fas fa-cubes" style="color:#E71212;"></i> En Construcción</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="medidoresWMS" >&nbsp;<i class="fas fa-tachometer-alt" style="color:#263DFF;"></i> Medidores</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="serviciosWMS" >&nbsp;<i class="fas fa-wrench"style="color:#42BAE6 ;"></i> Codigo Servicios </label><br>
              <label><input class="uk-checkbox" type="checkbox" name="phWMS" >&nbsp;<i class="fas fa-building"style="color:#FD8BCF ;"></i> Propiedades Horizontales </label><br>
              <label><input class="uk-checkbox" type="checkbox" name="demolicionWMS" >&nbsp;<i class="fas fa-cubes" style="color:#FBE331;"></i> En Demolición</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="shpCanon">&nbsp;<i class="fas fa-coins" style="color:#FFC900 ;"></i> Liq. Canon</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="clusterEscPublic">&nbsp;<i class="fas fa-school" style="color:#5DADE2;"></i> Esc. Publicas</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="clusterEscPriv">&nbsp;<i class="fas fa-school" style="color:#8E44AD;"></i> Esc. Privadas</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="clusterOrganismos">&nbsp;<i class="fas fa-building" style="color:#263DFF;"></i> Organismos Publicos</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="shpHospitales">&nbsp;<i class="fas fa-hospital" style="color:#E71212;"></i> Hospitales</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="clusterSalud">&nbsp;<i class="fas fa-clinic-medical" style="color:rgb(255,140,0);"></i> Est. de Salud</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="shpCic">&nbsp;<i class="fas fa-briefcase-medical" style="color:#42BAE6 ;"></i> Cic</label><br>
              <label><input class="uk-checkbox" type="checkbox" name="distritosWMS">&nbsp;<i class="fas fa-map-signs" style="color:#EBEDEC ;"></i> Agencias y Distritos</label><br>

              
            


                           
            </div>
          </form>
        </ul>
      </li>
      <li class="uk-parent">
        <a href="#">Catastro Tucuman</a>
        <ul class="uk-nav-sub">
          <form action="" id="frmShpCat">
            <div class="uk-form-controls uk-form-controls-text">
              <label>
                <input type="checkbox" class="uk-checkbox" name="padronWMS">&nbsp;<i class="fas fa-square" style="color:#DA6F6F;"></i> Parcela Catastral
              </label><br>
              <label>
                <input type="checkbox" class="uk-checkbox" name="edificaWMS">&nbsp;<i class="fas fa-home" style="color:#8A8989;"></i>Edificacion
              </label><br>
              <label>
                <input type="checkbox" class="uk-checkbox" name="piletasWMS">&nbsp;<i class="fas fa-water" style="color:#2AA0D7;"></i> Piletas
              </label><br>
              <label>
                <input type="checkbox" class="uk-checkbox" name="cotasWMS">&nbsp;<i class="fas fa-caret-up" style="color:#D9E62E;"></i> Cotas Elevación
              </label><br>
              <!-- <label>
                <input type="checkbox" class="uk-checkbox" name="">
              </label><br> -->
            </div>
          </form>
        </ul>
      </li>
  </div>
</div>
