/* convertir cuenta a codigo de cliente 
  entrada: 
    dist= distrito
    cta=cuaenta
    scta=subcuenta
  salida:
    codigo de clienta O mensaje de error
    
*/
/*  function converCta_Cod(dist,cta,scta){
  fetch ('../php/converCtaCodCli.php',{
    method: 'POST',      
    headers: {
      'Content-Type': 'application/json', 
      'Accept':       'application/json'   
    },
    body: JSON.stringify({inm_dist:dist,inm_cta:cta,inm_scta:scta}),
    async: false 
  })
  .then ( response => response.ok ? response.json() : Promise.reject(response))
  .then (json =>{
    if (json!=='' && json>0){
      
      console.log ( json);
      return Number (json);

    }else{
      console.log('no existe');
      return 'Cuenta no encontrada';
    }
  })
  .catch((error) => {return error;})
  return 'Demorado'; 
}; 
 */