

function alertMessage(txt,tipo){
  if (!tipo){
    tipo="alert"
  }
  new Noty({
    theme: 'metroui',
    text: txt,
    layout: 'bottomLeft',
    timeout: 3000,
    type: tipo,
}).show();
  
};

