function listAgencias(){
  var data=[];
  $.ajax({
    url:"../php/ListAgencias.php",
    async: false,
  })
  .done(function(e){
    if (e){
      data = JSON.parse($.trim(e)); 
    }else{
      alertMessage('NO se encontro agencias','error');       
    }
  })
  .fail(function(){
    alertMessage('Sin conexion con Base de Datos, tabla agencias','error');     
  })
  return data;
};
function listDistAgen(agencia){
  var data=[];
  if (agencia){
    debugger;
    $.ajax({
      url:"../php/ListDistAgen.php",
      data:{agencia:agencia},
      async: false,
      type:"POST",
    })
    .done(function(e){
      if (e){
        data = JSON.parse($.trim(e));
      }else{
        alertMessage('NO se encontro distritos para la agencia seleccionada','error'); 
      }
    })
    .fail(function(){
      alertMessage('Sin conexion con Base de Datos, tabla distritos','error');
    })
  }
  return data;
}
function clearSelect(selectId){
  var select=document.getElementById(selectId);
  var opt=select.options.length;
  for(i=opt-1;i>= 0;i--){
    select.options[i]=null;         
  }
};
function searchMap(valor){

};
function searchType(input){
  var data={};
  var valorInp=document.getElementById(input).value;
  var arraySearch=valorInp.split(':');
  var type=arraySearch[0].toUpperCase();
  var valor=arraySearch[1].toUpperCase();
  switch (type){
    case 'P':
      alertMessage('Buscando el Padron '+valor+'...','info');
      var result=searchPadron(valor);
      console.log(result);
/*       if (result!={}) {
        console.log(result);
      }else{
        alertMessage("No localizado","warning");
      }
 */
      break;
    case 'C':
      alertMessage('Buscando la Cuenta '+valor+'...','info');
 
      break;
    case 'D':
      alertMessage('Buscando la direccion '+valor,'info');

      break;
    case 'B':
      alertMessage('buscar por Barrio','info');
  
      break; 
    case 'CD':
      alertMessage('buscar por Codigo de Cliente','info');
      break;  
    case 'M':
      alertMessage('buscar por Medidor','info');
      break;       
    default:
      alertMessage('Tipo de Busqueda no valida','error');
  }
 /*  searchMap(arraySearch[0].toUpperCase(),arraySearch[1].toUpperCase());  
  console.log(valorInp); */
};
function searchPadron(padron){
  $.ajax({
    url:"../php/searchPadron.php",
    data:{padron:padron },
    async: false,
    type:"POST",
  })  
  .done(function(result){      
    alertMessage('Localizada','success');          
    data = JSON.parse($.trim(result));
    console.log(data);
    debugger;
    return data;              
    /* shpParcelas.clearLayers();
    shpParcelas.addData(data);
    var centroid = turf.centroid(data);
    var long = centroid.geometry.coordinates[0];
    var lat = centroid.geometry.coordinates[1];
  
    markPosition.setPosition(position);  
    map.flyTo(coordenada, 19); */
  })
  .fail(function(){
    alertMessage('Sin conexion con Base de Datos Cuentas','error');
  })
  
      
};
function redondeo2(num){
  return Math.round(num*100)/100;
}

function degARad (deg){
  return deg* Math.PI / 180;
}
function distanciaGeometrica(point1,point2){
  let R=6378137; // en metros  
  let dLat =degARad (point2[0]-point1[0]);
  let dLng =degARad (point2[1]-point1[1]);
  let a=Math.pow( Math.sin(dLat/2),2)+
        Math.cos(degARad(point1[0]))*
        Math.cos(degARad(point2[0]))*
        Math.pow(Math.sin(dLng/2),2);
  let c= 2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));

  return redondeo2(R*c,2);
}
