

function clearError(input){
  document.getElementById(input).classList.remove("uk-form-danger");
};
function addError(input){
  document.getElementById(input).classList.add("uk-form-danger");
  document.getElementById(input).focus();
};
/*Valida Password I: id del password(string) | O: {valor (string), error(string)}  */
var valPassword = (idInput) => {
  let input= document.getElementById(idInput);
  let error=""; 

  if (input.value){
    var expPass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;
    if (input.value.match(expPass)){
      clearError(idInput);
    }else{error="Password no valido";}    
  }else{error="El password no puede ser vacio";}
  if (error) {addError(idInput);}
  return {valor:input.value,error};


/*   var mensaje="ok";
  if(valor!=""){
    if (valor.length>=min && valor.length<=max){

      if ( /[^A-Za-z0-9ñÑ\d]/.test(valor)) { 
        mensaje="Password, debe ingresar letras y/o numeros"
      }       
    }else{mensaje="Password, debe ser mayor "+min+" y menor a "+max}
  }else{mensaje="Password, no debe ser vacio"}
  if (mensaje!="ok"){
    addError(input);    
  }
  return mensaje;  */
}
function valString(input,max){
  var valor= document.getElementById(input).value;
  var mensaje="";
  if(valor!=""){
    if (valor.length<=max){      
      if (valor.match(/[^A-Za-z ñÑ]/)) { 
        mensaje="debe ingresar solo letras";
      }else{mensaje="ok"}     
    }else{mensaje="no debe superar los "+max+" caracteres";}
  }else{mensaje="no debe ser vacio"}
  if (mensaje!="ok"){
    addError(input);    
  }
  return mensaje; 
}
function valLegajo(input,max){
  var valor=document.getElementById(input).value;
  var num=parseFloat(valor)
  
  var mensaje="";
  if (valor!=""){    
    if (!valor.match(/[^0-9]/)){
      if(Number.isInteger(num)){
  
        if ((num>0)&&(num<=max)){
          mensaje="ok"
        }else{mensaje="Legajo, no valido"}
      }else{ mensaje="Legajo, debe ser un numero entero"};
    }else{mensaje="solo debe ingresar numeros"}
  }else{mensaje="Legajo, no puede ser vacio"}
  if (mensaje!="ok"){
    addError(input);
  }

  return mensaje;
};
/*Validar email I: id del input(string), boolean si es requerido(boolean) | O: { valor(string),error(string) } */
let valEmail = (idInput,requerido) => {
  let input= document.getElementById(idInput).toLowerCase() ;
  let error="";  
  if (input.value){
    let expEmail =  /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;    
    if (expEmail.test(String(input.value).toLowerCase())){
      clearError(idInput);
    }else{error="email no valido";}    
  }else{
    if (requerido){error="El mail no puede ser vacio";}
  }
  if (error){addError(idInput);}
  return {valor:input.value,error};
};
function valAgen(input){
  var valor=document.getElementById(input).value;
  var codAgen=parseInt(valor,10)
  mensaje="";
  if (codAgen>0 && codAgen<=13 ) {
    mensaje="ok";
  }else{mensaje="Debe seleccionar una Agencia";}
  if (mensaje!="ok"){
    addError(input);    
  }
  return mensaje;
}
function valDist(input){
  var valor=document.getElementById(input).value;
  var codDist=parseInt(valor,10)
  mensaje="";
  if (codDist>0 && codDist<=999 ) {
    mensaje="ok";
  }else{mensaje="Debe seleccionar un Distrito";}
  if (mensaje!="ok"){
    addError(input);
  }
  return mensaje;
}
function valEntero(number,min,max){
  var tem=parseInt(number);
  if(!isNaN(tem)&&(tem==number)){
    if (tem>=min && tem<=max){
      return true;
    }else{
      return false;
    }
  }else{
    return false;
  }
}
function valPadron(padron){
  var error="";
  padron=padron.toUpperCase();
  var alfanum=/[0-9a-zA-Z]/;
  if (padron=== null || padron.length===0 || padron.length>6){
    error="padron no valido";
  }else{
    if(alfanum.test(padron)){
      if(padron.indexOf('PH')===0){
        /*Ingreso un PH */
        if (valEntero(padron.substr(2),1,99999999)){
          error="";
        }else{
          error="La parte entera del PH no es valida";
        }        
      }else{
        if(padron.indexOf('PH')===-1){
        /*Ingreso un padron independiente*/
          if (valEntero(padron,1,9999999)){
            error="";
          }else{
            error="El padron debe ser un numero entero valido";
          }        
        }else{
          error="PH  no valido";
        }
      }
    }else{
      error="el padron no es alfanumerico";
    }
  }
  return {padron:padron,error:error};
}
let valMedidor = (nromedidor) => {
  let error="";
  nromedidor=nromedidor.toUpperCase();  
  let exp= /[0-9a-zA-Z]{1,11}/; /* no esta funconando la valicacion */
  if (!exp.test(nromedidor)){
    error="Caracteres no permitidos"    
  };
  return {nromedidor:nromedidor,error:error};
}
let ValSearchMap = (text) => {
  var error="";
  var metodo="";
  var consulta=[];
  if(text===""){
    error="Debe ingresar una cadena para realizar la busqueda";
  }else{
    if (text.indexOf(':')===-1){
      error="no posee delimitador";
    }else{
      var arrayText=text.split(":");
      if (arrayText.length ===1){
        error="datos insuficiente para realizar una busqueda";
      }else{
        metodo=arrayText[0].toUpperCase();          
        var cant=arrayText.length;
        console.log(cant);
        var init=0;
        if (cant>1){
          switch(metodo){
            case 'C':
              for (var i=1; i<cant;i++){
                var tem =valCuenta(arrayText[i]);              
                if (tem.error==""){
                  consulta[init++]=tem;        
                }else{
                  error="hay error en una o mas cuentas. "+tem.error;
                }
              }            
            break;
            case 'P':
              for (var i=1; i<cant;i++){              
                var tem =valPadron(arrayText[i]);             
                if (tem.error==""){              
                  consulta[init++]=tem.padron;                     
                }else{
                  error="hay error en una o mas padrones. "+tem.error;
                } 
              }
            break;
            case 'M':
              for (var i=1; i<cant;i++){
                var tem=valMedidor(arrayText[i]);
                if (tem.error==""){
                  consulta[init++]=tem.nromedidor;
                }else{
                  error="hay error en una o mas numero de medidores. "+tem.error;
                }
              }
              break;
            case 'D':
              for (var i=1; i<cant;i++){
                let tem=valDireccion(arrayText[i]);                
                if(tem.error==""){
                  consulta[init++]=tem.direccion;
                }else{
                  error="hay erro en una o mas direcciones. "+tem.error; 
                }
              }
              break;
            case 'B':
              for(var i=1;i<cant;i++){
                if(true){
                  consulta[init++]=arrayText[i];
                }else{
                  error="hay error en una o mas nombre de barrios. "+tem.error;
                }
              }
              console.log(consulta);
              break;
            case 'CC':
              for (var i=1; i<cant;i++){              
                if (valEntero(parseInt(arrayText[i], 10),16400000,19399999)){
                  consulta[init++]=parseInt(arrayText[i], 10);
                  /* consulta[i-1]=arrayText[i]; */
                }else{
                  error="hay error en uno o mas codigos de clientes. "+tem.error;
                }
              }           
              break;
            case 'A':
              break;
            case 'DT':
              for (var i=1; i<cant;i++){
                let tem=valDni(arrayText[i])
                if (tem.error==""){
                  consulta[init++]=parseInt(arrayText[i],10)
            
                }else{
                  error="hay error en algun/os dni. "+tem.error;
                }
              }
              console.log(consulta);
              break;
            case 'DU':
              break;
            default:
              metodo="";
              error="metodo de busqueda incorrecto";     
          } 
        }else{
          error="Busqueda vacia, debe ingresar un dato valido";
        }
   
      }  
    }    
  }
  return {metodo:metodo,consulta:consulta,error:error};
}
function valCuenta(text){
  var error="";
  var dist,cta,subcta;
  if(text!==""){
    var arrayCta=text.split("-");    
    if (arrayCta.length===3){
      if(valEntero(arrayCta[0],1,999)){
        dist=parseInt(arrayCta[0]);
        if(valEntero(arrayCta[1],0,999999)){
          cta=parseInt(arrayCta[1]);
          if(valEntero(arrayCta[2],0,999)){
            subcta=parseInt(arrayCta[2]);        
          }else{
            error="error en la subCuenta";
          }
        }else{
          error="error en el la cuenta";
        }
      }else{
        error="error en el distrito";
      }
    }else{
      error="numero de cuenta incompleto";
    }
  }else{
    error="vacia"
  }
  return {dist:dist,cta:cta,subcta:subcta,error:error}
}
let valDireccion = (direccion) => {
  let error="";
  let solicitud="";
  if (direccion){
    let arrayText=direccion.split(",");
    let campos=["&city=","&state=","&country="];
    
    let calle = arrayText.shift();
    let cant=arrayText.length;
    let arrayCalle= calle.split(" ");
    arrayCalle.unshift(arrayCalle.pop()) 
    let band=true;
    solicitud+="street=";
    arrayCalle.forEach(e => {
  /*     if (band){
        solicitud += e+",+";
        band=false;
      }else{ */
        solicitud += e+"+";
   /*    } */
    });
    
    for (let i = 0; i < cant; i++) {
      solicitud += campos[i]+arrayText[i].replace(/ /g, "+");      
    }
    switch(cant){
      case 0:
        solicitud += "&city=San+Miguel+de+Tucuman&state=Tucuman&country=Argentina&postalcode=4000";
        break;
      case 1:
        solicitud += "&state=Tucuman&country=Argentina&postalcode=4000";
        break;
      case 2:
          solicitud += "&country=Argentina";
        break;      
          /*  case cant>=3:
          error="Algun dato luego de la coma no corresponde";
          break; */
         /*  default: */
      }        
      solicitud += "&format=geojson";
   
            /*     let street="street="+
            let city= "&city="+e.replace(/ /g,"+");
            let solicitud=street+city+"&state=Tucuman&country=Argentina&postalcode=4000&format=geojson"; */    
    /* console.log(e.replace(/ /g, "+")); */
  }else{
    error="Direccion incorrecta o vacia";
  }
  return {direccion:solicitud,error:error};
}

let valDni= (dni) =>{
  let error=""
  let exp= new RegExp('^[0-9]{6,8}$'); /* no esta funconando la valicacion */
  if (exp.test(dni)){
    dni = parseInt(dni);
  }else{
    error ="No es un dni valido"        
  } 
  return {dni:dni,error:error};
}