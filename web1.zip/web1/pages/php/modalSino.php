
<div class="uk-flex-top" uk-modal id="modSino">
<div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
  <button class="uk-modal-close-default" type="button" uk-close></button>
  <h2 class="uk-modal-title">Salir</h2>
  <p class="uk-text-left"> Esta seguro que sesea avandonar la sesión?</p>
  <p class="uk-text-right">  
    <button class="uk-button uk-button-default uk-modal-close" id="btnSalida" type="button">SI</button>
    <button class="uk-button uk-button-secondary uk-modal-close" type="button" >NO</button>
  </p>
</div>
</div>

