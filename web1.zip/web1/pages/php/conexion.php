<?php 
  function conexionBD(){
    /* $ip="186.122.179.6";
    $bd="gis"; 
    $pass="milk2k1sat"; */


    $ip="150.150.122.166";
    $bd="GisModificado"; 
    $pass="milk2k1"; 
    $conexion= pg_connect("host=$ip port=5432 dbname=$bd user=postgres password=$pass")or die("NO se pudo conectar la base de datos".pg_last_error());
    return $conexion;
  };
  function desconectarBD($conexion){
    $close=pg_close($conexion);
    return $close;
  }
  
?>