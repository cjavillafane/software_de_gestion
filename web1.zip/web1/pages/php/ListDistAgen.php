

<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){ 
    include './conexion.php'; 
    $agencia= $_POST["agencia"];  
/*     $conexion=pg_connect("host=localhost port=5432 dbname=sat user=postgres password=milk2k1")or die("NO se pudo conectar la base de datos".pg_last_error()); */
    $conexion=conexionBD();
    $sql="SELECT distinct distritos.inm_dist,distritos.dis_nom FROM agencias
    JOIN agen_distri on agen_distri.inm_age=agencias.inm_age
    JOIN distritos on distritos.inm_dist=agen_distri.inm_dist
    WHERE agencias.numeroagencia= $agencia"; 

    $result=pg_query($conexion,$sql); 
    $array=array();
    if (!$result){
        /* echo ""; */
        die("Error, no se ejecutó la consulta.");      
    }else{
        if (pg_num_rows($result)> 0) {
        while ($row= pg_fetch_assoc($result)){
            $array[]= $row;
        }
        /* echo ""; */
        /* die(""); */
        echo json_encode($array);
        }else{
        /* echo ""; */
        }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
    /* pg_close($conexion); */
  };  
?>