<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'conexion.php';
    $conexion=conexionBD();
   
    $dist=$_POST['inm_dist'];
    $cta=$_POST['inm_cta'];
    $scta=$_POST['inm_scta']; 
    $archivo=$_FILES['archivo'];

    
    $sql= "SELECT inm_cod FROM cuentas WHERE inm_dist=$dist AND inm_cta=$cta AND inm_scta=$scta";
    
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "Cliente no valido";
      }else{                      
        $inm_cod=0;
        while ($row = pg_fetch_array($result)) {
          $inm_cod = $row ['inm_cod'];     
        }
        echo $inm_cod;
        $sql="SELECT count(*) FROM banco_imagenes WHERE inm_cod=$inm_cod ";
        $result=pg_query($conexion,$sql);
        if (!$result){
          echo ('');
          die("Error, no se ejecutó la consulta."); 
        }else{          
          while ($row=pg_fetch_array($result)){
            echo ($row);
          }
        }
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  }; 
?>