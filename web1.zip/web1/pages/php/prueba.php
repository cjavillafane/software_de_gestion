<?php
  include "./conexion.php";
  $conexion=conexionBD();
  $sql="SELECT distinct distritos.inm_dist,distritos.dis_nom FROM agencias
    JOIN agen_distri on agen_distri.inm_age=agencias.inm_age
    JOIN distritos on distritos.inm_dist=agen_distri.inm_dist
    WHERE agencias.numeroagencia= $agencia"; 
  $result=pg_query($conexion,$sql); 
  $array=array();
    if (!$result){
        /* echo ""; */
        die("Error, no se ejecutó la consulta.");      
    }else{
        if (pg_num_rows($result)> 0) {
        while ($row= pg_fetch_assoc($result)){
            $array[]= $row;
        }
        /* echo ""; */
        /* die(""); */
        echo json_encode($array);
        }else{
        /* echo ""; */
        }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
?>