<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'conexion.php';
    $conexion=conexionBD();
    header('Content-Type: application/json');
    $datos = json_decode(file_get_contents('php://input'), true);    
    $dist=$datos['inm_dist'];
    $cta=$datos['inm_cta'];
    $scta=$datos['inm_scta']; 

    $sql= "SELECT inm_cod FROM cuentas WHERE inm_dist=$dist AND inm_cta=$cta AND inm_scta=$scta";

    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "";
      }else{                      
        $inm_cod=0;
        while ($row = pg_fetch_array($result)) {
          $inm_cod = $row ['inm_cod'];     
        }
        echo ($inm_cod);
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  }; 
?>