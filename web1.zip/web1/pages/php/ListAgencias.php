<?php    
  /* $conexion=pg_connect("host=localhost port=5432 dbname=sat user=postgres password=milk2k1")or die("NO se pudo conectar la base de datos".pg_last_error()); */
  include './conexion.php';
  $conexion=conexionBD();
  $sql="SELECT * FROM public.agenciasadicional ORDER BY numeroagencia";
	$result=pg_query($conexion,$sql); 
  $array=array();
    if (!$result){
      /* echo ""; */
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result)> 0) {
        while ($row= pg_fetch_assoc($result)){
          $array[]= $row;
        }
        /* echo ""; */
        /* die(""); */
        echo json_encode($array);
      }else{
        /* echo ""; */
      }
    }
  pg_free_result( $result );
  desconectarBD($conexion);

?>