

<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){ 
    $query2= $_POST["query"];  
    $query=utf8_encode ($query2);
    include "../../php/conexion.php";
    //$conexion= pg_connect("host=150.150.122.166 port=5432 dbname=GisModificado user=postgres password=milk2k1")or die("NO se pudo conectar la base de datos".pg_last_error());
    
    /* $conexion=pg_connect("host=localhost port=5432 dbname=sat user=postgres password=milk2k1")or die("NO se pudo conectar la base de datos".pg_last_error()); */
   $conexion=conexionBD();
    $sql="SELECT 
      inmuebles.inm_cod,cuentas.inm_dist,cuentas.inm_cta,cuentas.inm_scta,padrones.padron,clientes.inm_doc,
      clientes.inm_nomcli,calles.calinm_nom,domicilios.inm_nro,domicilios.inm_pis,domicilios.inm_dto,
      domicilios.inm_man,domicilios.inm_blk,domicilios.inm_lot,domicilios.inm_cas,
      barrios.barinm_nom,actividades.act_nom,codigoservicio.cse_nom,medidores.numero_medidor
      FROM cuentas
      JOIN inmuebles ON inmuebles.inm_cod=cuentas.inm_cod
      JOIN clientes ON clientes.idclientes=cuentas.idclientes
      JOIN domicilios ON domicilios.inm_cod=cuentas.inm_cod
      JOIN calles ON calles.inm_cal=domicilios.inm_cal
      JOIN barrios ON barrios.inm_bar=domicilios.inm_bar
      JOIN actividades ON actividades.inm_act=inmuebles.inm_act
      JOIN codigoservicio ON codigoservicio.inm_codser=inmuebles.inm_codser
      JOIN padrones ON inmuebles.padrones=padrones.padrones
      JOIN agencias on cuentas.inm_age=agencias.inm_age     
      LEFT JOIN medidores ON medidores.inm_cod=cuentas.inm_cod 
      WHERE $query
      ORDER BY calles.calinm_nom,inm_nro ASC"; 
 /*    $sql="select * from sat_search_dom($query)"; */
    $result=pg_query($conexion,$sql); 
    $array=array();
    if (!$result){
      /* echo ""; */
      echo "no encontrado";
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result)> 0) {
        while ($row= pg_fetch_assoc($result)){
          $array[]= $row;
          //echo $array["cuentas.inm_cod"];
        }
        
        /* echo ""; */
        /* die(""); */
        echo json_encode($array);
      }else{
        /* echo ""; */
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  };  
?>