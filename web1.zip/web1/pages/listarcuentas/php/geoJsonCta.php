<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $inm_cod=$_POST["inm_cod"]; 
    /* $conexion=pg_connect("host=localhost port=5432 dbname=sat user=postgres password=milk2k1")or die("NO se pudo conectar la base de datos".pg_last_error()); */
    $conexion=conexionBD();
    $sql="SELECT cuentas.inm_cod, ST_AsGeoJSON(ST_Transform(geom,4326)) AS geom  
    FROM cuentas_geom
    JOIN cuentas ON cuentas.idcuentas_geom=cuentas_geom.idcuentas_geom
    WHERE cuentas.inm_cod='$inm_cod'";
    $result=pg_query($conexion,$sql); 
    if (!$result){
      echo ('');
      die("Error, no se ejecutó la consulta.");      
    }else{
      if (pg_num_rows($result) == 0) {
        echo "";
      }else{
        $str = '';
        $str .= '{
        "type": "FeatureCollection",
        "name": "Busqueda",
        "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
        "features": [';
        while ($res = pg_fetch_array($result)) {
          $str .= '{
            "type": "Feature",
            "properties": {
              "inm_cod": "'.$res['inm_cod'].'"    
            },
            "geometry":'.$res['geom'].'
          },';
        }
        // Ahi quito la ultima coma que esta sobrando.
        $str2 = substr($str,0,strlen($str)-1);     
        //Cerrando el GeoJson
        $str2 .= ']}';
        echo $str2;
      }
    }
    pg_free_result( $result );
    desconectarBD($conexion);
  };
?>