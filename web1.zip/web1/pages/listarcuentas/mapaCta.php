<?php
	if (isset($_GET)){
		$arrayCod=$_GET["arrayCod"];
	};
	?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximumscale=1.0, user-scalable=no" />
 
  <meta name="description" content="descripcion">
  <meta name="keywords" content="lista de temas para el buscador">
  <meta name="author" content="Vargas Elias Gustavo">
<!--   <title>pagina</title>
  <link rel="shortcut icon" href="../../images/images.jpg" type="image/jpg"> -->
  <?php include '../links.php'; ?>
  <style>
    body {
      padding: 0;
      margin: 0;
    }
    #mapCta {
      height: 350px;
      width: 100%;
      position: relative; 
    }
  </style>
  
</head>

<body>
    <div id="mapCta"></div>
  <?php include '../scripts.php';?>
  <script>
    $(document).ready(function(){
      var arrayCod=<?php echo $arrayCod;?>;
      function drawCta(){
        arrayCod.forEach(element => {
          
         /*  addPolCuenta(element); */
        });
      };
      drawCta();
      var opmap={
        zoomControl: false,
      };
      var mapCta=L.map('mapCta', opmap).setView([-26.82, -65.22],9);

      var satelital = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
        maxZoom:22,
      }).addTo(mapCta);
      var blancoNegro = L.tileLayer('https://stamen-tiles-{s}.a.ssl.fastly.net/toner-background/{z}/{x}/{y}{r}.{ext}', {
        attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        subdomains: 'abcd',
        minZoom: 0,
        maxZoom:22,
        ext: 'png'
      });
      document.getElementsByClassName( 'leaflet-control-attribution' )[0].style.display = 'none'; 
      /* ESTILO DE GEOJSON */
      function stlParcelas(feacture){
        return{
          fillOpacity: 0.2,
          fillColor:'#34D624',
          weight:4,
          color:'#34D624'
        }
      }
      /*POPUP DE GEOJSON*/
      function popupParcelas(feature,layer){
        layer.bindPopup(feature.properties.inm_cod);
      }
      /*POLIGONO GEOJSON*/
      var shpParcelas= L.geoJSON('',{
        style:stlParcelas,
        onEachFeature:popupParcelas
      }).addTo(mapCta);
/*       
      function addPolCuenta(cod){
        $.ajax({
          url:"php/geoJsonCta.php",
          data:{inm_cod:cod},
          type:"POST",
        })      
        .done(function(result){
          if (result){    
            data = JSON.parse($.trim(result));         
          /*    shpParcelas.clearLayers(); */
            /* shpParcelas.addData(data); */        
          /*   map.setView(coordenada, 19); */         
     /*     }         
        })
        .fail(function(){
          alert('error');
        });
      } */
    });
  </script>

</body>
</html>