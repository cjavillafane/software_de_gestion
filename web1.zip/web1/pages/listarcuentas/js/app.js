$(document).ready(function(){
  /*Input de Filtro Individual*/
  $('#tblResult tfoot th').each( function () {
    var title = $(this).text();
    $(this).html( '<input type="text" class="uk-input uk-form-width-medium uk-form-small" style="width: 80px;"placeholder="'+title+'" />' );
  } );
  /* Tabla */
  var tableCuenta=$('#tblResult').DataTable({
    columns:[
      {data:'calinm_nom'},
      {data:'inm_nro'},
      {data:'inm_cod'},
      {data:'inm_dist'},
      {data:'inm_cta'},
      {data:'inm_scta'},
      {data:'padron'},
      {data:'inm_doc'},
      {data:'inm_nomcli'},
      {data:'barinm_nom'},
      {data:'inm_pis'},
      {data:'inm_dto'},
      {data:'inm_man'},
      {data:'inm_blk'},
      {data:'inm_lot'},
      {data:'inm_cas'},
      {data:'act_nom'},
      {data:'cse_nom'},
      {data:'numero_medidor'},
      {
        data:null,
        defaultContent:   
          '<div class="uk-button-group">'+
            '<button class="uk-button uk-button-default uk-button-small" href="#modalMap" uk-toggle><i class="fas fa-search-location"></i></button>'+
            '<button class="uk-button uk-button-default uk-button-small" id="btnLocation"><i class="fas fa-file-alt"></i></button>'+

            '<button class="uk-button uk-button-default uk-button-small" uk-toggle><i class="fas fa-info-circle"></i></button>'+

            
          '</div>',
          "width": "10%"
      }
    ],
    initComplete: function () {     
      this.api().columns().every( function () {
        var that = this;
        $( 'input', this.footer() ).on( 'keyup change clear', function () {
          if ( that.search() !== this.value ) {
            that
              .search( this.value )
              .draw();
          }
        } );
      } ); 
    },
    "responsive": true,
    "dom": "<'row topcustom'<'col-sm-6'B><'col-sm-6'f>>t"+
    "<'row bottomcustom'<'col-sm-4'l><'col-sm-4'i><'col-sm-4'p>>",
    "buttons":[ 
      {
        extend:     'excelHtml5',
        text:       '<i class="fas fa-file-excel"></i>',
/*         className: "uk-button uk-button-primary uk-button-small", */
        titleAttr: 'Excel'
      },
      {
        extend:     'csvHtml5',
        text:       '<i class="fas fa-file-csv"></i>',
    /*     className:"uk-button uk-button-primary uk-button-small", */
        titleAttr: 'CSV'
      },
      {
        extend:     'pdfHtml5',
        text:       '<i class="fas fa-file-pdf"></i>',
/*         className : "uk-button uk-button-primary uk-button-small", */
        titleAttr: 'PDF'
      }
    ], 
    "language": idioma_espanol,
    "scrollX": true
  });
  /*Seleccionar Elemento de la tabla para su Localizacion*/
  $('#tblResult tbody').on( 'click', 'tr', function () {
    $(this).toggleClass('selected');
    if (tableCuenta.rows('.selected').data().length>0){
      document.getElementById("btnLocation").removeAttribute("disabled");
    }else{     
      document.getElementById("btnLocation").disabled=true;
    }
  });
  /*Boton de Localizacion de Cuenta*/
  document.getElementById("btnLocation").addEventListener("click",function(event){
    var selc= tableCuenta.rows('.selected').data();
    console.log(selc);
    for(var i=0;i<selc.length;i++){
      console.log(selc[i].inm_cod);
    }
    UIkit.modal("#modalMap").show();
  })
  /*Constructor de Consulta */
  function generateQuery(array){
    var query="";
    array.forEach(function (i){
      if (query){
        query+= " AND ";
      }
      query+=i;
    })
    return query;
  };
  var calle='';
  var numPuerta='';
  /*Boton de Limpieza de Inputs para Nueva Busqueda*/
  document.getElementById("clear").addEventListener("click",function(){
    clear();
  });
  /*Limpiar Input*/
  function clear(){
    $('.SearchAdvance input').val('');
    $('.SearchAdvance input').removeClass('uk-form-danger')
    tableCuenta.clear().draw();
    document.getElementById("btnLocation").disabled=true;

  }
  /*Detectar Cambios en los Input y Remover Error*/
  $( "input[type='text']" ).change(function() {
    $( this ).removeClass("uk-form-danger");
  });
  /*FUNCION PRINCIPAL DE BUSQUEDA*/
  document.getElementById("searchCta").addEventListener("click",function(){ 
    var arrayquery=[];    
    var formInput=$('.SearchAdvance input:empty');
    var valido= true;
    formInput.each(function(){  
      var error='';    
      var val=this.value.toUpperCase();
      var valor=val.replace(/([aeio])\u0301|(u)[\u0301\u0308]/gi,"$1$2").normalize();
      /* normalize("NFD").replace(/[\u0300-\u036f]/g, ""); */ 
      if(valor){ 
        switch(this.name){
          case "inpCodCliente":
            error=valEntero(valor,16400000,20000000);
            if (error == 'ok'){
              arrayquery.push('cuentas.inm_cod= ' + valor);
            }else{
              valido=false;
              LocError(this.name,error);   
              alertMessage('Cliente '+error,'error');   
            };
            break;
          case "inpCuenta":
            error=valCuenta(valor);        
            if (error== 'ok'){
              arrayquery.push(querryCuenta(valor));
            }else{
              valido=false;
              LocError(this.name,error); 
              alertMessage(error,'error');
            };
            break;
          case "inpPadron":
            error=valEntero(valor,1,9999999);
            if (error == 'ok'){
              arrayquery.push("padrones.padron= '" + valor+ "'");
            }else{
              valido=false;
              LocError(this.name,error); 
              alertMessage('Padron '+error,'error');
            };
            break;         
          case "inpMedidor":
            error=valCadena(valor,3,10);
            if (error == 'ok'){
              arrayquery.push("numero_medidor ='" + valor+"'");
            }else{
              valido=false;
              LocError(this.name,error); 
              alertMessage('Medidor '+error,'error');
            };
            break;
          case "inpDireccion":
            valor= valor.replace(',', '');
            console.log(valor);
            error=valCadena(valor,4,35);
            if (error=='ok'){
              arrayquery.push(querryDireccion(valor));
            }else{
              valido=false;
              LocError(this.name,error);
              alertMessage('Direccion '+error); 
            }
            break;
          case "inpNomCliente":
            valor= valor.replace(',', '');
            error=valCadena(valor,3,50);
            if (error=='ok'){
              arrayquery.push(querryNombre(valor,'TITULAR'));
            }else{
              valido=false;
              LocError(this.name,error);
              alertMessage('Cliente '+error);
            }
            break;
          case "inpBarrio":
            valor= valor.replace(',', '');
            error=valCadena(valor,3,50);
            if (error=='ok'){
              arrayquery.push(querryBarrio(valor));
            }else{
              valido=false;
              LocError(this.name,error);
              alertMessage('Barrio '+error);
            }
            break;
          case "inpDniCuit":            
            var dato=valor.split('-');     
            if (dato.length==1){
              error=valDni(dato[0]);
              if (error=='ok'){
                arrayquery.push('inm_doc= '+dato[0]);
              }else{
                valido=false;
                LocError(this.name,error);
                alertMessage(error,'error');
              }
            }else{
              if (dato.length==3){
                error=valCuit(dato[0],dato[1],dato[2]);
                if (error=='ok'){
                  arrayquery.push("inm_digide= "+dato[0]+ " AND inm_doc= "+dato[1]+" AND inm_digver= "+dato[2]);
                }else{
                  valido=false;
                  LocError(this.name,error);
                  alertMessage(error,'error');
                }
              } else{
                alertMessage('Cuit/l no valido','error');
              }      
            }                   
            break;  
          case "inpMz":
            error=valStrNum(valor,10);
            if (error=='ok'){
              arrayquery.push(querryMz(valor));
            }else{
              valido=false;
              LocError(this.name,error);
              alertMessage('Manzana '+error,'error');
            }
            break; 
          case "inpBlk":
            error=valStrNum(valor,10);
            if (error=='ok'){
              arrayquery.push(querryBlk(valor));
            }else{
              valido=false;
              LocError(this.name,error);
              alertMessage('Block '+error,'error');
            }
            break;  
          case "inpLote":
            error=valStrNum(valor,10);
            if (error=='ok'){
              arrayquery.push(querryLote(valor));
            }else{
              valido=false;
              LocError(this.name,error);
              alertMessage('Lote '+error,'error');
            }
            break;  
          case "inpCasa":
            error=valStrNum(valor,10);
            if (error=='ok'){
              arrayquery.push(querryCasa(valor));
            }else{
              valido=false;
              LocError(this.name,error);
              alertMessage('Casa '+error,'error');
            }
            break;  
          default:
        }      
      }
    });

    if (valido){
      if (arrayquery.length>0){       
        var query=generateQuery(arrayquery);
        var rango=document.getElementById("inpRango").value;      
        var tipo=document.getElementById("inpTipo").value;
        var tipoClie=document.getElementById("inpTipCli").value;
        var age=document.getElementById("inpAgencia").value;
        var dist=document.getElementById("inpDistrito").value;
        /* incluido en funcion */
        var inicio=parseInt(numPuerta)-(parseInt(rango)/2);
        var fin=parseInt(numPuerta)+(parseInt(rango)/2);       
        
        if (numPuerta){
          if (query){
            query+=" AND"
          }
          query+=" (inm_nro>= "+inicio+" AND inm_nro<= "+fin+" )"
        }
        query+=" AND idestados= '"+ tipo+ "'";
        if (age!=0){
          if (query){
            query+=" AND"
          }
          query+= " numeroagencia="+ age
        }
        if (dist!=0){
          if (query){
            query+=" AND"
          }
          query+= " cuentas.inm_dist = "+ dist
        }
        console.log(query);
        search(query);
        var queryFunction= query+';'+calle+';'+numPuerta+';'+rango+';'+tipo+';'+tipoClie;
        /* search(queryFunction); */
      }else{
        alertMessage('Debe ingresar parametros de busqueda','error');
      }
    }else{
      /* alert("error o errores"); */
    }

  });
  /*Marcar error en el Input*/
  function LocError(input,error){
    document.getElementById(input).classList.add("uk-form-danger");
  }
  /*Remover Error*/
  function clearError(input){
    document.getElementById(input).classList.remove("uk-form-danger");
  }
  /*Contructor de Consulta por Cuentas y Subcuenta*/
  function querryCuenta(valor){
    var arrayCta=valor.split('-');    
    if (arrayCta[1]){
      return "cuentas.inm_cta= "+arrayCta[0]+" AND cuentas.inm_scta= "+arrayCta[1]
    }else{
      return "cuentas.inm_cta= "+arrayCta[0]
    }
  }
  /*Contructor de Consulta por Direccion*/
  function querryDireccion(valor){
    var direccion='';
    var arrayDirec=valor.split(' ');
    var index=arrayDirec.length;
    var num=parseInt(arrayDirec[index-1]);
    if ((index>1) && (Number.isInteger(num))){   
      arrayDirec.splice(index-1,1);
      numPuerta=num;
    }else{
      numPuerta='';
    }
    if (arrayDirec.length>=1){
      direccion+= queryTxt(arrayDirec,'calinm_nom');
      
    }
    return direccion;
  }
  /*Contructor de Consulta por Nombre*/
  function querryNombre(valor,tipo){
    var arrayNom=valor.split(' ');
    if (tipo=='TITULAR'){
      return queryTxt(arrayNom,'inm_nomcli')
    }
  }
  /*Contructor de Consulta por Barrio*/
  function querryBarrio(valor,tipo){
    var arrayNom=valor.split(' ');   
    return queryTxt(arrayNom,'barinm_nom'); 
  }
  /*Iniciar la Busqueda*/
  function search(query){ 
    console.log(query);
    debugger;
    UIkit.modal("#modalLoad").show();
    /*arrancar*/   
    $.ajax({
      url:"php/searchAdv.php",
      data:{query:query},
      type:"POST",
    })
    .done(function(e){
      UIkit.modal("#modalLoad").hide();  
      console.log(e);
     
      tableCuenta.clear().draw(); 
      if (e.length==4){
        alertMessage('No encontrado','error');          
   
      }else{
        document.getElementById("tabla").scrollIntoView(true);
        
        alertMessage(' <i class="far fa-check-square"></i>  Encontrado','success');
        data = JSON.parse($.trim(e));  
        tableCuenta.rows.add(data).draw();
      }
    })
    .fail(function(){
      alertMessage('Error en la Base de Datos','error');
    })
  };
  /*Constructor de Consulta tipo texto sin orden y igualdad parcial*/
  function queryTxt(array,colum){  
    var query1="";
    var query2=""; 
    array.forEach(function(item){
      if (query1){
        query1 += " AND ";
      }
      query1+="to_tsvector("+colum+") @@ to_tsquery ('"+ item +"')";     
    });   
    array.forEach(function(item){
      if (query2){
        query2 += " AND ";
      }
      query2+= colum+" ILIKE '%"+ item +"%'";  
    })
    var query = "(("+ query1 + ") OR ("+ query2 +"))";
    calle=query;
    return query;
  };
  /*Contructor de Consulta porManzana*/
  function querryMz(valor){
    return "inm_man= '"+valor+"'"
  }
  /*Contructor de Consulta por Block*/
  function querryBlk(valor){
    return "inm_blk= '"+valor+"'"
  }
  /*Contructor de Consulta por Lote*/
  function querryLote(valor){
    return "inm_lot= '"+valor+"'"
  }
  /*Contructor de Consulta por Casa*/
  function querryCasa(valor){
    return "inm_cas= '"+valor+"'"
  }
  /*Añadir poligono al mapa*/
/*   function addPolCuenta(cod){
    $.ajax({
      url:"php/geoJsonCta.php",
      data:{inm_cod:cod},
      type:"POST",
    })      
    .done(function(result){
      if (result){    
        data = JSON.parse($.trim(result));    */      
      /*    shpParcelas.clearLayers(); */
       /*  shpParcelas.addData(data); */        
      /*   map.setView(coordenada, 19); */         
/*       }         
    })
    .fail(function(){
      alertMessage('Error en la lOcalizacion','error');
    });
  } */
  /* CARGAR SELECT DE AGENCIAS */
  loadAgencias();
  /*Listar Agencias Disponibles*/
  function loadAgencias(){
    $.ajax({
      url:"../php/ListAgencias.php",
    })
    .done(function(e){
      if (e){
        data = JSON.parse($.trim(e));   
        var select = document.getElementById("inpAgencia"); 
        data.forEach(function(item){
          select.innerHTML += "<option value=\"" + item.numeroagencia + "\">" + item.nombre + "</option>";         
        })        
      }else{
        alertMessage('Error en Base de Datos','error'); 
      }
    })
    .fail(function(){
      alertMessage('Sin conexion con Base de Datos','error'); 
    })

  }
  /*Duscar Distrito en funcion del Cambio de Agencia*/
  document.getElementById("inpAgencia").addEventListener("change", function(){
    if (this.value !=0){
      loadDistritos(this.value);
    }else{
      var select = document.getElementById("inpDistrito"); 
      var opt=select.options.length;
      for(i=opt-1;i> 0;i--){
        select.options[i]=null;         
      }
    }
  }); 
  /*Listar Distritos*/
  function loadDistritos(agencia){
    $.ajax({
      url:"../php/ListDistAgen.php",
      data:{agencia:agencia},
      type:"POST",
    })
    .done(function(e){
      if (e){
        data = JSON.parse($.trim(e));  

        var select = document.getElementById("inpDistrito"); 
        var opt=select.options.length;
        for(i=opt-1;i>=1;i--){
          select.options[i]=null;         
        }
        data.forEach(function(item){
          select.innerHTML += "<option value=\"" + item.inm_dist + "\">" +item.inm_dist+" - " +item.dis_nom +"</option>";         
        })  
     /*    alert(select.value());
        alert(select.options[0].value); */   
        $("#inpDistrito").val(select.options[0].value);   
      }else{
        alertMessage('Error en Base de Datos','error'); 
      }
    })
    .fail(function(){
      alertMessage('Sin conexion con Base de Datos','error'); 
    })
  }
});