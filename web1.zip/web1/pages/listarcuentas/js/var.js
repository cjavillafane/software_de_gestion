var idioma_espanol = {
  "decimal":        ",",
  "thousands":      ".",
  "sProcessing":     "Procesando...",
  "sLengthMenu":     "Mostrar _MENU_ registros",
  "sZeroRecords":    "No se encontraron resultados",
  "sEmptyTable":     "Ningún dato disponible en esta tabla",
  "sInfo":           "Mostrando del _START_ al _END_ de un total de _TOTAL_",
  "sInfoEmpty":      "Mostrando del 0 al 0 de un total de 0 registros",
  "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
  "sInfoPostFix":    "",
  "sSearch":         "Buscar:",
  "sUrl":            "",
  "sInfoThousands":  ",",
  "sLoadingRecords": "Cargando...",
  "oPaginate": {
    "sFirst":    "Primero",
    "sLast":     "Último",
    "sNext":     "<span aria-hidden='true'>&raquo;</span>",
    "sPrevious": "<span aria-hidden='true'>&laquo;</span>"
  },
  "oAria": {
    "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
    "sSortDescending": ": Activar para ordenar la columna de manera descendente"
  }  
};

function valEntero(valor,min,max){
  var num=parseFloat(valor)
  if(Number.isInteger(num)&&(num>=min)&&(num<=max)){   
    return 'ok';
  }else{    
    return 'no valido';
  }  
} 
function valCuenta(valor){
  var arrayCta=valor.split('-'); 
  var cuenta=parseFloat(arrayCta[0]);
  var scta=parseFloat(arrayCta[1]);
  if (Number.isInteger(cuenta)&&(cuenta>0)&&(cuenta<=999999)){
    if (Number.isInteger(scta)&&(scta>=0)&&(scta<=999)){
      return 'ok';
    }else{
      return 'Numero de SubCuenta no valido';
    }
  }else{
    return 'numero de cuenta no valido';
  }
}
function valCadena(valor,minChar,maxChar){
  var cadena=valor.length;
  if (cadena>=minChar && cadena<=maxChar){
    return 'ok';
  }else{
    return 'no Valido';
  }
}


/* de 5 a 8*/
function valDni(valor){
  var cadena=valor.length;
  var cuenta=parseFloat(cadena);
  if (Number.isInteger(cuenta) && cadena>=5 && cadena<=8 ){
    return 'ok';
  }else{
    return ' DNI no Valido';
  }
}
/* de 9  a 11*/
function valCuit(digide,doc,digver){
  var ide=parseFloat(digide);
  var doc=parseFloat(doc);
  var ver=parseFloat(digver);
  if (Number.isInteger(ide) && ide>9 && ide<=99){
    if (Number.isInteger(doc) && doc>9999 && doc<=99999999){
      if (Number.isInteger(ver) && ver>=0 && ver<=9){
        return 'ok';
      }else{
        return ' Digito Verificador no valido';
      }   
    }else{
      return 'Documento no valido';
    }
  }else{
    return 'Digito Identificador no valido';
  }
}
function valStrNum(valor,max){
  if (valor.length<=max){
    return 'ok'
  }else{
    return 'supera maximo permitido'
  }
}

/* var opmap={
  zoomControl: false
};
var mapCta=L.map('mapCta', opmap).setView([-26.82, -65.22],9); */

/* var satelital = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
  attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
  maxZoom:22,
});
var blancoNegro = L.tileLayer('https://stamen-tiles-{s}.a.ssl.fastly.net/toner-background/{z}/{x}/{y}{r}.{ext}', {
	attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
	subdomains: 'abcd',
	minZoom: 0,
  maxZoom:22,
	ext: 'png'
}).addTo(mapCta); */
/* document.getElementsByClassName( 'leaflet-control-attribution' )[0].style.display = 'none';  */

