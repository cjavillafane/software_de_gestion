

<div class="uk-card uk-card-default uk-card-body">
  <div class="SearchAdvance">

    <!--  <form id="frmSearchData" name="frmSearchData"  onSubmit="searchData(this)"> -->
      <fieldset class="uk-fieldset">
        <legend class="uk-legend">Buscador de Cuentas Avanzado</legend>
        <div class="uk-margin">
          <label for="inpAgencia" class="uk-form-label">Agencia</label>
          <div class="uk-form-controls">
            <select id="inpAgencia" name="inpAgencia" class="uk-select uk-form-small" value="0"
            uk-tooltip="title: Seleccionar una Agencia ; pos:bottom-left">       
            </select>          
          </div>
        </div>
        <div class="uk-margin">
          <label for="inpDistrito" class="uk-form-label">Distritos</label>
          <div class="uk-form-controls">
            <select id="inpDistrito" name="inpDistrito" class="uk-select uk-form-small" 
            uk-tooltip="title: Seleccionar un distrito ; pos:bottom-left">   
              <option selected value=0>TODOS</option>           
            </select>          
          </div>
        </div>
        <div class="uk-margin uk-grid-small uk-child-width-1-2@s uk-child-width-1-4@m uk-text-center" uk-grid>
          <div>
            <div class="uk-margin">
              <input id="inpCodCliente" name="inpCodCliente" class="uk-input uk-form-small" type="text" 
              placeholder="Codigo de Cliente" uk-tooltip="title: Codigo de cliente; pos:bottom-left">
            </div>      
          </div>
          <div>
            <div class="uk-margin">
              <input id="inpCuenta" name="inpCuenta" class="uk-input uk-form-small" type="text"  
              placeholder="Cuenta y SubCta 9999999-9999" uk-tooltip="title: Cuenta y subcta 9999999-9999 ; pos:bottom-left">
            </div>   
          </div>
          <div>
            <div class="uk-margin">
              <input id="inpPadron" name="inpPadron" class="uk-input uk-form-small" type="text" 
              placeholder="Padron Catastral" uk-tooltip="title:Padron catastral ; pos:bottom-left">
            </div>      
          </div>
          <div>
            <div class="uk-margin">
              <input id="inpMedidor" name="inpMedidor" class="uk-input uk-form-small" type="text" 
              placeholder="N° de medidor" uk-tooltip="title:Numero de medidor ; pos:bottom-left">
            </div>      
          </div>
        </div>
        <ul uk-accordion="multiple: true">
          <li>
            <a href="#" class="uk-accordion-title"><i class="fas fa-home"></i>&nbsp;Dirección</a>
            <div class="uk-accordion-content">
              <div class="uk-margin uk-grid-small uk-child-width-1-2@s uk-child-width-1-3@m uk-text-center" uk-grid>
                <div>
                  <div class="uk-margin">
                    <input id="inpDireccion" name="inpDireccion" class="uk-input uk-form-small" type="text" 
                    placeholder="Dirección ej:  Avenida Avellaneda 99999" uk-tooltip="title: Direccion: calle y numero; pos:bottom-left">
                  </div>                
                </div>
                <div>
                  <div class="uk-margin">
                    <select id="inpRango" name="inpRango" class="uk-select uk-form-small" uk-tooltip="title: Rango de N° de puertas; pos:bottom-left">
                      <option value="10">10</option> 
                      <option value="20">20</option>
                      <option value="30">30</option>
                      <option value="40">40</option>
                      <option value="50">50</option>
                      <option value="100">100</option>
                    </select>
                  </div>  
                </div>
                <div>
                  <div class="uk-margin">
                    <select id="inpTipo" name="inpTipo" class="uk-select uk-form-small" uk-tooltip="title: Tipo de dirección  ; pos:bottom-left">
                      <option value="INMUEBLES">Inmueble</option>
                      <option value="POSTALES" >Postal</option>
                    </select>
                  </div>  
                </div>
              </div>
              <div class="uk-margin uk-grid-small uk-child-width-1-5@s uk-child-width-1-5@m uk-text-center" uk-grid>
                <div>
                  <div class="uk-margin">
                    <input id="inpBarrio" name="inpBarrio" class="uk-input uk-form-small" type="text" placeholder="Nombre del Barrio"
                    uk-tooltip="title:Barrio ; pos:bottom-left">
                  </div> 
                </div>
                <div>
                  <div class="uk-margin">
                    <input id="inpMz" name="inpMz" class="uk-input uk-form-small" type="text" placeholder="Manzana"
                    uk-tooltip="title: Manzana ; pos:bottom-left">
                  </div> 
                </div>
                <div>
                  <div class="uk-margin">
                    <input id="inpBlk" name="inpBlk" class="uk-input uk-form-small" type="text" placeholder="Block"
                    uk-tooltip="title:Block ; pos:bottom-left">
                  </div> 
                </div>
                <div>
                  <div class="uk-margin">
                    <input id="inpLote" name="inpLote" class="uk-input uk-form-small" type="text" placeholder="Lote"
                    uk-tooltip="title:Lote ; pos:bottom-left">
                  </div> 
                </div>
                <div>
                  <div class="uk-margin">
                    <input id="inpCasa" name="inpCasa" class="uk-input uk-form-small" type="text" placeholder="Casa"
                    uk-tooltip="title:Casa ; pos:bottom-left">
                  </div> 
                </div>
               

              </div>
            </div>
          </li>           
          <li>
            <a href="#" class="uk-accordion-title"><i class="fas fa-id-card"></i>&nbsp;Cliente</a>
            <div class="uk-accordion-content">
              <div class="uk-margin uk-grid-small uk-child-width-1-2@s uk-child-width-1-3@m uk-text-center" uk-grid>
                <div>
                  <div class="uk-margin">
                    <input id="inpNomCliente" name="inpNomCliente" class="uk-input uk-form-small" type="text"
                     placeholder="Nombre y Apellido" uk-tooltip="title:Nombre y Apellido ; pos:bottom-left">
                  </div>
                </div>
                <div>
                  <div class="uk-margin">
                    <input id="inpDniCuit" name="inpDniCuit"class="uk-input uk-form-small" type="text" 
                    placeholder="DNI o CUIT (debe incluir '-') " uk-tooltip="title:DNI o CUIT ; pos:bottom-left">
                  </div>
                </div>
                <div>
                  <div class="uk-margin">
                    <select id="inpTipCli" name="inpTipCli" class="uk-select uk-form-small" disabled
                    uk-tooltip="title:Tipo de Cliente ; pos:bottom-left">
                      <option value="TITULAR">Titular</option>
                      <option value="USUARIO">Usuario</option>
                    </select>
                  </div>                
                </div>
              </div>
            </div>
          </li>     
        </ul>
        <div class=" uk-align-right ">  
          <button id="btnLocation" class="uk-button uk-button-secondary uk-button-small" disabled><i class="fas fa-search-location"></i> Localizar</button>    
          <button id="clear" class="uk-button uk-button-default uk-button-small" ><i class="fas fa-backspace"></i> Limpiar</button>
          <button id="searchCta" class="uk-button uk-button-primary uk-button-small" ><i class="fas fa-search"></i> Buscar</button>    
        </div>
       </fieldset>
  </div>
<!--   </form> -->
  <div class="uk-margin"id="tabla">
    <table class="uk-table uk-table-small uk-table-divider" id="tblResult">
      <thead style="background: #000">
        <tr>
          <th class="uk-width-small">Direccion</th>
          <th>N°</th>
          <th>Cod. Clte.</th>
          <th>dist.</th>
          <th>cta</th>
          <th>scta</th>
          <th>padron</th>
          <th>dni</th>
          <th>Nombre</th>
          <th>Barrio</th>
          <th>piso</th>   
          <th>dto.</th>
          <th>mz.</th>        
          <th>blk.</th>
          <th>lot.</th>
          <th>casa</th>
          <th>Actividad</th>
          <th>Servicio</th>
          <th>Medidor</th>
          <th>Botones</th>
        </tr>
      </thead>
      <tfoot>
        <tr>
          <th>Direccion</th>
          <th>N°</th>
          <th>codigo</th>
          <th>dist.</th>
          <th>cta</th>
          <th>scta</th>
          <th>padron</th>
          <th>dni</th>
          <th>Nombre</th>
          <th>Barrio</th>
          <th>piso</th>   
          <th>dto.</th>
          <th>mz.</th>        
          <th>blk.</th>
          <th>lot.</th>
          <th>casa</th>
          <th>Actividad</th>
          <th>Servicio</th>
          <th>Medidor</th>
          <th></th>
        </tr>
        </tfoot>
    </table>
  </div> 
</div>
<div id="modalMap" uk-modal>
  <div class="uk-modal-dialog uk-modal-body">
    <button class="uk-modal-close-default" type="button" uk-close></button>
    <h2 class="uk-modal-title">Ubicacion Geografica</h2> 
    <div id="mapa">
    </div>
    <iframe id="iframe" style="border:none; width:100%; height:350px" src="mapaCta.php?arrayCod=[16425021,16425022,16425023]"></iframe>
  <!--   <div class="mapa">
      <div id="mapCta"></div>
    </div>  -->  
  
  </div>
</div>

<!-- 
<div id="modalLoad" class="uk-modal-full" uk-modal >
  <div class="uk-modal-dialog">

    <div class="uk-grid-collapse uk-child-width-1-2@s uk-flex-middle" uk-grid>
    

    <div class="uk-padding-large">
    <h1>Buscando...</h1>
      <div class="loader"></div>
      </div>
         </div>
  </div>
</div>   -->  


<div id="modalLoad" class="uk-flex-top" uk-modal bg-close=false>
    <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
    <center>
      <h2>Buscando...</h2>
      <div class="loader"></div>
    </center>

    </div>
</div>


    
      
<!--     <input name="ctl00$PlaceContent$Usuario" type="text" id="Usuario" class="form-control" onkeydown="LimpiarMensaje()" onselect="LimpiarMensaje()" onkeypress="handleMask(event, '99-99999999-9')" placeholder="__-________-_"> 
      
      
      
        <div class="uk-margin">
            <select class="uk-select">
                <option>Option 01</option>
                <option>Option 02</option>
            </select>
        </div>

        <div class="uk-margin">
            <textarea class="uk-textarea" rows="5" placeholder="Textarea"></textarea>
        </div>

        <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
            <label><input class="uk-radio" type="radio" name="radio2" checked> A</label>
            <label><input class="uk-radio" type="radio" name="radio2"> B</label>
        </div>

        <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
            <label><input class="uk-checkbox" type="checkbox" checked> A</label>
            <label><input class="uk-checkbox" type="checkbox"> B</label>
        </div>

        <div class="uk-margin">
            <input class="uk-range" type="range" value="2" min="0" max="10" step="0.1">
        </div> -->


