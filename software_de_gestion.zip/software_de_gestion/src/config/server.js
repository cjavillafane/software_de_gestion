const express = require('express');
const path = require('path');
const app = express();
const cors = require('cors');
const cookieParser = require('cookie-parser');
const session = require('express-session');

//Carpeta estática

app.use('/static', express.static('static'));

//settings

app.set('port', process.env.PORT || 4747);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../app/views'));

app.use(express.urlencoded({ extended: false }));
app.use(cors());
app.use(express.json());
app.use(cookieParser());

app.use(session({
    secret: 'cmt496',
    resave: true,
    saveUninitialized: true
}));

module.exports = app;