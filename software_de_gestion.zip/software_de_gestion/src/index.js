const express = require('express');
const app = require('./config/server');
const path = require('path');
require('./app/routes/home')(app);
require('./app/routes/clientes')(app);
require('./app/routes/compras')(app);
require('./app/routes/empresas')(app);
require('./app/routes/login')(app);
require('./app/routes/periodos')(app);
require('./app/routes/proveedores')(app);
require('./app/routes/ventas')(app);



//start
app.listen(app.get('port'), () => {
    console.log('Escuchando puerto', app.get('port'));
});


const Afip = require('@afipsdk/afip.js');

const afip = new Afip({ CUIT: 20399758387 });

async function probar (){
    const serverStatus = await afip.RegisterScopeFour.getServerStatus();

    console.log('Este es el estado del servidor:');
    console.log(serverStatus);

//    const taxpayerDetails = await afip.RegisterScopeFour.getTaxpayerDetails(30536187339);
    const taxpayerDetails = await afip.RegisterScopeThirteen.getTaxpayerDetails(30536187339);
   console.log(taxpayerDetails);

   /*  const sales = await afip.ElectronicBilling.getSalesPoints();
    console.log(sales); */
}

probar();