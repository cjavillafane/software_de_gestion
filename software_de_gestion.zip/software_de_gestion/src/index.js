const express = require('express');
const app = require('./config/server');
const path = require('path');
require('./app/routes/home')(app);
require('./app/routes/clientes')(app);
require('./app/routes/compras')(app);
require('./app/routes/empresas')(app);
require('./app/routes/login')(app);
require('./app/routes/periodos')(app);
require('./app/routes/proveedores')(app);
require('./app/routes/ventas')(app);



//start
app.listen(app.get('port'), () => {
    console.log('Escuchando puerto', app.get('port'));
});


var mes = 10;

var date = new Date();
console.log(date);
date.setHours(date.getHours()-3);
console.log(date)
var primerDia = new Date(date.getFullYear(),mes , 1);
var ultimoDia = new Date(date.getFullYear(), mes + 1, 0);

console.log(primerDia);
console.log(ultimoDia);