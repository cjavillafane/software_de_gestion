const express = require('express');
const app = require('./config/server');
const path = require('path');
require('./app/routes/home')(app);
require('./app/routes/clientes')(app);
require('./app/routes/compras')(app);
require('./app/routes/empresas')(app);
require('./app/routes/login')(app);
require('./app/routes/periodos')(app);
require('./app/routes/proveedores')(app);
require('./app/routes/ventas')(app);



//start
app.listen(app.get('port'), () => {
    console.log('Escuchando puerto', app.get('port'));
});