const app = require('./config/server');
require('./app/routes/login')(app);


//start
app.listen(app.get('port'), () => {
    console.log('Escuchando puerto', app.get('port'));
});