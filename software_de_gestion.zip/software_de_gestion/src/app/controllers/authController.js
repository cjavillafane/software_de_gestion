const { Router } = require('express');
const router = Router();
const sql = require('mssql');

// const User = require('../models/User');
const verifyToken = require('./verifyToken');

const jwt = require('jsonwebtoken');
const config = require('../config');


const configdb = {
    server: 'localhost',
    database: 'gestionempresas',
    authentication: {
        type: 'default',
        options: {
            userName: 'root',
            password: 'Pacheco2021*'
        }
    },
    options: {
        encrypt: false,
        trustServerCertificate: true
    }
};




module.exports = router;