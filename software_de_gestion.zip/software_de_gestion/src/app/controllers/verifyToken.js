const jwt = require('jsonwebtoken');
const pool = require('../../config/database');
const consultas = require('../util/consultasMYSQL');
var CryptoJS = require("crypto-js");

async function verifyToken(req, res, next) {
    try{ 
    const token = req.session.user_data.token;
    var camino_usuario = [];
    var msg = "";
    if (!token) {
        var mensaje = {"respuesta":"Sesión expirada. Por favor inicie sesión nuevamente.",
                                "continuar":"Ingresar",
                                "ruta": "/login" }
        res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
    }

   
     
     var dte = await pool.query(consultas.claves());
     const decodificado = await jwt.verify(token, dte[0].token);

     var clave = req.session.encriptado.clave;
     var bytes  = CryptoJS.AES.decrypt(clave, dte[0].clave);
     var desencriptado = bytes.toString(CryptoJS.enc.Utf8);

     if (desencriptado=="seguridad_encriptada"){
        req.session.user_data.usuario=decodificado.usuario;
        next();
     }
    }
    catch (e){
        console.log(e);
        var camino_usuario = [];
        var mensaje = {"respuesta":"Sesión expirada. Por favor inicie sesión nuevamente.",
                               "continuar":"Ingresar",
                               "ruta": "/login" }
        res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
    }
}

async function verifyEmpresa(req, res, next) {
    if(req.session.user_data.idempresa==undefined){ 
        var camino_usuario = req.session.camino;
        var mensaje = {"respuesta":"Debe activar una empresa para continuar.",
                    "continuar":"Ir a empresas",
                    "ruta": "/empresas" }
        res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
    }
    else 
        next();
}

async function verifyPeriodo(req, res, next) {
    if ( req.session.user_data.idperiodo==undefined){
        var camino_usuario = req.session.camino;
        var mensaje = {"respuesta":"Debe activar un periodo para continuar.",
                    "continuar":"Ir a periodos",
                    "ruta": "/periodos" }
        res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
    }
    else 
        next();
}


module.exports.verifyToken = verifyToken;
module.exports.verifyEmpresa = verifyEmpresa;
module.exports.verifyPeriodo = verifyPeriodo;