const jwt = require('jsonwebtoken');
const config = require('../clavetoken');
const pool = require('../../config/database');
const consultas = require('../util/consultasMYSQL');
var CryptoJS = require("crypto-js");

async function verifyToken(req, res, next) {
    try{ 
    const token = req.session.user_data.token;
    var msg = "";
    if (!token) {
        msg = "Sesión expirada. Error de sesión";
       // res.render('./components/errorMsg.ejs', {msg});
       res.json({msg});
    }

   
     console.log("el token a decodificar es "+token);
     var dte = await pool.query(consultas.claves());
     const decodificado = await jwt.verify(token, dte[0].token);

     var clave = req.session.encriptado.clave;
     var bytes  = CryptoJS.AES.decrypt(clave, dte[0].clave);
     var desencriptado = bytes.toString(CryptoJS.enc.Utf8);

     if (desencriptado=="seguridad_encriptada"){
        req.session.user_data.usuario=decodificado.usuario;
        next();
     }
    }
    catch (e){
        console.log(e);
        msg = "Error de Sesión expirada. Por favor inicie sesión nuevamente.";
        //res.render('./components/errorMsg.ejs', {msg});
        res.json({msg});
    }
}


module.exports.verifyToken = verifyToken;