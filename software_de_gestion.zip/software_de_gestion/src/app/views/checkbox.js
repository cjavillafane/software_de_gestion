
$(document).ready(function(){
$('input[type="checkbox"]').change(function(){
   if($(this).is(':checked')){
       $('input[type="checkbox"]').not(this).prop('checked', false);
       
    /*    var tr = $(this).closest('td');
       
       var reservacion =$(tr).find('td:nth-child(1)').text();
       var nombre = $(tr).find('td:nth-child(2)').text();
       var loc_externo = $(tr).find('td:nth-child(3)').text();
       var pickup = $(tr).find('td:nth-child(4)').text();
       var retorno =$(tr).find('td:nth-child(5)').text();
       var canal = $(tr).find('td:nth-child(6)').text();
       var auto = $(tr).find('td:nth-child(7)').text(); */
        
   }
})
})
