var valPassword = (idInput) => {
    let input= document.getElementById(idInput);
    let error=""; 
  
    if (input.value){
      var expPass = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,16}$/;
      if (input.value.match(expPass)){
        clearError(idInput);
      }else{error="Password no valido";}    
    }else{error="El password no puede ser vacio";}
    if (error) {addError(idInput);}
    return {valor:input.value,error};
  
  }

  function valLegajo(input,max){
    var valor=document.getElementById(input).value;
    var num=parseFloat(valor)
    
    var mensaje="";
    if (valor!=""){    
      if (!valor.match(/[^0-9]/)){
        if(Number.isInteger(num)){
    
          if ((num>0)&&(num<=max)){
            mensaje="ok"
          }else{mensaje="Usuario, no valido"}
        }else{ mensaje="Usuario, debe ser un numero entero"};
      }else{mensaje="solo debe ingresar numeros"}
    }else{mensaje="Legajo, no puede ser vacio"}
    if (mensaje!="ok"){
      addError(input);
    }
  
    return mensaje;
  };


$(document).ready(function(){
    /*Enviar form de login */
    document.getElementById("iniciar_sesion").addEventListener("click",function(){
        window.location.href="/inicio";
      var datos={};         
      var error=false;    
      var password=valPassword("password")
      var errorLeg=valLegajo("usuario",9999);
      if (document.getElementById("remember-me").checked){
        datos.recurdame='R'
      }else{
        datos.recurdame='N'
      }  
      if (errorLeg!="ok"){ /*si hay error legajo*/
        alertMessage(errorLeg,"error");
        error=true;
      }else{datos.usuario= document.getElementById("usuario").value}
      if(password.error!==""){ /*si hay error en password*/
        alertMessage(password.error,"error");        
        error=true;
      }else{datos.password= document.getElementById("password").value}
      console.log(datos);
      if (!error){ 
          if(datos.usuario==1234 && datos.password=='123456'){
            setTimeout(function(){
                window.location.href="./inicio/inicio.ejs";
              },2000)
          }
        /* alertMessage("datos correctos",'success');   */    
       /*  console.log(datos); */
    /*     $.ajax({
          url:"login.php",
          data:{usuario:datos.usuario, password:datos.password,recuerdame:datos.recurdame},
          type:"POST",
        })
        .done(function(e){
          
               
      
          switch (e){
            case '0':
              addError('inpUser');
              alertMessage("Usuario inexistente o bloquedo",'error');
              break;         
            case '2':
              addError('inpPassword');
              alertMessage("Password incorrecto",'error');
              break;
            case '3':
              alertMessage("Autorizado",'success');
              debugger
              setTimeout(function(){
                window.location.href="../mapa/index.php";
              },2000)
              break;
          }
  
  
       
        })
        .fail(function(){
          alertMessage('Error en la Base de Datos','error');
        }) */
      }
    });
    /*Enviar form de Register*//* 
    document.getElementById("btnPassword").addEventListener("click",function(){
      if ($('#inpPassword').attr('type')=='password') {
        $('#inpPassword').attr('type', 'text');
      } else {
        $('#inpPassword').attr('type', 'password');
      }
    }); */
    document.getElementById("btnRegister").addEventListener("click",function(){
      var datos={};
      var error=false;
      var errorUsuario=valLegajo("inpUsuarioR",9999)
      var errorNombre=valString("inpNombre",40);
      var emailInt=valEmail("inpMailInt",false);
      var email=valEmail("inpMail",true);
      var errorAgen=valAgen("inpAgencia");
  
      var password=valPassword("inpPasswordR")
  
      if (errorUsuario!="ok"){
        alertMessage(errorUsuario,"error");
        error=true;
      }else{datos.usuario=document.getElementById("inpUsuarioR").value}
      if (errorNombre!="ok"){
        alertMessage("Nombre, "+errorNombre,"error");
        error=true;
      }else{datos.nombre=document.getElementById("inpNombre").value}
      /*emite mensaje si hay error, sino lo guarda en datos*/
      if(emailInt.error){
        alertMessage(emailInt.error,"error");
        error=true;
      }else{datos.emailInt=emailInt.valor}
      if(email.error){
        alertMessage(email.error,"error");
        error=true;
      }else{datos.email=email.valor}
  
      if (errorAgen!="ok"){
        alertMessage(errorAgen,"error");
        error=true;
      }else{datos.agencia=document.getElementById("inpAgencia").value}
  
      if (password.error){
        alertMessage(password.error,"error");
        error=true;
      }else{datos.password=password.valor}
      if (!error){
        
        altaUsuario(datos);
      }
  
  
  
  
    });
  
    let altaUsuario= (datos) => {
      fetch ('./php/altaUsuario.php', {
        method: 'POST',
        body:JSON.stringify(datos),
        headers: {'Content-Type': 'application/json'}       
      })
      .then((response) => response.json())
      .then( json => {
        if (!json){   
          alertMessage('Alta exitosa, contactar al administrador','success');   
          UIkit.modal('modRegister').hide();              
        }else{
          alertMessage('El usuario ya fue dado de alta','error');                 
        }      
      })
      .catch((error) => {
        alertMessage('Problemas con el servidor :'+error,'error');  
        console.log(error);
      })
  
  
    }
  
      document.getElementById('inpUser').addEventListener("change",function(event){
        clearError(event.target.id);
      });
      document.getElementById('inpPassword').addEventListener("change",function(event){
        clearError(event.target.id);
      });
      document.getElementById('inpUsuarioR').addEventListener("change",function(event){
        clearError(event.target.id);
      });
      document.getElementById('inpNombre').addEventListener("change",function(event){
        clearError(event.target.id);
      });
      document.getElementById('inpMailInt').addEventListener("change",function(event){
        clearError(event.target.id);
      });
      document.getElementById('inpMail').addEventListener("change",function(event){
        clearError(event.target.id);
      });
      document.getElementById('inpAgencia').addEventListener("change",function(event){
        clearError(event.target.id);
      });
      document.getElementById('inpPasswordR').addEventListener("change",function(event){
        clearError(event.target.id);
      });
     /*  document.getElementById("btnReg").addEventListener("click",function(){
        alertMessage('Registrar');
      }); */
  /* hace visible el password en login*/
      document.getElementById("btnPassword").addEventListener("click",function(){
        var input=document.getElementById("inpPassword");
        if (input.type=="password"){
          input.type="text";
        }else{
          input.type="password";
        }
      });
  /* hace visible el password en el Registro*/
      document.getElementById("btnPasswordR").addEventListener("click",function(){
        var input=document.getElementById("inpPasswordR");
        if (input.type=="password"){
          input.type="text";
        }else{
          input.type="password";
        }
      });
      function loadListAgen(){
        var data=listAgencias();    
        if (data!=[]){
          var select = document.getElementById("inpAgencia"); 
          data.forEach(function(item){
            if (item.numeroagencia!=0){
              select.innerHTML += "<option value=\"" + item.numeroagencia + "\">" + item.nombre + "</option>";         
            }
          });
          
          
        }else{
          alertMessage('Error en listar cuentas','error');
        }
  
      };
      loadListAgen();
  /*     document.getElementById("inpAgencia").addEventListener("change",function(){      
        var selectDist=document.getElementById("inpDistrito");
        var selectAge=document.getElementById("inpAgencia")
        selectDist.disabled=false;
        if (selectAge.options[0].value=="0"){
          selectAge.options[0]=null
        };
        var agencia=parseInt( selectAge.value,10);
        if (agencia>0 & agencia<=13){        
          var data=listDistAgen(agencia);
          clearSelect("inpDistrito");
          data.forEach(function(item){        
            selectDist.innerHTML += "<option value=\"" + item.inm_dist + "\">" +item.inm_dist+" - " +item.dis_nom +"</option>";                
          }); 
  
        }
      }); */
    document.getElementById("btnRecuperar").addEventListener("click",function(){
      var email=valEmail("inpMailRecover",true);    
      alert(email.error+"   valor:"+email.valor  );
      fetch ('./php/recuperar.php',{
        method: 'POST',
        body: JSON.stringify({email:email.valor}),
        headers:{'Content-Type': 'application/json'}
      })
      .then (response => response.json())
      .then (json => {           
        /* console(json); */      
      })
      .catch (error => {
        alertMessage('Error en la consulta : '+error,'error');
      })
  
    })
  
     
  
  
  
  
   
      
    });