const query = {
    activar_empresa: function (idusuario,idempresa) {
        return "CALL activar_empresa('"+idusuario+"','"+idempresa+"');";
    },
    activar_periodo: function (idusuario,idempresa,idperiodo) {
        return "CALL activar_periodo('"+idusuario+"','"+idempresa+"','"+idperiodo+"');";
    },
    crear_empresa: function (idusuario,nombre,cuit,telefono,condicion_iva,domicilio,localidad,provincia,concepto,actividad_principal,actividad_secundaria,oper_compras,oper_ventas,inicio_actividad,ingresos_brutos,establecimiento_n,n_libro_compras,n_libro_ventas,sede_timbrado,hoja_libro_compras,hoja_libro_ventas) {
  
        return "";
    },
    claves: function () {
        return "SELECT * FROM clave_token WHERE idclavetoken=1;";
    },
    listar_usuarios: function () {
        return "SELECT * FROM usuarios;";
    },
   
    listar_empresas: function (idusuario) {
        return "SELECT e.* FROM empresas e INNER JOIN usuario_empresa ue ON e.idempresa=ue.empresas_idempresa"+
        " INNER JOIN usuarios u ON u.idusuario=ue.usuarios_idusuario WHERE u.idusuario='"+idusuario+"';";
    },

    listar_periodos: function (idempresa) {
        return "SELECT * FROM periodos WHERE empresas_idempresa='"+idempresa+"';";
    },

    listar_compras: function (idempresa) {
        return "SELECT * FROM compras WHERE empresas_idempresa='"+idempresa+"';";
    },

    listar_ventas: function (idempresa) {
        return "SELECT * FROM ventas WHERE empresas_idempresa='"+idempresa+"';";
    },

    listar_clientes: function (idempresa) {
        return "SELECT DISTINCT p.* FROM ventas v INNER JOIN personas p ON "+
        " v.personas_idpersona=p.idpersona WHERE v.empresas_idempresa='"+idempresa+"';";
    },

    listar_proveedores: function (idempresa) {
        return "SELECT DISTINCT p.* FROM compras c INNER JOIN personas p ON "+
        " c.personas_idpersona=p.idpersona WHERE c.empresas_idempresa='"+idempresa+"';";
    },

    login: function (usuario,contrasena) {
        return "CALL login('"+usuario+"','"+contrasena+"');";
    }
   
}

module.exports = query;