const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const verifyToken = require('../controllers/verifyToken');

module.exports = app => {

    app.get('/compras',  verifyToken.verifyToken,  async (req, res) => {

        if(req.session.user_data.idempresa!=undefined){
                var idempresa = req.session.user_data.idempresa;
                var compras = await pool.query(consultas.listar_compras(idempresa));
                console.log(compras);
                var camino_usuario = req.session.camino;

                res.render('./compras/listarCompras.ejs',{compras,camino_usuario})
        }
        else{
            var camino_usuario = req.session.camino;
            var mensaje = {"respuesta":"Debe activar una empresa para continuar.",
                           "continuar":"Ir a empresas",
                           "ruta": "/empresas" }
            res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
        }
        });

        app.get('/nuevaCompra',  verifyToken.verifyToken,  async (req, res) => {
            var camino_usuario = req.session.camino;

            res.render('./compras/nuevaCompra.ejs',{camino_usuario})
            });
    
        app.post('/nuevaCompra',  verifyToken.verifyToken,  async (req, res) => {
            try{
            var idusuario =  1 //req.session.user_data.idusuario;
            var { fecha_emision,buscar_proveedor,cuit,ingresos_brutos,cond_iva,provincia,tipo_comprobante,actividad,tipo_compra,
             comprobante,comprobante2,comprobante3,codigo_autorizacion,fecha_vencimiento,importe,subtotal,neto_grabado,neto_grabado2,
            iva,iva1,iva2,iva3,busqueda,tipo_retencion} = req.body;
            
            var nuevo_Compra = { }
  
            
            try {
                var crear_Compra = await pool.query("INSERT personas SET ? " , [nuevo_Compra]);
                console.log(crear_Compra);
            }
            catch (error) {
                res.send(error);
                console.log("Error al crear el Compra");
                console.log(error);
    
                fs.writeFile('error_en_nuevo_Compra.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
    
            }
    
    
         //   res.json( {"respuesta": "hola.!"})
            res.redirect('/compras');
            }
            catch (error) {
                res.send(error);
                console.log("Error al crear el Compra.");
                console.log(error);
                fs.writeFile('error_en_nuevo_Compra.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
            }});
    
            app.get('/modificarCompra/:id',  verifyToken.verifyToken,  async (req, res) => {
                try{
                const { id } = req.params;
                var idusuario =  1 //req.session.user_data.idusuario;
                // Realizar Controles para verificar que el usuario tenga permisos para modificar    

                const Compra = await pool.query('Select * from personas where idpersona= ? and usuarios_idusuario = ?', [id,idusuario]);
                console.log(Compra);
                res.render('./compras/modificarCompra.ejs', { Compra })
                }
                
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el el Compra");
                    console.log(error);
        
                    fs.writeFile('error_en_modificar_Compra.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });    
                }
            });
    
            app.post('/modificarCompra/:id',  verifyToken.verifyToken,  async (req, res) => {
                try{
                  const { id } = req.params;
                  var idusuario =  1 //req.session.user_data.idusuario;
                  // Realizar Controles para verificar que el usuario tenga permisos para modificar      

                  var { nombre,direccion,localidad,provincia,telefono,cuenta,cond_iva,Compra_global,ingresos_brutos,actividad  } = req.body;
            
                  var Compra_modificado = { nombre,direccion,localidad,provincia,telefono,cuenta,"condicion_iva":cond_iva,
                     Compra_global,"n_ingr_brutos":ingresos_brutos,"rubro_actividad":actividad}
          
        
                try {
                    var modificar_Compra = await pool.query("UPDATE personas SET ? WHERE idpersona = ? and usuarios_idusuario = ?'", [Compra_modificado, id,idusuario]);
                    console.log(modificar_Compra);
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el el Compra");
                    console.log(error);
        
                    fs.writeFile('error_en_modificar_Compra.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });
        
                }
        
        
             //   res.json( {"respuesta": "hola.!"})
                 res.redirect('/compras');
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el Compra.");
                    console.log(error);
                    fs.writeFile('error_en_modificar_Compra.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });
            }});
    
            app.post('/eliminarCompra',  verifyToken.verifyToken,  async (req, res) => {
                    var idempresa = req.body.idempresa;
                    var idcompra = req.body.idcompra;
                    var idusuario =  1 //req.session.user_data.idusuario;
                       // Realizar Controles para verificar que el usuario tenga permisos para eliminar compras    
                    try {
                        var result = await pool.query('DELETE compras WHERE idcompra = ? AND empresas_idempresa = ?', [idcompra,idempresa]);
                        console.log(result);
                    }
                    catch (error) {
                        res.send(error);
                        console.log("Error al eliminar el Compra");
                        console.log(error);
                    }
                    res.redirect('/compras');
            });
    
    
    }