module.exports = app => {





app.get('/', async (req, res) => {
    res.render('./login/login.ejs')
});

app.post('/login', async (req, res) => {

    res.json( {"respuesta": "hola.!"})
 //   res.render('./home/home.ejs')
    });

}