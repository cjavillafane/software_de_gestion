module.exports = app => {





app.get('/', async (req, res) => {
    res.render('./home/home.ejs')
});

app.get('/inicio', async (req, res) => {
    res.render('./inicio/inicio.ejs')
});// 

app.post('/login', async (req, res) => {

    res.json( {"respuesta": "hola.!"})
 //   res.render('./home/home.ejs')
    });

}