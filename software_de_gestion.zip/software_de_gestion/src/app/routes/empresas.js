const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const fs = require('fs');
const verifyToken = require('../controllers/verifyToken');

module.exports = app => {

    app.get('/empresas', async (req, res) => {

        var idusuario = 1;
        var empresas = await pool.query(consultas.listar_empresas(idusuario));
        console.log(empresas);
        var camino_usuario = req.session.camino;
      
        res.render('./empresas/listarEmpresas.ejs',{empresas,camino_usuario} )
        });

    app.get('/nuevaEmpresa', async (req, res) => {
        var camino_usuario = req.session.camino;
        res.render('./empresas/nuevaEmpresa.ejs', {camino_usuario})
        });

    app.post('/nuevaEmpresa', async (req, res) => {

        try{
            
            var idusuario = req.session.user_data.idusuario;

        var { cuit,nombre,direccion,localidad,provincia,telefono,cond_iva,concep_predeterminado,act_principal,act_secundaria,
             compras, ventas,act_inicio,ingresos_brutos,establecimiento,iva_compras,iva_ventas,sede_timbrado,hoja_compras,hoja_ventas  } = req.body;


        try {
            var crear_empresa =  await pool.query("CALL crear_empresa ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)",[idusuario,nombre,cuit,telefono,cond_iva,direccion,localidad,provincia,concep_predeterminado,act_principal,act_secundaria,compras,ventas,act_inicio,ingresos_brutos,establecimiento,iva_compras,iva_ventas,sede_timbrado,hoja_compras,hoja_ventas]);
            console.log(crear_empresa);
            
        }
        catch (error) {
            res.send(error);
            console.log("Error al crear la empresa");
            console.log(error);

            fs.writeFile('error_en_nueva_empresa.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });

        }


     //   res.json( {"respuesta": "hola.!"})
        res.redirect('/empresas');
        }
        catch (error) {
            res.send(error);
            console.log("Error al crear la empresa.");
            console.log(error);
            fs.writeFile('error_en_nueva_empresa.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });
        }});

        app.post('/modificarEmpresa', async (req, res) => {
            var camino_usuario = req.session.camino;
            var id = req.body.idempresa;
            
            //var id = req.session.user_data.username.empresa_modificada;
            console.log(id);
            const empresa = await pool.query('Select * from empresas where idempresa= ?', [id]);
            console.log(empresa);
            res.render('./empresas/modificarEmpresa.ejs', { empresa ,camino_usuario})
    
        });

        app.post('/modificarEmpresaForm', async (req, res) => {
            try{
            var id = req.body.idempresa;    
            var { cuit,nombre,direccion,localidad,provincia,telefono,cond_iva,concep_predeterminado,act_principal,act_secundaria,
                 compras, ventas,act_inicio,ingresos_brutos,establecimiento,iva_compras,iva_ventas,sede_timbrado,hoja_compras,hoja_ventas  } = req.body;
            
            var empresa_modificada = { cuit,nombre,"domicilio":direccion,localidad,provincia,telefono,"condicion_iva":cond_iva,"concepto":concep_predeterminado,
                "actividad_principal":act_principal,"actividad_secundaria":act_secundaria,"oper_compras":compras, "oper_ventas":ventas,
                "inicio_actividad":act_inicio,ingresos_brutos,"establecimiento_n":establecimiento,"n_libro_compras":iva_compras,
                "n_libro_ventas":iva_ventas,sede_timbrado,"hoja_libro_compras":hoja_compras,"hoja_libro_ventas":hoja_ventas,"activa":1 }
                
            console.log(empresa_modificada);
            try {
                var modificar_empresa = await pool.query("UPDATE empresas SET ? WHERE idempresa = ?", [empresa_modificada, id]);
                console.log(modificar_empresa);
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la empresa");
                console.log(error);
    
                fs.writeFile('error_en_modificar_empresa.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
    
            }
    
    
         //   res.json( {"respuesta": "hola.!"})
             res.redirect('/empresas');
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la empresa.");
                console.log(error);
                fs.writeFile('error_en_modificar_empresa.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
        }
        
    });

        app.post('/activarEmpresa', async (req, res) => {
            var idusuario = req.session.user_data.idusuario;
            var id = req.body.idempresa;    // id de la empresa con la que se quiere trabajar.
            req.session.camino = [];
            //var id = req.session.user_data.username.empresa_modificada;
            console.log(id);
            console.log(idusuario);
            const activada = await pool.query(consultas.activar_empresa(idusuario,id));
            console.log(activada);

            if(activada[0].length>0){
                req.session.user_data.idempresa=id;
                req.session.camino = [{"valor":activada[0][0].nombre.toString(),
                                        "ruta":"/empresas"}];
                var camino_usuario =  req.session.camino;
                console.log(camino_usuario);
                var mensaje = {"respuesta":"Empresa activada exitosamente.",
                               "continuar":"Continuar a Menú Periodos",
                               "ruta": "/periodos"  }
        
                res.render('./components/mensaje_exito.ejs', {mensaje,camino_usuario});
              //  res.json({"Mensaje":"Empresa activada exitosamente."})
            }
            else{
                req.session.user_data.idempresa=null;
                var mensaje = {"respuesta":"Hubo un error al activar la empresa.",
                               "continuar":"Volver",
                               "ruta": "/-" }
                res.render('./components/mensaje_error.ejs', {mensaje});
                //res.json({"Error":"Fallo al  activar empresa."})
            }
            
           // res.render('./empresas/modificarEmpresa.ejs', { empresa })
    
        });


        app.post('/eliminarEmpresa' , async (req, res) => {
                var id = req.body.idempresa;   
                try {
                    var result = await pool.query('UPDATE empresas set activa=0 where idempresa=' + id);
                    console.log(result);
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al eliminar la empresa");
                    console.log(error);
                }
                res.redirect('/empresas');
        });

}