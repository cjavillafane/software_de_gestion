const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const verifyToken = require('../controllers/verifyToken');

module.exports = app => {

    app.get('/proveedores',  verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
 
            var idempresa = req.session.user_data.idempresa;
            var proveedores = await pool.query(consultas.listar_proveedores(idempresa));
            console.log(proveedores);
            var camino_usuario = req.session.camino;

            res.render('./proveedores/listarProveedores.ejs',{proveedores,camino_usuario})
      
        });

        app.get('/nuevoProveedor',  verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
            var camino_usuario = req.session.camino;
            res.render('./proveedores/nuevoProveedor.ejs',{camino_usuario})
            });
    
        app.post('/nuevoProveedor',  verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
            try{
            var idusuario = req.session.user_data.idusuario;
            var idempresa = req.session.user_data.idempresa;
            var { cuit,nombre_proveedor,direccion,localidad,provincia,telefono,cuenta,cond_iva,ingresos_brutos,
                actividad,codigo_postal,proveedor_global  } = req.body;
            
            if(proveedor_global!=undefined)
                proveedor_global=0;
            else
                proveedor_global=1;       

            var nuevo_proveedor = { cuit,"nombre":nombre_proveedor,direccion,localidad,provincia,telefono,cuenta,"condicion_iva":cond_iva,codigo_postal,
                "cliente_global":proveedor_global,"n_ingr_brutos":ingresos_brutos,"rubro_actividad":actividad,
                "tipopersona":"Proveedor","usuarios_idusuario":idusuario,"empresas_idempresa":idempresa,"activo":"1"}
  
            
            try {
                var crear_Proveedor = await pool.query("INSERT personas SET ? " , [nuevo_proveedor]);
                console.log(crear_Proveedor);
            }
            catch (error) {
                res.send(error);
                console.log("Error al crear el Proveedor");
                console.log(error);
    
                fs.writeFile('error_en_nuevo_Proveedor.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
    
            }
    
    
         //   res.json( {"respuesta": "hola.!"})
            res.redirect('/proveedores');
            }
            catch (error) {
                res.send(error);
                console.log("Error al crear el Proveedor.");
                console.log(error);
                fs.writeFile('error_en_nuevo_Proveedor.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
            }});
    
            app.post('/modificarProveedor',  verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
                try{
                var id = req.body.idpersona;
                var camino_usuario = req.session.camino;
                var idusuario = req.session.user_data.idusuario;
                // Realizar Controles para verificar que el usuario tenga permisos para modificar    

                const proveedor = await pool.query('Select * from personas where idpersona= ? and usuarios_idusuario = ?', [id,idusuario]);
                console.log(proveedor);
                res.render('./proveedores/modificarProveedor.ejs', { proveedor,camino_usuario })
                }
                
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el el Proveedor");
                    console.log(error);
        
                    fs.writeFile('error_en_modificar_Proveedor.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });    
                }
            });
    
            app.post('/modificarProveedorForm',  verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
                try{
                  var id = req.body.idpersona;
                  var idusuario = req.session.user_data.idusuario;
                  // Realizar Controles para verificar que el usuario tenga permisos para modificar      

                  var { nombre_proveedor,direccion,localidad,provincia,telefono,cuenta,cond_iva,proveedor_global,ingresos_brutos,actividad  } = req.body;
            
                  if(proveedor_global!=undefined)
                     proveedor_global=0;
                  else
                     proveedor_global=1;    

                  var Proveedor_modificado = { "nombre":nombre_proveedor,direccion,localidad,provincia,telefono,cuenta,"condicion_iva":cond_iva,
                     "cliente_global":proveedor_global,"n_ingr_brutos":ingresos_brutos,"rubro_actividad":actividad}
          
        
                try {
                    var modificar_Proveedor = await pool.query("UPDATE personas SET ? WHERE idpersona = ? and usuarios_idusuario = ?", [Proveedor_modificado, id,idusuario]);
                    console.log(modificar_Proveedor);
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el el Proveedor");
                    console.log(error);
        
                    fs.writeFile('error_en_modificar_Proveedor.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });
        
                }
        
        
             //   res.json( {"respuesta": "hola.!"})
                 res.redirect('/proveedores');
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el Proveedor.");
                    console.log(error);
                    fs.writeFile('error_en_modificar_Proveedor.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });
            }});
    
            app.post('/eliminarProveedor',  verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
                    var id = req.body.idpersona;
                    var idusuario =  req.session.user_data.idusuario;
                       // Realizar Controles para verificar que el usuario tenga permisos para eliminar proveedores    
                    try {
                        var result = await pool.query('UPDATE personas set activo=0 where idpersona = ? and usuarios_idusuario = ? ;', [id,idusuario]);
                        console.log(result);
                    }
                    catch (error) {
                        res.send(error);
                        console.log("Error al eliminar el Proveedor");
                        console.log(error);
                    }
                    res.redirect('/proveedores');
            });
    
    
    }