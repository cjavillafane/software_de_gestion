const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const verifyToken = require('../controllers/verifyToken');

module.exports = app => {

    app.get('/periodos', verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {

        if(req.session.user_data.idempresa!=undefined){
        
        var idempresa = req.session.user_data.idempresa;
        var periodos = await pool.query(consultas.listar_periodos(idempresa));
        console.log(periodos);
        periodos.forEach(element => {
            if(element.fecha_inicio!=undefined)
                
                element.fecha_inicio = element.fecha_inicio.getDate() + "/" + (element.fecha_inicio.getMonth()+1) + "/" + element.fecha_inicio.getFullYear() ;
            else
                element.fecha_inicio = "-"   

            if(element.fecha_fin!=undefined)
                element.fecha_fin = element.fecha_fin.getDate() + "/" + (element.fecha_fin.getMonth()+1) + "/" + element.fecha_fin.getFullYear() ;
            else
                element.fecha_fin = "-"    
            
        });

        console.log(periodos);
        var camino_usuario = req.session.camino;

        res.render('./periodos/listarPeriodos.ejs',{periodos,camino_usuario})
        }
        else{
                var camino_usuario = req.session.camino;
                var mensaje = {"respuesta":"Debe activar una empresa para continuar.",
                               "continuar":"Ir a empresas",
                               "ruta": "/empresas" }
                res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
        }

        });

    app.get('/nuevoPeriodo', verifyToken.verifyToken, async (req, res) => {
        var camino_usuario = req.session.camino;
        res.render('./periodos/nuevoPeriodo.ejs',{camino_usuario})
        });

    app.post('/nuevoPeriodo', verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
        try{
  
        var idempresa = req.session.user_data.idempresa;

        var { nombre, anio,mes,fecha_inicio, fecha_fin  } = req.body;
        
        var mes = Number(mes);
        console.log(mes);
        if(mes<12){ 
            /*
            var date = new Date();
            date.setHours(date.getHours()-3); */
            var primerDia = new Date(anio,mes , 1);
            var ultimoDia = new Date(anio, mes + 1, 0);
            console.log(primerDia)
            console.log(ultimoDia);
            var nuevo_periodo = { nombre,"fecha_inicio":primerDia,"fecha_fin":ultimoDia,anio,
                "activo":1,"estado":"Abierto","empresas_idempresa": idempresa };
        }
        else
            { 
                var nuevo_periodo = { nombre,fecha_inicio,fecha_fin,anio,
                    "activo":1,"estado":"Abierto","empresas_idempresa": idempresa}
            }
       

            console.log (nuevo_periodo);
        try {
            var crear_periodo = await pool.query("INSERT periodos SET ? " , [nuevo_periodo]);
            console.log(crear_periodo);
        }
        catch (error) {
            var camino_usuario =  req.session.camino;
            var mensaje = {"respuesta":"Hubo un error al cargar los datos del Periodo.",
                           "continuar":"Volver",
                           "ruta": "/-" }
            res.render('./components/mensaje_volver.ejs', {mensaje,camino_usuario});
            console.log("Error al crear el periodo");
            console.log(error);

            fs.writeFile('error_en_nueva_periodo.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });

        }


     //   res.json( {"respuesta": "hola.!"})
        res.redirect('/periodos');
        }
        catch (error) {
                var camino_usuario =  req.session.camino;
                var mensaje = {"respuesta":"Hubo un error al cargar los datos del Periodo.",
                               "continuar":"Volver",
                               "ruta": "/-" }
                res.render('./components/mensaje_volver.ejs', {mensaje,camino_usuario});
            console.log(error);
            fs.writeFile('error_en_nueva_periodo.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });
        }});

        app.post('/modificarPeriodo', verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
            var id = req.body.idperiodo;
            var camino_usuario =  req.session.camino;
            const periodo = await pool.query('Select * from periodos where idperiodo= ?', [id]);
            periodo.forEach(element => {
                if(element.fecha_inicio!=undefined)
                    element.fecha_inicio = element.fecha_inicio.toISOString().slice(0,element.fecha_inicio.toISOString().length -14);
                else
                    element.fecha_inicio = "-"   

                if(element.fecha_fin!=undefined)
                    element.fecha_fin = element.fecha_fin.toISOString().slice(0,element.fecha_fin.toISOString().length -14);
                else
                    element.fecha_fin = "-"    
                
            });
            console.log(periodo);
            res.render('./periodos/modificarPeriodo.ejs', { periodo,camino_usuario })

        });

        app.post('/modificarPeriodoForm', verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
            try{
              var id = req.body.idperiodo;
              console.log("El periodo es: ---------------------- "+id);
              var idempresa = req.session.user_data.idempresa;

                var { nombre, anio,mes,fecha_inicio, fecha_fin  } = req.body;
                
                var mes = Number(mes);
                console.log(mes);
                if(mes<12){ 
                    /*
                    var date = new Date();
                    date.setHours(date.getHours()-3); */
                    var primerDia = new Date(anio,mes , 1);
                    var ultimoDia = new Date(anio, mes + 1, 0);
                    console.log(primerDia)
                    console.log(ultimoDia);
                    var periodo_modificado = { nombre,"fecha_inicio":primerDia,"fecha_fin":ultimoDia,anio };
                }
                else
                    { 
                        var periodo_modificado = { nombre,fecha_inicio,fecha_fin,anio}
                    }

                    console.log (periodo_modificado);
            try {
                var modificar_periodo = await pool.query("UPDATE periodos SET ? WHERE idperiodo = ? ", [periodo_modificado, id]);
                console.log(modificar_periodo);
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la el periodo");
                console.log(error);
    
                fs.writeFile('error_en_modificar_periodo.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
    
            }
    
    
         //   res.json( {"respuesta": "hola.!"})
             res.redirect('/periodos');
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la periodo.");
                console.log(error);
                fs.writeFile('error_en_modificar_periodo.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
        }});

        
        app.post('/activarPeriodo', verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
            var idusuario = req.session.user_data.idusuario;
            var idempresa = req.session.user_data.idempresa;
            var camino_usuario =  req.session.camino;
            var id = req.body.idperiodo;    // id de la empresa con la que se quiere trabajar.
            //var id = req.session.user_data.username.empresa_modificada;
            console.log(id);
            const activada = await pool.query(consultas.activar_periodo(idusuario,idempresa,id));
            console.log(activada);

            if(activada[0].length>0){
                req.session.user_data.idperiodo=id;
                
                if(req.session.camino.length>1)
                req.session.camino.pop();

                req.session.camino.push({"valor":activada[0][0].nombre.toString(),
                                        "ruta":"/periodos"});
                camino_usuario = req.session.camino;
                console.log(camino_usuario);
                var mensaje = {"respuesta":"Periodo activado exitosamente.",
                               "continuar":"Elegir otro periodo",
                               "ruta": "/periodos"  }
        
                res.render('./components/mensaje_exito.ejs', {mensaje,camino_usuario});
              //  res.json({"Mensaje":"Empresa activada exitosamente."})
            }
            else{
                req.session.user_data.idperiodo=null;
                var mensaje = {"respuesta":"Hubo un error al activar la empresa.",
                               "continuar":"Volver",
                               "ruta": "/-" }
                res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
            }
            
           // res.render('./empresas/modificarEmpresa.ejs', { empresa })
    
        });


        app.post('/eliminarPeriodo', verifyToken.verifyToken, verifyToken.verifyEmpresa, async (req, res) => {
               
                try {
                    var id = req.body.idperiodo;
                    if (id == req.session.user_data.idperiodo)
                          req.session.camino.pop();   
            
                    var camino_usuario = req.session.camino;
                    console.log(camino_usuario); 

                    var result = await pool.query('UPDATE periodos set activo=0 where idperiodo=' + id);
                    console.log(result);
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al eliminar el periodo");
                    console.log(error);
                }

                var mensaje = {"respuesta":"Periodo eliminado exitosamente.",
                               "continuar":"Elegir otro periodo",
                               "ruta": "/periodos"  }
        
                res.render('./components/mensaje_exito.ejs', {mensaje,camino_usuario});
        });


}