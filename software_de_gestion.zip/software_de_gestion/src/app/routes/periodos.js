const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const verifyToken = require('../controllers/verifyToken');

module.exports = app => {

    app.get('/periodos', async (req, res) => {

        var idempresa = req.session.user_data.idempresa;
        var periodos = await pool.query(consultas.listar_periodos(idempresa));
        console.log(periodos);
        var camino_usuario = req.session.camino;

        res.render('./periodos/listarPeriodos.ejs',{periodos,camino_usuario})
        });

    app.get('/nuevoPeriodo', async (req, res) => {
        var camino_usuario = req.session.camino;
        res.render('./periodos/nuevoPeriodo.ejs',{camino_usuario})
        });

    app.post('/nuevoPeriodo', async (req, res) => {
        try{
        // var idperiodo =  req.session.user_data.idperiodo;
  
        var idempresa = req.session.user_data.idempresa;
        var { nombre, fecha_inicio, fecha_fin  } = req.body;
        
        var nuevo_periodo = { nombre,fecha_inicio,fecha_fin,"anio":fecha_inicio.toString().slice(5,fecha_inicio.toString().length),
        "activo":1,"estado":"ABIERTO","empresas_idempresa": idempresa}

        try {
            var crear_periodo = await pool.query("INSERT periodos SET ? " , [nuevo_periodo]);
            console.log(crear_periodo);
        }
        catch (error) {
            res.send(error);
            console.log("Error al crear la periodo");
            console.log(error);

            fs.writeFile('error_en_nueva_periodo.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });

        }


     //   res.json( {"respuesta": "hola.!"})
        res.redirect('/periodos');
        }
        catch (error) {
            res.send(error);
            console.log("Error al crear la periodo.");
            console.log(error);
            fs.writeFile('error_en_nueva_periodo.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });
        }});

        app.post('/modificarPeriodo', async (req, res) => {
            var id = req.body.idperiodo;
            var camino_usuario =  req.session.camino;
            const periodo = await pool.query('Select * from periodos where idperiodo= ?', [id]);
            console.log(periodo);
            res.render('./periodos/modificarPeriodo.ejs', { periodo,camino_usuario })

        });

        app.post('/modificarPeriodoForm', async (req, res) => {
            try{
              var id = req.body.idperiodo;
              var { nombre, fecha_inicio, fecha_fin  } = req.body;
        
              var periodo_modificado = { nombre,fecha_inicio,fecha_fin,"anio":fecha_inicio.toString().slice(5,fecha_inicio.toString().length),
              "activo":1,"estado":"ABIERTO","periodos_idperiodo": idperiodo}
      
    
            try {
                var modificar_periodo = await pool.query("UPDATE periodos SET ? WHERE idperiodo = ?'", [periodo_modificado, id]);
                console.log(modificar_periodo);
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la el periodo");
                console.log(error);
    
                fs.writeFile('error_en_modificar_periodo.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
    
            }
    
    
         //   res.json( {"respuesta": "hola.!"})
             res.redirect('/periodos');
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la periodo.");
                console.log(error);
                fs.writeFile('error_en_modificar_periodo.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
        }});

        
        app.post('/activarPeriodo', async (req, res) => {
            var idusuario = req.session.user_data.idusuario;
            var idempresa = req.session.user_data.idempresa;
            var camino_usuario =  req.session.camino;
            var id = req.body.idperiodo;    // id de la empresa con la que se quiere trabajar.
            //var id = req.session.user_data.username.empresa_modificada;
            console.log(id);
            const activada = await pool.query(consultas.activar_periodo(idusuario,idempresa,id));
            console.log(activada);

            if(activada[0].length>0){
                req.session.user_data.idperiodo=id;
                
                if(req.session.camino.length>1)
                req.session.camino.pop();

                req.session.camino.push({"valor":activada[0][0].nombre.toString(),
                                        "ruta":"/periodos"});
                camino_usuario = req.session.camino;
                console.log(camino_usuario);
                var mensaje = {"respuesta":"Periodo activado exitosamente.",
                               "continuar":"Elegir otro periodo",
                               "ruta": "/periodos"  }
        
                res.render('./components/mensaje_exito.ejs', {mensaje,camino_usuario});
              //  res.json({"Mensaje":"Empresa activada exitosamente."})
            }
            else{
                req.session.user_data.idperiodo=null;
                var mensaje = {"respuesta":"Hubo un error al activar la empresa.",
                               "continuar":"Volver",
                               "ruta": "/-" }
                res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
            }
            
           // res.render('./empresas/modificarEmpresa.ejs', { empresa })
    
        });


        app.post('/eliminarPeriodo', async (req, res) => {
                var id = req.body.idperiodo;
                try {
                    var result = await pool.query('UPDATE periodos set activo=0 where idperiodo=' + id);
                    console.log(result);
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al eliminar el periodo");
                    console.log(error);
                }
                res.redirect('/periodos');
        });


}