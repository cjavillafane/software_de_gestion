const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/periodos', async (req, res) => {

        var idperiodo = 7;
        var periodos = await pool.query(consultas.listar_periodos(idperiodo));
        console.log(periodos);

        res.render('./periodos/listarPeriodos.ejs',{periodos})
        });

    app.get('/nuevoPeriodo', async (req, res) => {

        res.render('./periodos/nuevoPeriodo.ejs')
        });

    app.get('/nuevoPeriodo', async (req, res) => {
        try{
        // var idperiodo =  req.session.user_data.idperiodo;
        var  idperiodo = 7;
        var { nombre, fecha_inicio, fecha_fin  } = req.body;
        
        var nuevo_periodo = { nombre,fecha_inicio,fecha_fin,"anio":fecha_inicio.toString().slice(5,fecha_inicio.toString().length),
        "activo":1,"estado":"ABIERTO","periodos_idperiodo": idperiodo}

        try {
            var crear_periodo = await pool.query("INSERT periodos SET ? " , [nuevo_periodo]);
            console.log(crear_periodo);
        }
        catch (error) {
            res.send(error);
            console.log("Error al crear la periodo");
            console.log(error);

            fs.writeFile('error_en_nueva_periodo.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });

        }


     //   res.json( {"respuesta": "hola.!"})
        res.redirect('/periodos');
        }
        catch (error) {
            res.send(error);
            console.log("Error al crear la periodo.");
            console.log(error);
            fs.writeFile('error_en_nueva_periodo.txt', error, (err) => {
                // throws an error, you could also catch it here
                if (err) throw err;
            
                // success case, the file was saved
                console.log('Se produjo un error.');
            });
        }});

        app.post('/modificarPeriodo', async (req, res) => {
            var id = req.body.idperiodo;
            const periodo = await pool.query('Select * from periodos where idperiodo= ?', [id]);
            console.log(periodo);
            res.render('./periodos/modificarPeriodo.ejs', { periodo })

        });

        app.post('/modificarPeriodoForm', async (req, res) => {
            try{
              var id = req.body.idperiodo;
              var { nombre, fecha_inicio, fecha_fin  } = req.body;
        
              var periodo_modificado = { nombre,fecha_inicio,fecha_fin,"anio":fecha_inicio.toString().slice(5,fecha_inicio.toString().length),
              "activo":1,"estado":"ABIERTO","periodos_idperiodo": idperiodo}
      
    
            try {
                var modificar_periodo = await pool.query("UPDATE periodos SET ? WHERE idperiodo = ?'", [periodo_modificado, id]);
                console.log(modificar_periodo);
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la el periodo");
                console.log(error);
    
                fs.writeFile('error_en_modificar_periodo.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
    
            }
    
    
         //   res.json( {"respuesta": "hola.!"})
             res.redirect('/periodos');
            }
            catch (error) {
                res.send(error);
                console.log("Error al modificar la periodo.");
                console.log(error);
                fs.writeFile('error_en_modificar_periodo.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
        }});

        app.post('/eliminarPeriodo', async (req, res) => {
                var id = req.body.idperiodo;
                try {
                    var result = await pool.query('UPDATE periodos set activo=0 where idperiodo=' + id);
                    console.log(result);
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al eliminar el periodo");
                    console.log(error);
                }
                res.redirect('/periodos');
        });


}