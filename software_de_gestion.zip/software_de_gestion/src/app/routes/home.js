const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const verifyToken = require('../controllers/verifyToken');

module.exports = app => {

    app.get('/',  verifyToken.verifyToken, async (req, res) => {
        console.log( req.session.user_data);
        var usuarios = await pool.query(consultas.listar_usuarios());
        //console.log(usuarios);
    
        res.render('./home/home2.ejs');
        
    });
}