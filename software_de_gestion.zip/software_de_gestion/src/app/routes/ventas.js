const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/ventas', async (req, res) => {

        var idempresa = 7;
        var ventas = await pool.query(consultas.listar_ventas(idempresa));
        console.log(ventas);

        res.render('./ventas/listarVentas.ejs',{ventas})
        });

    app.get('/nuevaventa', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/nuevaventa', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
       
    app.get('/modificarventa', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/modificarventa', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
        
    app.post('/eliminarventa', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });       



}