const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const verifyToken = require('../controllers/verifyToken');

module.exports = app => {

    app.get('/ventas',  verifyToken.verifyToken,  async (req, res) => {

        var idempresa = 7;
        var ventas = await pool.query(consultas.listar_ventas(idempresa));
        console.log(ventas);
        var camino_usuario = req.session.camino;

        res.render('./ventas/listarVentas.ejs',{ventas,camino_usuario})
        });

    app.get('/nuevaventa',  verifyToken.verifyToken,  async (req, res) => {
        var camino_usuario = req.session.camino;
        
        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/nuevaventa',  verifyToken.verifyToken,  async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
       
    app.get('/modificarventa',  verifyToken.verifyToken,  async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/modificarventa',  verifyToken.verifyToken,  async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
        
    app.post('/eliminarventa',  verifyToken.verifyToken,  async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });       



}