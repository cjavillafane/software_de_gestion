const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');
const verifyToken = require('../controllers/verifyToken');
const fs = require('fs');
module.exports = app => {

    app.get('/clientes',  verifyToken.verifyToken,  async (req, res) => {

        if(req.session.user_data.idempresa!=undefined){

        var idempresa = req.session.user_data.idempresa;
        var clientes = await pool.query(consultas.listar_clientes(idempresa));
        console.log(clientes);
        var camino_usuario = req.session.camino;

       res.render('./clientes/listarClientes.ejs',{clientes,camino_usuario});
        }
        else{
            var camino_usuario = req.session.camino;
            var mensaje = {"respuesta":"Debe activar una empresa para continuar.",
                           "continuar":"Ir a empresas",
                           "ruta": "/empresas" }
            res.render('./components/mensaje_error.ejs', {mensaje,camino_usuario});
        }
        });

        app.get('/nuevoCliente',  verifyToken.verifyToken,  async (req, res) => {
            var camino_usuario = req.session.camino;
            res.render('./clientes/nuevocliente.ejs',{camino_usuario})
            });
    
        app.post('/nuevoCliente',  verifyToken.verifyToken,  async (req, res) => {
            try{
            var idusuario =  req.session.user_data.idusuario;
            var idempresa =  req.session.user_data.idempresa;
            var camino_usuario = req.session.camino;
            var { cuit,nombre,direccion,localidad,provincia,telefono,cuenta,cond_iva,cliente_global,ingresos_brutos,actividad  } = req.body;
            
            if(cliente_global!=undefined)
                cliente_global=0;
            else
                cliente_global=1;    

            var nuevo_cliente = { cuit,nombre,direccion,localidad,provincia,telefono,cuenta,"condicion_iva":cond_iva,
                cliente_global,"n_ingr_brutos":ingresos_brutos,"rubro_actividad":actividad,"tipopersona":"Cliente","empresas_idempresa":idempresa,
                "usuarios_idusuario":idusuario,"activo":"1"}
  
            
            try {
                var crear_cliente = await pool.query("INSERT personas SET ? " , [nuevo_cliente]);
                console.log(crear_cliente);
            }
            catch (error) {
               
                console.log("Error al crear el cliente");
                console.log(error);
                if(error.code=='ER_DUP_ENTRY'){
                    var mensaje = {"respuesta":"El número de CUIT ingresado ya se encuentra registrado para la empresa activa.",
                               "continuar":"Volver",
                               "ruta": "/-" }
                    res.render('./components/mensaje_volver.ejs', {mensaje,camino_usuario});
                }
                else{
                    var mensaje = {"respuesta":"Error en la carga de datos del cliente.",
                                "continuar":"Volver",
                                "ruta": "/-" }
                    res.render('./components/mensaje_volver.ejs', {mensaje,camino_usuario});
                }
            
                var mensaje_de_error = new Date().toISOString() + " - " + error.code + " - " + error.sqlMessage + "\n"
                fs.writeFile('error_en_nuevo_cliente.txt', mensaje_de_error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
    
            }
    
    
         //   res.json( {"respuesta": "hola.!"})
            res.redirect('/clientes');
            }
            catch (error) {
                res.send(error);
                console.log("Error al crear el cliente.");
                console.log(error);
                fs.writeFile('error_en_nueva_cliente.txt', error, (err) => {
                    // throws an error, you could also catch it here
                    if (err) throw err;
                
                    // success case, the file was saved
                    console.log('Se produjo un error.');
                });
            }});
    
            app.post('/modificarCliente',  verifyToken.verifyToken,  async (req, res) => {
                try{
                var id = req.body.idpersona;
                var idusuario =  req.session.user_data.idusuario;
                // Realizar Controles para verificar que el usuario tenga permisos para modificar    
                var camino_usuario = req.session.camino;

                const cliente = await pool.query('Select * from personas where idpersona= ? and usuarios_idusuario = ?', [id,idusuario]);
                console.log(cliente);
                res.render('./clientes/modificarcliente.ejs', { cliente,camino_usuario })
                }
                
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el el cliente");
                    console.log(error);
        
                    fs.writeFile('error_en_modificar_cliente.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });    
                }
            });
    
            app.post('/modificarClienteForm',  verifyToken.verifyToken,  async (req, res) => {
                try{
                  var id = req.body.idpersona;
                  var idusuario = req.session.user_data.idusuario;
                  // Realizar Controles para verificar que el usuario tenga permisos para modificar      

                  var { nombre,direccion,localidad,provincia,telefono,cuenta,cond_iva,cliente_global,ingresos_brutos,actividad  } = req.body;
            
                  if(cliente_global!=undefined)
                        cliente_global=0;
                  else
                        cliente_global=1;    

                  var cliente_modificado = { nombre,direccion,localidad,provincia,telefono,cuenta,"condicion_iva":cond_iva,
                     cliente_global,"n_ingr_brutos":ingresos_brutos,"rubro_actividad":actividad}
          
        
                try {
                    var modificar_cliente = await pool.query("UPDATE personas SET ? WHERE idpersona = ? and usuarios_idusuario = ?'", [cliente_modificado, id,idusuario]);
                    console.log(modificar_cliente);
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el el cliente");
                    console.log(error);
        
                    fs.writeFile('error_en_modificar_cliente.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });
        
                }
        
        
             //   res.json( {"respuesta": "hola.!"})
                 res.redirect('/clientes');
                }
                catch (error) {
                    res.send(error);
                    console.log("Error al modificar el cliente.");
                    console.log(error);
                    fs.writeFile('error_en_modificar_cliente.txt', error, (err) => {
                        // throws an error, you could also catch it here
                        if (err) throw err;
                    
                        // success case, the file was saved
                        console.log('Se produjo un error.');
                    });
            }});
    
            app.post('/eliminarCliente',  verifyToken.verifyToken,  async (req, res) => {
                    var id = req.body.idpersona;
                    var idusuario = req.session.user_data.idusuario;
                       // Realizar Controles para verificar que el usuario tenga permisos para eliminar clientes    
                    try {
                        var result = await pool.query('UPDATE personas set activo = 0 where idpersona = ? and usuarios_idusuario = ? ;', [id,idusuario]);
                        console.log(result);
                    }
                    catch (error) {
                        res.send(error);
                        console.log("Error al eliminar el cliente");
                        console.log(error);
                    }
                    res.redirect('/clientes');
            });
    
    
    }