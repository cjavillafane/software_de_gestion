module.exports = {
    secret: 'mysecretkey',
    secretDelegar: 'clavedeacceso'
}