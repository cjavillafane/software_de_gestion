  /**
       * Funcion que crea los eventos necesarios
       */
   const setEvents = () => {
    document.querySelectorAll("input").forEach(el => {
        el.removeEventListener("keyup", calcularFila);
        el.addEventListener("keyup", calcularFila);
    });
};
setEvents();
 
/**
 * Funcion para calcular el subtotal de la fila
 * Se ejecuta cada vez que se modifica un input
 */
function calcularFila() {
    const tr=this.closest("tr")
     const num=tr.querySelectorAll("input[type=number]");
     console.log(num,'num')
     if(num[0]!=undefined && num[1]!=undefined)
      num[2].value=parseFloat(num[1].value*num[0].value/100 || 0 ).toFixed(2);

      tr.querySelector(".subtotal").innerText=(parseFloat(num[1].value)+parseFloat(num[2].value) || 0).toFixed(2);
     
      const suma_impuestos=[...document.getElementsByName("impuesto")].reduce((acum, el) => acum+parseFloat(el.value), 0);
    console.log(suma_impuestos);
    document.getElementById("total_retencion").value=suma_impuestos;
 

    var x=document.getElementById("importe_total").value-parseFloat(document.querySelector(".total").innerText);
    document.getElementById("diferencia_total").value=parseFloat(x).toFixed(2);
     
    calcularTotal();
    agregarFila();
} 
 
/**
 * Funcion que calcula el total
 */
 function calcularTotal() {
    const suma=[...document.querySelectorAll(".subtotal")].reduce((acum, el) => acum+parseFloat(el.innerText), 0);
   
    document.querySelector(".total").innerText=suma.toFixed(2);
  
} 
 
/**
 * Funcion para revisar si hay que añadir una nueva fila
 * Unicamente se añade una nueva fila, si la ultima fila no
 * esta vacia
 */
function agregarFila() {
    // revisamos si la ultima fila esta vacia.
    const tr=document.querySelectorAll("tr");
    // la ultima fila contiene el total, y nosotros queremos al anterior a la del total
    const ultimaFila=tr[tr.length-2];
    //console.log(ultimaFila,'hola',tr);
    // comprovamos si la ultima fila esta vacia
    const vacio=[...ultimaFila.querySelectorAll("input")].every(el => el.value=="");
    //console.log(vacio,'222222');
    if (vacio==false) {
        ultimaFila.insertAdjacentElement('afterend', createTr(tr.length-2));
        setEvents();
    } 
}
 
/**
 * Funcion que crea una nueva fila
 *
 * @return {object} tr
 */
function createTr(id) {
    // creamos una nueva fila
     const td1=document.createElement("td");
    const input1=document.createElement("input");
    input1.type="text";
    input1.name="retencion";
    td1.appendChild(input1); 
 
 
    const td2=document.createElement("td");
    const input2=document.createElement("input");
    input2.type="number";
    input2.name="porcentaje";
   
    td2.appendChild(input2);
 
    const td3=document.createElement("td");
    const input3=document.createElement("input");
    input3.type="number";
    input3.name="neto";
      
    td3.appendChild(input3);

    const td4=document.createElement("td");
    const input4=document.createElement("input");
    input4.type="number";
    input4.name="impuesto";
    input4.disabled=true;  
    td4.appendChild(input4);

    const td5=document.createElement("td");
    const input5=document.createElement("input");
    input5.type="text";
    input5.name="producto_servicio";
    
    td5.appendChild(input5);

    const td6=document.createElement("td");
    const input6=document.createElement("input");
    input6.type="date";
    input6.name="fecha_pago";
      
    td6.appendChild(input6);

    
 
    const td7=document.createElement("td");
    td7.classList.add("subtotal");
    td7.innerText="0.00"; 
 
    const tr=document.createElement("tr");
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    tr.appendChild(td5);
    tr.appendChild(td6);
    tr.appendChild(td7);
 
    return tr;
}