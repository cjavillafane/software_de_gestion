act_inicio.max = new Date().toISOString().split("T")[0];


function validacion(){
    var cuit = document.getElementById("cuit").value;
  if( cuit == null || cuit.length == 0 || /^\s+$/.test(cuit) ) {
    alert("El cuit no puede ser vacio")
    return false;
  }

  var nombre = document.getElementById("nombre").value;
  if( nombre == null || nombre.length == 0 || /^\s+$/.test(nombre) ) {
    alert("El nombre no puede ser vacio")
    return false;
  }

  var direccion = document.getElementById("direccion").value;
  if( direccion == null || direccion.length == 0 || /^\s+$/.test(direccion) ) {
    alert("La direccion no puede ser vacia")
    return false;
  }

  var localidad = document.getElementById("localidad").value;
  if( localidad == null || localidad.length == 0 || /^\s+$/.test(localidad) ) {
    alert("La localidad no puede ser vacia")
    return false;
  }

  var telefono = document.getElementById("telefono").value;
  if( telefono == null || telefono.length == 0 || /^\s$/.test(telefono) ) {
    alert("El telefono no puede ser vacio")
    return false;
  }

  var act_inicio = document.getElementById("act_inicio").value;
  if( act_inicio == null || act_inicio.length == 0 || /^\s$/.test(act_inicio) ) {
    alert("Debe elegir una fecha de inicio de Actividad")
    return false;
  }

  var ingresos_brutos = document.getElementById("ingresos_brutos").value;
  if( ingresos_brutos == null || ingresos_brutos.length == 0 || /^\s$/.test(ingresos_brutos) ) {
    alert("El n° de ingreso bruto no puede ser vacio")
    return false;
  }

  establecimiento = document.getElementById("establecimiento").value;
  if( isNaN(establecimiento) ) {
    alert("Debe ingresar un numero en el establecimiento")
    return false;
  }

  if( establecimiento == null || establecimiento.length == 0 || /^\s$/.test(establecimiento) ) {
    alert("Debe ingresar un numero en el establecimiento")
    return false;

   }

   var iva_compras = document.getElementById("iva_compras").value;
   if( iva_compras == null || iva_compras.length == 0 || /^\s$/.test(iva_compras) ) {
    alert("El n° del libro de iva compras no puede ser vacio")
    return false;

   }

   var iva_ventas = document.getElementById("iva_ventas").value;
   if( iva_ventas == null || iva_ventas.length == 0 || /^\s$/.test(iva_ventas) ) {
    alert("El n° del libro de iva ventas no puede ser vacio")
    return false;

   }

   var sede_timbrado = document.getElementById("sede_timbrado").value;
   if( sede_timbrado == null || sede_timbrado.length == 0 || /^\s$/.test(sede_timbrado) ) {
    alert("El n° de sede de timbrado no puede ser vacio")
    return false;

   }

   var hoja_compras = document.getElementById("hoja_compras").value;
   if( hoja_compras == null || hoja_compras.length == 0 || /^\s$/.test(hoja_compras) ) {
    alert("El n° de hoja del libro de iva compras no puede ser vacio")
    return false;

   }
   
   var hoja_ventas = document.getElementById("hoja_ventas").value;
   if( hoja_ventas == null || hoja_ventas.length == 0 || /^\s$/.test(hoja_ventas) ) {
    alert("El n° de hoja del libro de iva ventas no puede ser vacio")
    return false;

   }
  }