$(document).ready(async function () {
    $('#btn_afip').click(async function () {

$('#comprobante').val("taxpayerDetails.razonSocial");
        $('#comprobante2').val("1");
        $('#comprobante3').val("taxpayerDetails.tipoPersona");


    })
  });


 /*  function agregarRetencion(){
    document.getElementById("tabla_nuevaCompra").insertRow(-1).innerHTML = '<td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td>';

  } */

  fecha_emision.max = new Date().toISOString().split("T")[0];

  fecha_vencimiento.min = new Date().toISOString().split("T")[0];