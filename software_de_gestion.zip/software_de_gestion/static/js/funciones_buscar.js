(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

      var _input;

      function _onInputEvent(e) {
        _input = e.target;
        var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
        Arr.forEach.call(tables, function(table) {
          Arr.forEach.call(table.tBodies, function(tbody) {
            Arr.forEach.call(tbody.rows, _filter);
          });
        });
      }

      function _filter(row) {
        var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
        row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
      }

      return {
        init: function() {
          var inputs = document.getElementsByClassName('light-table-filter');
          Arr.forEach.call(inputs, function(input) {
            input.oninput = _onInputEvent;
          });
        }
      };
    })(Array.prototype);

    document.addEventListener('readystatechange', function() {
      if (document.readyState === 'complete') {
        LightTableFilter.init();
      }
    });

  })(document);
 

      $(document).ready(function(){
     $('input[type="checkbox"]').change(function(){
         if($(this).is(':checked')){
             $('input[type="checkbox"]').not(this).prop('checked', false);
             
       
              
         }
     })
 })


 $('#delete-modal').on('show.bs.modal', function (e) {
	var $button = $(e.relatedTarget);
  var entry_number = $button.data('entry-number');
  $(this).find('#entry-num').text(entry_number);
  $(this).find('#delete-confirm').attr('data-target', '#entry-' + entry_number);
}).on('hide.bs.modal', function () {
	$(this).find('#entry-num').text('');
  $(this).find('#delete-confirm').attr('data-target', '');
});

$('#delete-confirm').on('click', function () {
   var entry_target = $(this).attr('data-target');
console.log($(this).data('target'));
   console.log($(this).attr('data-target'));
   var $target = $(entry_target);
   $target.remove();
   $('#delete-modal').modal('hide');
});
 