const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/proveedores', async (req, res) => {

        var idempresa = 7;
        var proveedores = await pool.query(consultas.listar_proveedores(idempresa));
        console.log(proveedores);

        res.render('./proveedores/listarProveedores.ejs',{proveedores})
        });

    app.get('/nuevoproveedor', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/nuevoproveedor', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
       
    app.get('/modificarproveedor', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/modificarproveedor', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
        
    app.post('/eliminarproveedor', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });       



}