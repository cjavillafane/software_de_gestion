const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/empresas', async (req, res) => {

        var idusuario = 1;
        var empresas = await pool.query(consultas.listar_empresas(idusuario));
        console.log(empresas);
      
       // res.json( {"respuesta": "hola empresas.!"})
        res.render('./empresas/listarEmpresas.ejs',{empresas} )
        });

    app.get('/nuevaempresa', async (req, res) => {

     //   res.json( {"respuesta": "hola.!"})
        res.render('./empresas/nuevaEmpresa.ejs')
        });



}