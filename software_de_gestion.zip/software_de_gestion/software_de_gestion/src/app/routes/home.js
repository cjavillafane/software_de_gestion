const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/', async (req, res) => {
    
        var usuarios = await pool.query(consultas.listar_usuarios());
        console.log(usuarios);
    
        res.render('./home/home.ejs');
        
    });
}