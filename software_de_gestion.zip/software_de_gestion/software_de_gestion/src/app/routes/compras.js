const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/compras', async (req, res) => {

        var idempresa = 7;
        var compras = await pool.query(consultas.listar_compras(idempresa));
        console.log(compras);

      //  res.json( {"respuesta": "hola compras.!"})
        res.render('./compras/listarCompras.ejs',{compras})
        });

    app.post('/nuevacompra', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });



}