const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/periodos', async (req, res) => {

        var idempresa = 7;
        var periodos = await pool.query(consultas.listar_periodos(idempresa));
        console.log(periodos);

      //  res.json( {"respuesta": "hola periodos.!"})
        res.render('./periodos/listarPeriodos.ejs',{periodos})
        });

    app.post('/nuevoperiodo', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });



}