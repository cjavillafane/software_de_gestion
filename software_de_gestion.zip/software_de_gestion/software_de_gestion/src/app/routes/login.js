const _md5 = require('md5');
const jwt = require('jsonwebtoken');
const config = require('../clavetoken');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {


app.get('/login', async (req, res) => {

  

    res.render('./login/login.ejs');
    
});


app.post('/login', async (req, res) => {
    try{
        var usuario = req.body.usuario;
        req.session.usuario = usuario;
        var username = "";
        var clave =  req.body.contrasena;  //_md5(req.body.contrasena);
        var msg = 'El usuario o clave ingresados son incorrectos, intente nuevamente.';
        var login = await pool.query(consultas.login(usuario,clave));

                if(login.length>0){
                    const token = jwt.sign({"usuario": usuario}, config.secret, {
                        expiresIn: 36000
                    });
                    req.session.user_data={token};
                    req.session.user_data.username =login[0].nombre.toString().trim()
                    username=login[0].nombre.toString().trim();
                   // console.log("token generado "+req.session.user_data.token);
                    res.redirect('/');

                } else {
                    res.render('./components/errorMsg.ejs', { msg });
                }
       
    }
    catch(error){
        console.log(error);
    }
    });;



app.post('/logout', async (req, res) => {
    req.session.user_data=null;
    req.session.usuario=null;
    res.render('./login/login.ejs')
});

}