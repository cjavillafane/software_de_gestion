const app = require('../../config/server');
const consultas = require('../util/consultasMYSQL');
const pool = require('../../config/database');


module.exports = app => {

    app.get('/clientes', async (req, res) => {

        var idempresa = 7;
        var clientes = await pool.query(consultas.listar_clientes(idempresa));
        console.log(clientes);

     //   res.json( {"respuesta": "hola ventas.!"})
       res.render('./clientes/listarClientes.ejs',{clientes})
        });

    app.get('/nuevocliente', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/nuevocliente', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
       
    app.get('/modificarcliente', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
     //   res.render('./home/home.ejs')
        });

    app.post('/modificarcliente', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });
        
    app.post('/eliminarcliente', async (req, res) => {

        res.json( {"respuesta": "hola.!"})
        //   res.render('./home/home.ejs')
        });       



}