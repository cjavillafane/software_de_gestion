const query = {
    listar_usuarios: function () {
        return "SELECT * FROM usuarios;";
    },
   
    listar_empresas: function (idusuario) {
        return "SELECT e.* FROM empresas e INNER JOIN usuario_empresa ue ON e.idempresa=ue.empresas_idempresa"+
        " INNER JOIN usuarios u ON u.idusuario=ue.usuarios_idusuario WHERE u.idusuario='"+idusuario+"';";
    },

    listar_periodos: function (idempresa) {
        return "SELECT * FROM periodos WHERE empresas_idempresa='"+idempresa+"';";
    },

    listar_compras: function (idempresa) {
        return "SELECT * FROM compras WHERE empresas_idempresa='"+idempresa+"';";
    },

    listar_ventas: function (idempresa) {
        return "SELECT * FROM ventas WHERE empresas_idempresa='"+idempresa+"';";
    },

    listar_clientes: function (idempresa) {
        return "SELECT DISTINCT p.* FROM ventas v INNER JOIN personas p ON "+
        " v.personas_idpersona=p.idpersona WHERE v.empresas_idempresa='"+idempresa+"';";
    },

    listar_proveedores: function (idempresa) {
        return "SELECT DISTINCT p.* FROM compras c INNER JOIN personas p ON "+
        " c.personas_idpersona=p.idpersona WHERE c.empresas_idempresa='"+idempresa+"';";
    },

    login: function (usuario,contrasena) {
        return "SELECT * FROM usuarios WHERE usuario ='"+usuario+"' AND contrasena ='"+contrasena+"';";
    }
    
}

module.exports = query;