const jwt = require('jsonwebtoken');
const config = require('../clavetoken');

async function verifyToken(req, res, next) {
    try{ 
    const token = req.session.user_data.token;
    var msg = "";
    if (!token) {
        msg = "Sesión expirada. Error de sesión";
        res.render('./components/errorMsg.ejs', {msg});
    }

   
     console.log("el token a decodificar es "+token);
     const decodificado = await jwt.verify(token, config.secret);
   //  console.log("lo decodificado es: "+decodificado.codme);
     req.session.user_data.socio=decodificado.codme;
     next();
    }
    catch{
        msg = "Sesión expirada. Por favor inicie sesión nuevamente.";
        res.render('./components/errorMsg.ejs', {msg});
    }
}


async function verificarDelegar(req, res, next) {
    const token = req.body.token;
    const Delegar = req.body.delegar;
    
    if (!token) {
        return res.status(401).send({ auth: false, message: 'Acesso denegado' });
    }
    // Decode the Tokenreq.userId = decoded.id;
    try{
     const decodificado =  await jwt.verify(token, config.secret);
    }
    catch{
     
        res.status(401).send({ auth: false, message: 'Acesso denegado' });
    }

    try{
     const decodificadoDelegar =  await jwt.verify(Delegar, config.secretDelegar);
     next();
    }
    catch{
       
        res.status(401).send({ auth: false, message: 'Acesso denegado' });
    }




}



module.exports.verifyToken = verifyToken;
module.exports.verificarDelegar = verificarDelegar;